﻿// [stage-wrap chunked<70000B] frame37 折叠中间态：帧顶联合头(lint --fold-specific 子集,0 碰撞)
//   + staged 函数(8 chunk 绕 AVM1 64KB 函数体上限,见 swf-function-sizes 门) + 内联调用。
import flash.filters.*;
import flash.geom.*;
import org.flashNight.arki.bullet.BulletComponent.Collider.*;
import org.flashNight.arki.camera.*;
import org.flashNight.arki.component.Buff.*;
import org.flashNight.arki.component.Buff.Component.*;
import org.flashNight.arki.component.Collider.*;
import org.flashNight.arki.component.Effect.*;
import org.flashNight.arki.item.*;
import org.flashNight.arki.render.*;
import org.flashNight.arki.spatial.move.*;
import org.flashNight.arki.unit.*;
import org.flashNight.arki.unit.Action.Regeneration.*;
import org.flashNight.arki.unit.UnitComponent.Dressup.*;
import org.flashNight.arki.unit.UnitComponent.Dressup.EquipmentUtil.*;
import org.flashNight.arki.unit.UnitComponent.Targetcache.*;
import org.flashNight.arki.weather.*;
import org.flashNight.gesh.object.*;
import org.flashNight.naki.DataStructures.*;
import org.flashNight.neur.Event.*;
import org.flashNight.neur.StateMachine.*;
import org.flashNight.sara.util.*;

if (_root.__boot == undefined) _root.__boot = {};
_root.__boot.f37_1 = function() {
    #include "../逻辑/装备函数/通用装备函数.as"
    // ========== 集中管理的import语句 ==========
    // 所有装备函数文件共享的类库引用

    // ========== 装备函数文件include列表 ==========
    #include "../逻辑/装备函数/外观类挂载.as"
    #include "../逻辑/装备函数/红外夜视仪.as"
    #include "../逻辑/装备函数/电感切割刃.as"
    #include "../逻辑/装备函数/炎魔斩new.as"
    #include "../逻辑/装备函数/烬灭裁决.as"
    #include "../逻辑/装备函数/死者之手.as"

    #include "../逻辑/装备函数/双面雷神.as"

    #include "../逻辑/装备函数/雷铁斩斧.as"
    #include "../逻辑/装备函数/特勤警棍.as"
    #include "../逻辑/装备函数/牙狼剑.as"
};
_root.__boot.f37_2 = function() {
    #include "../逻辑/装备函数/公社爆燃钻矛.as"

    #include "../逻辑/装备函数/RPG.as"
    #include "../逻辑/装备函数/PF98A.as"
    #include "../逻辑/装备函数/追月连弩.as"
    #include "../逻辑/装备函数/RPG28.as"
    #include "../逻辑/装备函数/RShG4.as"
    #include "../逻辑/装备函数/RShG4Я.as"

    #include "../逻辑/装备函数/光刀狮子.as"
    #include "../逻辑/装备函数/光斧金牛.as"
    #include "../逻辑/装备函数/光剑天秤.as"
    #include "../逻辑/装备函数/光刃摩羯.as"


    #include "../逻辑/装备函数/斩马刀.as"
};
_root.__boot.f37_3 = function() {
    #include "../逻辑/装备函数/烈焰斩马刀.as"

    #include "../逻辑/装备函数/键盘镰刀.as"
};
_root.__boot.f37_4 = function() {
    #include "../逻辑/装备函数/吉他喷火.as"
};
_root.__boot.f37_5 = function() {
    #include "../逻辑/装备函数/主唱光剑.as"
    #include "../逻辑/装备函数/火药燃气液压打桩机.as"
#include "../逻辑/装备函数/打桩机M7.as"
    #include "../逻辑/装备函数/刀口触发特效.as"
    #include "../逻辑/装备函数/XM25.as"
    #include "../逻辑/装备函数/XM556_Microgun.as"
    #include "../逻辑/装备函数/XM556-OC-Overlord.as"
    #include "../逻辑/装备函数/XM556_H_Stinger.as"
    #include "../逻辑/装备函数/NEGEV.as"
    #include "../逻辑/装备函数/M249.as"
    #include "../逻辑/装备函数/Jackhammer.as"
    #include "../逻辑/装备函数/G11.as"
    #include "../逻辑/装备函数/G111.as"
};
_root.__boot.f37_6 = function() {
    #include "../逻辑/装备函数/G1111.as"
    #include "../逻辑/装备函数/XM214-CageFrame.as"
    #include "../逻辑/装备函数/M134.as"
    #include "../逻辑/装备函数/M134暴力版.as"
    #include "../逻辑/装备函数/wa90变形款.as"
    #include "../逻辑/装备函数/镜之虎彻.as"
    #include "../逻辑/装备函数/铁枪.as"
    #include "../逻辑/装备函数/黑铁的剑.as"
    #include "../逻辑/装备函数/僵尸割草机.as"
    #include "../逻辑/装备函数/混凝土切割机.as"
    #include "../逻辑/装备函数/MACSIII.as"
};
_root.__boot.f37_7 = function() {
    #include "../逻辑/装备函数/等离子切割机.as"
    #include "../逻辑/装备函数/杀戮风暴.as"
    #include "../逻辑/装备函数/Six12_Matryoshka.as"

    #include "../逻辑/装备函数/P90.as"
    #include "../逻辑/装备函数/AR57.as"

    #include "../逻辑/装备函数/GM6_LYNX.as"

    #include "../逻辑/装备函数/Mark3.as"
    #include "../逻辑/装备函数/毒液蜘蛛侠.as"
    #include "../逻辑/装备函数/贯空天盖手套.as"

    #include "../逻辑/装备函数/喷气背包.as"

    #include "../逻辑/装备函数/剑圣胸甲.as"
    #include "../逻辑/装备函数/剑圣套装.as"
    #include "../逻辑/装备函数/剑圣头部装甲.as"
};
_root.__boot.f37_8 = function() {
    #include "../逻辑/装备函数/枪械射击动画.as"
    #include "../逻辑/装备函数/枪械激光瞄准.as"
    #include "../逻辑/装备函数/装备光源.as"
    #include "../逻辑/装备函数/血色光剑天秤.as"
    #include "../逻辑/装备函数/钛合金套装.as"
    #include "../逻辑/装备函数/剑圣腿甲.as"
    #include "../逻辑/装备函数/剑圣手甲.as"
    #include "../逻辑/装备函数/剑圣装甲鞋.as"
    #include "../逻辑/装备函数/九命猫妖.as"
};
_root.__boot.f37_1();
_root.__boot.f37_2();
_root.__boot.f37_3();
_root.__boot.f37_4();
_root.__boot.f37_5();
_root.__boot.f37_6();
_root.__boot.f37_7();
_root.__boot.f37_8();
