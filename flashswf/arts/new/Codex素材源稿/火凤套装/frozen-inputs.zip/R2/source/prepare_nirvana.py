"""Freeze XFL timelines as reusable SVG definitions; never executes frame scripts.

Run with Python 3 from this package. The bundled XFL geometry reader is frozen.
Motion interpolation and nested graphic clocks are evaluated here explicitly.
Flash additive blending uses SVG screen; small gradient bevels are omitted.
"""
from pathlib import Path
from xml.etree import ElementTree as E
import sys, json, math, copy, hashlib
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).parent))
import xfl_exporter as X
ROOT=Path(__file__).resolve().parents[1]
NS=X.NS;I=list(X.IDENTITY);M=X.multiply
PREFIX='Codex/火凤转阶段/原稿/'

def tag(e):return e.tag.rsplit('}',1)[-1]
def matrix(e):return list(X.parse_matrix(e.find('./x:matrix/x:Matrix',NS)))
def translation(x,y):return [1,0,0,1,x,y]
def lerp(a,b,t):return a+(b-a)*t
def ease(fr,t):
    pts=fr.findall('./x:tweens/x:CustomEase/x:Point',NS)
    if len(pts)==4:
        p=[(float(v.get('x',0)),float(v.get('y',0))) for v in pts]
        def bez(u,k):return (1-u)**3*p[0][k]+3*(1-u)**2*u*p[1][k]+3*(1-u)*u*u*p[2][k]+u**3*p[3][k]
        lo,hi=0.,1.
        for _ in range(28):
            q=(lo+hi)/2
            if bez(q,0)<t:lo=q
            else:hi=q
        return bez((lo+hi)/2,1)
    mode=fr.get('easeMethodName')
    if mode=='cubicOut':return 1-(1-t)**3
    if mode=='quadOut':return 1-(1-t)**2
    return t

def interpolate(a,b,t):
    """Classic transform tween: interpolate column angles, scales, translation."""
    out=copy.deepcopy(a)
    aa,bb=matrix(a),matrix(b)
    def col(x,y):return math.hypot(x,y),math.atan2(y,x)
    cols=[]
    for k in [0,2]:
        sa,ra=col(aa[k],aa[k+1]);sb,rb=col(bb[k],bb[k+1])
        r=ra+((rb-ra+math.pi)%(2*math.pi)-math.pi)*t;s=lerp(sa,sb,t)
        cols.extend([math.cos(r)*s,math.sin(r)*s])
    mm=cols+[lerp(aa[4],bb[4],t),lerp(aa[5],bb[5],t)]
    parent=out.find('./x:matrix',NS)
    if parent is None:parent=E.SubElement(out,'{'+NS['x']+'}matrix')
    me=parent.find('./x:Matrix',NS)
    if me is None:me=E.SubElement(parent,'{'+NS['x']+'}Matrix')
    me.attrib=dict(zip(['a','b','c','d','tx','ty'],map(str,mm)))
    ca=a.find('./x:color/x:Color',NS);cb=b.find('./x:color/x:Color',NS)
    if ca is not None or cb is not None:
        pa=out.find('./x:color',NS)
        if pa is None:pa=E.SubElement(out,'{'+NS['x']+'}color')
        ce=pa.find('./x:Color',NS)
        if ce is None:ce=E.SubElement(pa,'{'+NS['x']+'}Color')
        keys=set(ca.attrib if ca is not None else {})|set(cb.attrib if cb is not None else {})
        for key in keys:
            default=1 if key.endswith('Multiplier') else 0
            va=float(ca.get(key,default)) if ca is not None else default
            vb=float(cb.get(key,default)) if cb is not None else default
            ce.set(key,str(lerp(va,vb,t)))
    return out

class MotionRenderer(X.Renderer):
    def __init__(self,library,prefix):
        super().__init__(library,[]);self.prefix=prefix;self.symbols={};self.definitions=[];self.clock=[];self.framecache={};self.durationcache={};self.filtercache={};self.approximations=set()
    def duration(self,name):
        if name not in self.durationcache:self.durationcache[name]=max((int(f.get('index',0))+int(f.get('duration',1)) for f in self.load(name).findall('.//x:DOMFrame',NS)),default=1)
        return self.durationcache[name]
    def layers_at(self,name,frame):
        key=(name,frame)
        if key in self.framecache:return self.framecache[key]
        result=[];root=self.load(name)
        for li,layer in enumerate(root.findall('./x:timeline/x:DOMTimeline/x:layers/x:DOMLayer',NS)):
            if layer.get('layerType') in ('guide','folder') or layer.get('visible')=='false':continue
            frames=layer.findall('./x:frames/x:DOMFrame',NS)
            for fi,fr in enumerate(frames):
                start=int(fr.get('index',0));dur=int(fr.get('duration',1))
                if not start<=frame<start+dur:continue
                elapsed=frame-start;ee=fr.find('./x:elements',NS);els=list(ee) if ee is not None else []
                if elapsed and fr.get('tweenType')=='motion' and fi+1<len(frames):
                    ee=frames[fi+1].find('./x:elements',NS);nxt=list(ee) if ee is not None else []
                    if len(els)==len(nxt) and all(tag(a)==tag(b) and a.get('libraryItemName')==b.get('libraryItemName') for a,b in zip(els,nxt)):
                        els=[interpolate(a,b,ease(fr,elapsed/dur)) for a,b in zip(els,nxt)]
                    else:self.approximations.add('Unmatched tween elements held at keyframe')
                result.append((li,layer.get('name',''),els,elapsed));break
        self.framecache[key]=result
        return result
    def childframe(self,e,elapsed):
        name=e.get('libraryItemName');n=self.duration(name);first=int(e.get('firstFrame',0))
        loop=e.get('loop','loop')
        if loop=='single frame':return min(first,n-1)
        if loop=='play once':return min(first+elapsed,n-1)
        return (first+elapsed)%n
    def render_symbol(self,name,frame,where,ct=X.CT_IDENTITY):
        frame=int(frame)%self.duration(name);key=(name,frame,ct)
        if key in self.symbols:return '<use href="#'+self.symbols[key]+'"/>'
        aid=self.prefix+'s'+str(len(self.symbols));self.symbols[key]=aid
        chunks=[]
        for li,ln,els,elapsed in reversed(self.layers_at(name,frame)):
            self.clock.append(elapsed)
            chunks.append(self.elements_to_svg(els,name,ct))
            self.clock.pop()
        self.definitions.append('<g id="'+aid+'">'+''.join(chunks)+'</g>')
        return '<use href="#'+aid+'"/>'
    def element_to_svg(self,e,where,ct=X.CT_IDENTITY):
        e=copy.deepcopy(e)
        if tag(e)=='DOMSymbolInstance':
            frame=self.childframe(e,self.clock[-1] if self.clock else 0)
            e.set('firstFrame',str(frame));e.set('loop','single frame')
        if e.get('blendMode')=='add':
            e.set('blendMode','screen');self.approximations.add('Flash add mapped to SVG screen')
        return super().element_to_svg(e,where,ct)
    def filters_to_attr(self,filt,where):
        if filt is None or not len(filt):return ''
        key=E.tostring(filt,encoding='unicode')
        if key in self.filtercache:return self.filtercache[key]
        ops=[];last='SourceGraphic';idx=0
        for fl in filt:
            kind=tag(fl);idx+=1;r='r'+str(idx)
            bx=float(fl.get('blurX',4))/4;by=float(fl.get('blurY',4))/4
            if kind=='BlurFilter':
                ops.append(f'<feGaussianBlur in="{last}" stdDeviation="{bx} {by}" result="{r}"/>');last=r
            elif kind=='GlowFilter':
                color=fl.get('color','#ff0000');strength=float(fl.get('strength',1));alpha=min(1,float(fl.get('alpha',1))*strength)
                ops.append(f'<feGaussianBlur in="{last}" stdDeviation="{bx} {by}" result="b{idx}"/><feFlood flood-color="{color}" flood-opacity="{alpha}" result="c{idx}"/><feComposite in="c{idx}" in2="b{idx}" operator="in" result="g{idx}"/><feMerge result="{r}"><feMergeNode in="g{idx}"/><feMergeNode in="{last}"/></feMerge>');last=r
                if fl.get('inner')=='true' or fl.get('knockout')=='true':self.approximations.add('Inner/knockout glow approximated as outer glow')
            elif kind=='AdjustColorFilter':
                hue=float(fl.get('hue',0));sat=1+float(fl.get('saturation',0))/100
                if hue:ops.append(f'<feColorMatrix in="{last}" type="hueRotate" values="{hue}" result="{r}h"/>');last=r+'h'
                if sat!=1:ops.append(f'<feColorMatrix in="{last}" type="saturate" values="{sat}" result="{r}s"/>');last=r+'s'
                if float(fl.get('contrast',0)) or float(fl.get('brightness',0)):self.approximations.add('Brightness/contrast color adjustment omitted')
            elif kind=='GradientBevelFilter':self.approximations.add('Flash GradientBevel fine edge lighting omitted; vector fills retained')
            else:self.approximations.add('Filter omitted: '+kind)
        if not ops:result=''
        else:
            fid=self.prefix+'f'+str(len(self.filtercache));self.definitions.append(f'<filter id="{fid}" x="-90%" y="-90%" width="280%" height="280%" color-interpolation-filters="sRGB">'+''.join(ops)+'</filter>');result=f' filter="url(#{fid})"'
        self.filtercache[key]=result;return result

def instance_asset(r,e,elapsed):
    # Keep transforms outside each cached asset; all nested timeline art remains vector.
    e=copy.deepcopy(e);mm=matrix(e);p=e.find('./x:matrix',NS)
    if p is not None:e.remove(p)
    e.set('firstFrame',str(r.childframe(e,elapsed)));e.set('loop','single frame')
    sig=E.tostring(e,encoding='unicode')
    if sig not in r.instance_cache:
        aid=r.prefix+'i'+str(len(r.instance_cache));r.instance_cache[sig]=aid
        r.clock.append(0);body=r.element_to_svg(e,'instance');r.clock.pop()
        r.definitions.append(f'<g id="{aid}">{body}</g>')
    return r.instance_cache[sig],mm

def body_elements(r,name,frame,parent,order=()):
    result=[]
    for li,ln,els,elapsed in reversed(r.layers_at(name,frame)):
        for ei,e in enumerate(els):
            if tag(e)!='DOMSymbolInstance':continue
            ref=e.get('libraryItemName');mm=M(parent,matrix(e))
            if ref.endswith('/起身'):
                result+=body_elements(r,ref,r.childframe(e,elapsed),mm,order+(li,ei));continue
            aid,_=instance_asset(r,e,elapsed)
            result.append({'aid':aid,'matrix':mm,'part':ref.split('/')[-1],'ref':ref,'layer':li,'order':list(order)+( [li,ei])})
    return result

def lift(f):
    if f<94:return 0
    if f<121:
        t=(f-94)/27;return -208.95*t*t*(3-2*t)
    if f<151:return -208.95
    if f<159:return -208.95*(1-((f-150)/9)**2)
    return 0

def main():
    r=MotionRenderer(ROOT/'source/nirvana-library','nv');r.instance_cache={}
    d=MotionRenderer(ROOT/'source/down-library','dn');d.instance_cache={}
    root=translation(409.1,177.8);frames=[]
    for f in range(182):
        body=[];back=[];front=[];native=[]
        for li,ln,els,elapsed in reversed(r.layers_at(PREFIX+'转阶段动画',f)):
            if ln=='人物动画':
                for e in els:
                    if tag(e)!='DOMSymbolInstance':continue
                    if e.get('libraryItemName').endswith('/起身'):
                        body+=body_elements(r,e.get('libraryItemName'),r.childframe(e,elapsed),M(root,matrix(e)))
                    else:
                        aid,mm=instance_asset(r,e,elapsed);body.append({'aid':aid,'matrix':M(root,mm),'part':e.get('libraryItemName').split('/')[-1],'ref':e.get('libraryItemName'),'layer':li})
                native+=body
            else:
                for e in els:
                    if tag(e)!='DOMSymbolInstance':continue
                    aid,mm=instance_asset(r,e,elapsed);draw={'aid':aid,'matrix':M(root,mm),'part':e.get('libraryItemName').split('/')[-1]}
                    native.append(draw)
                    if ln=='影子':continue
                    (front if li<8 else back).append(draw)
        frames.append({'body':body,'back':back,'front':front,'native':native,'lift':lift(f+1) if f>=81 else 0})
    down=[body_elements(d,'Symbol 556',f,root) for f in range(30)]
    charge=[]
    for f in range(32):
        aid=r.render_symbol('Codex/火凤转阶段/蓄焰',f,'charge').split('#')[1].split('"')[0]
        charge.append(aid)
    aura=[]
    for f in range(r.duration(PREFIX+'1.特效文件夹/03.赤橙色系/火焰与爆炸/余烬重生/火凤余烬')):
        aura.append(r.render_symbol(PREFIX+'1.特效文件夹/03.赤橙色系/火焰与爆炸/余烬重生/火凤余烬',f,'aura').split('#')[1].split('"')[0])
    # Prefix geometry reader gradient IDs independently for the two libraries.
    all_defs=[]
    for obj in [r,d]:
        defs=''.join(obj.defs+obj.definitions)
        import re
        defs=re.sub(r'(id=")((?:d|fl|g)\d+)(")',lambda m:m[1]+obj.prefix+m[2]+m[3],defs)
        defs=re.sub(r'url\(#((?:d|fl|g)\d+)\)',lambda m:'url(#'+obj.prefix+m[1]+')',defs)
        all_defs.append(defs)
    (ROOT/'source/nirvana-defs.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg"><defs>'+''.join(all_defs)+'</defs></svg>',encoding='utf8')
    data={'frames':frames,'down':down,'charge':charge,'aura':aura,'fps':30,'rootMatrix':root,'approximations':sorted(r.approximations|d.approximations),'notes':['No AS2, damage, healing, buff or revive-coin logic executed.','Classic transform/alpha tween and nested graphic playheads sampled at 30fps.','Vertical travel follows the frozen PhoenixPhaseController, 208.95px apex.']}
    (ROOT/'source/nirvana-snapshot.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),encoding='utf8')
    print(json.dumps({'sourceFrames':len(frames),'downFrames':len(down),'SVGDefinitionBytes':sum(map(len,all_defs)),'symbols':len(r.symbols)+len(d.symbols),'approximations':data['approximations']},ensure_ascii=False))

if __name__=='__main__':main()
