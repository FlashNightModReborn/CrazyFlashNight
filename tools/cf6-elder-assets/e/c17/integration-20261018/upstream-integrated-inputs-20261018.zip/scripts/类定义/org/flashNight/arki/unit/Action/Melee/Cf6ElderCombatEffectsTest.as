﻿import org.flashNight.arki.unit.UnitComponent.Status.ImpactStateHandler;
import org.flashNight.arki.component.Buff.BuffManager;
import org.flashNight.arki.component.Buff.Effect.ElderBeamVulnerability;
import org.flashNight.arki.component.Buff.Effect.FireControlVulnerability;
import org.flashNight.arki.component.Damage.*;
import org.flashNight.arki.component.Shield.*;
import org.flashNight.arki.bullet.BulletComponent.Queue.BulletQueueProcessor;
import org.flashNight.arki.bullet.BulletComponent.Queue.BulletHitEffectRegistry;
import org.flashNight.naki.RandomNumberEngine.PinkNoiseEngine;

/** Real emitted action declarations pass through settlement, BuffManager and shield implementations. */
class org.flashNight.arki.unit.Action.Melee.Cf6ElderCombatEffectsTest {
    private static var samples:Object;
    private static var passed:Number,failed:Number,serial:Number;
    private static function check(ok:Boolean,label:String):Void {
        if(ok)passed++;else{failed++;trace("[TEST_FAIL] Cf6ElderCombatEffectsTest: "+label);}
    }
    private static function near(a:Number,b:Number):Boolean {return Math.abs(a-b)<0.00001;}
    public static function reset():Void {samples={};passed=failed=serial=0;}
    public static function capture(action:String,data:Object,actor:MovieClip):Void {
        if(samples[action]==undefined)samples[action]={data:data,actor:actor};
    }
    private static function target():MovieClip {
        var t:MovieClip=_root.cf6MakePlayerTarget(_root.gameworld,"effectTarget"+(++serial),175);
        t.buffManager=new BuffManager(t,{});t.createEmptyMovieClip("man",2);
        return t;
    }
    private static function bullet(action:String):Object {
        var result:Object={};for(var key:String in samples[action].data)result[key]=samples[action].data[key];
        result.固伤=0;result.flags=256;result.hitCount=0;result.damageManager=DamageManagerFactory.resolveForBullet(result);
        return result;
    }
    private static function settle(data:Object,actor:MovieClip,t:MovieClip,miss:Boolean):Object {
        actor.dispatcher={publish:function():Void {}};
        var queue:Object=BulletQueueProcessor;
        // Suppress only number rendering; calculation, actual-hit classification and callbacks are production.
        var impact:Object=DamageResult.getIMPACT();var display:Function=impact.triggerDisplay;
        impact.triggerDisplay=function(x:Number,y:Number,name:String):Void {};
        var context:Object={bullet:data,shooter:actor,Damage:DamageCalculator,flags:256,meleeMask:768};
        var result:Object=queue.settleHit(context,t,{overlapCenter:{x:t._x,y:t._y}},1,miss?"躲闪":"未躲闪",true);
        impact.triggerDisplay=display;
        return result;
    }
    public static function runAllTests(nativeKnockback:Function):Boolean {
        if(DamageManagerFactory.Basic==null)DamageManagerFactory.init();PinkNoiseEngine.getInstance();
        check(samples.beam!=undefined && samples.kicks!=undefined && samples.slam!=undefined && samples.heavyBeam!=undefined,"all four emitted robot actions captured");
        if(failed>0)return false;
        var actor:MovieClip=samples.kicks.actor;
        var originalShieldLevel:Number=actor.等级;actor.等级=99;
        actor.shield=AdaptiveShield.createDormant("melee-reward-fixture");actor.shield.setOwner(actor);
        var foreign:Shield=Shield.createTemporary(7,1,300,"foreign");actor.shield.addShield(foreign);
        var t:MovieClip=target(),data:Object=bullet("kicks"),before:Number=t.hp;
        settle(data,actor,t,true);
        check(t.hp==before && t.hp满血值==100000 && actor.shield.getShieldCount()==1,"MISS neither crumbles nor rewards shield");
        settle(data,actor,t,false);
        check(t.hp满血值==99500 && t.hp<before && t.损伤值>=500 && before-t.hp>=500,"actual punch uses 0.5 percent paired crumble");
        var first:Number=actor.elderMeleeShield,shield:IShield=actor.shield.getShieldById(first);
        check(first>=0 && near(shield.getCapacity(),200) && near(shield.getStrength(),18),"actual melee earns calibrated temporary shield");
        check(shield.absorbDamage(100,false,1)==82 && near(shield.getCapacity(),182),"reward shield absorbs a bounded per-hit amount");
        settle(data,actor,t,false);
        check(actor.elderMeleeShield==first && actor.shield.getShieldCount()==2,"same contact cannot stack reward across targets");
        data=bullet("kicks");settle(data,actor,t,false);
        check(actor.elderMeleeShield!=first && actor.shield.getShieldById(first)==null && actor.shield.getShieldCount()==2
            && actor.shield.getShieldById(foreign.getId())!=null,"new contact refreshes only owned shield");
        first=actor.elderMeleeShield;actor.shield.update(59);
        check(actor.shield.getShieldById(first)!=null,"shield lives through 59 frames");actor.shield.update(1);
        check(actor.shield.getShieldById(first)==null && actor.shield.getShieldById(foreign.getId())!=null,"shield expires at 60 without deleting foreign shield");
        actor.等级=1;data=bullet("kicks");settle(data,actor,t,false);
        shield=actor.shield.getShieldById(actor.elderMeleeShield);
        check(near(shield.getStrength(),45) && near(shield.getCapacity(),200),"level-one melee shield uses the low endpoint");
        check(shield.absorbDamage(100,false,1)==55 && near(shield.getCapacity(),155),"low-level reward shield applies its calibrated per-hit absorption");
        first=actor.elderMeleeShield;actor.shield.update(119);
        check(actor.shield.getShieldById(first)!=null,"level-one melee shield retains its longer coverage through frame 119");
        actor.shield.update(1);
        check(actor.shield.getShieldById(first)==null && actor.shield.getShieldById(foreign.getId())!=null,"level-one melee shield expires at 120 without touching foreign shield");
        actor.等级=50;data=bullet("kicks");settle(data,actor,t,false);
        first=actor.elderMeleeShield;shield=actor.shield.getShieldById(first);
        check(near(shield.getStrength(),31.5) && near(shield.getCapacity(),200),"middle-level reward uses the interpolated shield strength");
        actor.shield.update(89);check(actor.shield.getShieldById(first)!=null,"middle-level shield retains frame 89");
        actor.shield.update(1);check(actor.shield.getShieldById(first)==null && actor.shield.getShieldById(foreign.getId())!=null,"middle-level shield expires at 90 and preserves foreign shield");
        _root.护盾函数.移除护盾(actor,actor.elderMeleeShield);actor.elderMeleeShield=-1;
        actor.等级=Number("bad");actor.elderRewardMelee(t,"kicks");
        check(actor.shield.getShieldCount()==1 && actor.elderMeleeShield==-1,"invalid level cannot create an infinite-strength fallback shield");
        actor.等级=originalShieldLevel;
        var identity:Object=actor.elderIdentity;actor.elderIdentity={};data=bullet("kicks");settle(data,actor,t,false);
        check(actor.shield.getShieldCount()==1,"stale shooter identity cannot reward replacement");actor.elderIdentity=identity;
        t.removeMovieClip();

        t=target();data=bullet("beam");actor=samples.beam.actor;before=t.hp;
        var beamHitsBefore:Number=actor.elderCombatStats.beamHits,beamPowerBefore:Number=actor.elderCombatStats.beamHitPower;
        settle(data,actor,t,true);
        check(t.hp==before && t.buffManager.getBuffById(ElderBeamVulnerability.ID)==null && actor.elderCombatStats.beamHits==beamHitsBefore,"missed red beam gives no vulnerability or actual-hit credit");
        settle(data,actor,t,false);
        check(t.hp<before && data.伤害类型=="魔法" && data.魔法伤害属性=="波" && data.子弹威力==300 && actor.elderCombatStats.beamHits==beamHitsBefore+1 && actor.elderCombatStats.beamHitPower==beamPowerBefore+3,"primer keeps authored wave damage and records actual contact");
        check(near(t.damageTakenMultiplier,1.25) && near(t.ti61CrumbleTakenMultiplier,1.25),"primer raises damage and crumble by 25 percent");
        t.buffManager.update(90);check(near(t.damageTakenMultiplier,1.125),"six-second vulnerability decays linearly at midpoint");
        ElderBeamVulnerability.applyToTarget(t,{peak:0.25,durationFrames:180});ElderBeamVulnerability.applyToTarget(t,{peak:0.25,durationFrames:180});
        check(near(t.damageTakenMultiplier,1.25),"multiple casters and repeat hits refresh without stacking");
        t.损伤值=0;var crumble:Object={击溃:0.5,子弹威力:100,additionalEffectDamage:0};
        CrumbleDamageHandle.instance.handleBulletDamage(crumble,{},t,{},DamageResult.getIMPACT());
        check(t.hp满血值==99375 && t.损伤值==625,"marked target takes enhanced real crumble");
        t.buffManager.update(180);check(near(t.damageTakenMultiplier,1) && near(t.ti61CrumbleTakenMultiplier,1),"expiry restores both multipliers");
        check(!actor.elderHasBeamMark(t),"zero remaining time cannot authorize heavy beam during deferred node cleanup");
        check(!ElderBeamVulnerability.applyToTarget(t,{peak:0.26,durationFrames:180})
            && !ElderBeamVulnerability.applyToTarget(t,{peak:0.25,durationFrames:30}),"invalid effect contracts rejected");
        check(!BulletHitEffectRegistry.apply(bullet("beam"),actor,t,{dodgeStatus:"HIT",scatterModelEnabled:true,actualScatterUsed:2,scatterMissCount:2}),"all-MISS scatter cannot apply mark");
        ElderBeamVulnerability.applyToTarget(t,{peak:0.25,durationFrames:180});t.hp=0;t.buffManager.update(1);
        check(!actor.elderHasBeamMark(t) && near(t.damageTakenMultiplier,1),"death immediately disables mark and effect");
        // MetaBuff first ejects its Pods, then retires its registered node on maintenance updates.
        for(var cleanupPass:Number=0;cleanupPass<3;cleanupPass++)t.buffManager.update(0);
        check(t.buffManager.getBuffById(ElderBeamVulnerability.ID)==null,"expired node finishes the normal cleanup transaction");
        t.hp=t.hp满血值=100000;
        check(FireControlVulnerability.applyToTarget(t,{peak:0.75,durationFrames:30}) && near(t.damageTakenMultiplier,1.75),"Titanium 171 retains independent 75-percent one-second contract");
        t.buffManager.update(30);check(near(t.damageTakenMultiplier,1),"Titanium 171 still expires at 30 frames");
        t.removeMovieClip();

        t=target();actor=samples.slam.actor;actor.shield=AdaptiveShield.createDormant("slam-shield");actor.shield.setOwner(actor);
        var originalClock:Number=actor.elderClock;
        t._x=actor._x+(actor.方向=="左"?-180:180);t._y=t.Z轴坐标=actor.Z轴坐标;
        t.刚体=true;t.免疫击退=t.浮空=t.倒地=t.硬直中=false;t.韧性系数=0;t.remainingImpactForce=0;
        t.移动钝感硬直=t.状态改变=function():Void {};
        t.移动=function(direction:String,speed:Number):Void {this._x+=direction=="右"?speed:-speed;};
        t.被击移动=nativeKnockback;
        data=bullet("slam");var impactResult:Object=settle(data,actor,t,false);
        var impact:MovieClip=_root.gameworld.createEmptyMovieClip("actualSlamImpact",_root.gameworld.getNextHighestDepth());
        for(var key:String in data)impact[key]=data[key];impact.破坏力=data.子弹威力;
        ImpactStateHandler.handleImpactState(t,impact,DamageResult(impactResult),actor.方向,true);
        check(t.speed==18 && t.减速度==0.5,"actual stagger route applies strong grounded knockback");
        for(var step:Number=0;step<40;step++)if(t.speed>0)t.onEnterFrame();
        var distance:Number=Math.abs(t._x-actor._x);actor.elderClock+=40;
        check(near(distance,495) && actor.elderComboReady(t,distance,0,0),"actual 180-to-495 knockback remains in the beam combo window");
        actor.攻击目标=t._name;actor.elderNextHeavyBeam=0;
        ElderBeamVulnerability.applyToTarget(t,{peak:0.25,durationFrames:180});
        check(actor.elderChooseAttack(distance,0,0,true)=="heavyBeam","marked displaced target selects heavy follow-up");
        actor.elderClock=originalClock;actor.攻击目标="无";impact.removeMovieClip();
        check(data.斩杀==10 && data.水平击退速度==18 && data.垂直击退速度==0,"slam declares execute and grounded strong knockback");
        check(actor.elderCombo.target==t._name && actor.elderCombo.identity===t.__elderActionIdentity,"only actual slam hit arms target-bound beam combo");
        var killed:MovieClip=target();killed.hp=5000;data=bullet("slam");settle(data,actor,killed,false);
        check(killed.hp==0,"real execute handler finishes a target below ten percent");killed.removeMovieClip();t.removeMovieClip();

        t=target();actor=samples.heavyBeam.actor;data=bullet("heavyBeam");before=t.hp;
        var heavyHitsBefore:Number=actor.elderCombatStats.heavyBeamHits,heavyPowerBefore:Number=actor.elderCombatStats.heavyBeamHitPower;
        settle(data,actor,t,false);
        check(data.子弹威力==50 && data.伤害类型=="魔法" && data.魔法伤害属性=="波" && t.hp<before && actor.elderCombatStats.heavyBeamHits==heavyHitsBefore+1 && actor.elderCombatStats.heavyBeamHitPower==heavyPowerBefore+0.5,"continuous heavy beam starts with half power and records actual contact");
        check(t.buffManager.getBuffById(ElderBeamVulnerability.ID)==null,"heavy beam cannot grant its own prerequisite");t.removeMovieClip();
        actor=samples.beam.actor;actor.状态="空手攻击";
        actor.shield=AdaptiveShield.createDormant("beam-shield-fixture");actor.shield.setOwner(actor);
        foreign=Shield.createTemporary(7,1,300,"foreign");actor.shield.addShield(foreign);
        actor.elderBeginAttack(actor.man,"beam");first=actor.elderBeamShield;shield=actor.shield.getShieldById(first);
        check(first>=0 && near(shield.getCapacity(),200) && shield.getStrength()==75,"beam action owns a bounded charging shield");
        check(shield.absorbDamage(100,false,1)==25 && near(shield.getCapacity(),125),"charging shield absorbs only its per-hit budget");
        actor.elderBeginAttack(actor.man,"beam");
        check(actor.elderBeamShield!=first && actor.shield.getShieldById(first)==null && actor.shield.getShieldCount()==2,"new beam replaces only its own shield");
        first=actor.elderBeamShield;actor.shield.update(43);
        check(actor.shield.getShieldById(first)!=null,"charging shield survives through frame 43 during recovery");actor.shield.update(1);
        check(actor.shield.getShieldById(first)==null && actor.shield.getShieldById(foreign.getId())!=null,"charging shield expires at frame 44 without deleting foreign shield");
        var shieldAttack:Number=actor.空手攻击力,shieldHp:Number=actor.hp满血值;
        actor.空手攻击力=2000;actor.hp满血值=10000;
        actor.elderBeginAttack(actor.man,"beam");shield=actor.shield.getShieldById(actor.elderBeamShield);
        check(shield.getStrength()==800 && near(shield.getCapacity(),2000),"high attack cannot exceed the fixed beam shield strength cap");
        check(shield.absorbDamage(1000,false,1)==200 && near(shield.getCapacity(),1200),"large hits penetrate the capped beam shield");
        actor.elderCancelAttack();actor.空手攻击力=shieldAttack;actor.hp满血值=shieldHp;
        var beamLevel:Number=actor.等级,beamLevels:Array=[30,60,99],beamCaps:Array=[240,150,12000/119];
        for(var beamIndex:Number=0;beamIndex<beamLevels.length;beamIndex++){
            actor.等级=beamLevels[beamIndex];actor.elderBeginAttack(actor.man,"beam");
            shield=actor.shield.getShieldById(actor.elderBeamShield);
            check(near(shield.getCapacity(),beamCaps[beamIndex]) && shield.getStrength()==75,"level-dependent beam capacity "+beamLevels[beamIndex]);
            actor.elderCancelAttack();
        }
        actor.等级=Number("bad");actor.elderBeginAttack(actor.man,"beam");
        check(actor.elderBeamShield==-1 && actor.shield.getShieldCount()==1,"invalid beam level cannot grant a fallback shield");
        actor.elderCancelAttack();actor.等级=beamLevel;
        actor.elderBeginAttack(actor.man,"beam");
        check(actor.elderNextBeam==actor.elderClock+80,"ordinary beam schedules the calibrated eighty-frame interval");
        actor.elderCancelAttack();
        actor.elderBeginAttack(actor.man,"beam");first=actor.elderBeamShield;actor.elderCancelAttack();
        check(actor.shield.getShieldById(first)==null && actor.shield.getShieldById(foreign.getId())!=null,"interruption removes only owned charging shield");
        trace("Cf6ElderCombatEffectsTest: "+passed+" passed, "+failed+" failed");return failed==0;
    }
}
