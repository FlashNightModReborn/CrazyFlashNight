﻿
_root.cheatFunction = new Object();

// ============================================================
// 作弊开关容器
// ------------------------------------------------------------
// 所有作弊"状态"只挂在这个二级容器下，不再往 _root 一级塞新属性
// （_root 上已经挂了太多东西）。_root 一级因此只多 cheatFlags 一个引用。
// 容器内的开关都是本次游戏有效、不进存档。
// ============================================================
if (_root.cheatFlags == undefined) _root.cheatFlags = new Object();

// 强制显示任务限定 NPC：true 时 _root.初始化NPC 不再用任务需求 / 任务需求支线 挡人。
_root.cheatFlags.强制显示NPC = false;

_root.cheatFunction.hardmode = function(){
	_root.difficultyMode = 0;
	_root.最上层发布文字提示("更改为困难模式！");
	_root.修改工具按钮._visible = true;
}
_root.cheatFunction.easymode = function(){
	_root.difficultyMode = 1;
	_root.最上层发布文字提示("更改为简单模式！");
	_root.修改工具按钮._visible = true;
}
_root.cheatFunction.challengemode = function(){
	_root.difficultyMode = 2;
	_root.最上层发布文字提示("更改为挑战模式！");
	_root.修改工具按钮._visible = false;
}

_root.cheatFunction.test = function(){
	if(!_root.调试模式){
		_root.调试模式 = true;
		_root.最上层发布文字提示("调试模式开启！");
	}else{
		_root.调试模式 = false;
		_root.最上层发布文字提示("调试模式关闭！");
	}
}

_root.cheatFunction.add1 = function(){
	var add1僵尸兵种 = "敌人-光头军人僵尸1";
	var add1僵尸等级 = 1;
	var add1僵尸名字 = "僵尸";
	var add1僵尸是否为敌人 = true;
	var add1僵尸身高 = 175;
	var add1僵尸僵尸型敌人newname = this._name + 兵种;

	var hero:MovieClip = TargetCacheManager.findHero();
	_root.加载游戏世界人物(add1僵尸兵种,add1僵尸僵尸型敌人newname,_root.gameworld.getNextHighestDepth(),{_x: hero._x ,_y:hero._y,等级:add1僵尸等级,名字:add1僵尸名字,是否为敌人:add1僵尸是否为敌人,身高:add1僵尸身高,产生源:null});
	_root.最上层发布文字提示("添加一个僵尸！");
}

_root.cheatFunction.ultrarapidfire = function(){
	for(var key in _root.技能表对象){
		_root.技能表对象[key].MaxLevel = 99;
		if(_root.技能表对象[key].CD > 1000){
			_root.技能表对象[key].CD = 1000;
		}
	}for (var i = 1; i < 13; i++){
		var 当前技能栏 = _root.玩家信息界面.快捷技能界面["快捷技能栏" + i];
		if(当前技能栏.冷却时间 > 1000){
			当前技能栏.冷却时间 = 1000;
		}
	}
	_root.玩家信息界面.刷新技能等级显示();
	_root.最上层发布文字提示("无限火力开启！");
	_root.发布消息("开启无限火力模式，所有技能的升级上限提升至99级，cd降低为1秒。部分技能可能产生bug。退出游戏后技能cd恢复正常。");
}
_root.cheatFunction.fire = _root.cheatFunction.ultrarapidfire;

_root.cheatFunction.getallmods = function(){
	var modlist = org.flashNight.arki.item.EquipmentUtil.modList;
	var acarr = [];
	for(var i=0; i<modlist.length; i++){
		acarr.push({name:modlist[i], value:1});
	}
	org.flashNight.arki.item.ItemUtil.acquire(acarr,
		{source:"cheat", reason:"cheat_grant"});
	_root.最上层发布文字提示("获得所有配件材料各1个");
}

_root.cheatFunction.getallintelligence = function(){
	var intelligenceDict = org.flashNight.arki.item.ItemUtil.informationMaxValueDict;
	var acarr = [];
	for(var name in intelligenceDict){
		var maxValue = intelligenceDict[name]; // 获取该情报的最大值
		acarr.push({name: name, value: maxValue});
	}
	org.flashNight.arki.item.ItemUtil.acquire(acarr,
		{source:"cheat", reason:"cheat_grant"});
	_root.最上层发布文字提示("获得所有情报(满额)");
}

_root.cheatFunction.unlockkills = function(){
	if(_root.兵种库 == undefined){
		_root.最上层发布文字提示("兵种库未加载，无法解锁击杀记录");
		return;
	}
	if(_root.killStats == undefined){
		_root.killStats = {total:0, byType:{}};
	}
	if(_root.killStats.byType == undefined){
		_root.killStats.byType = {};
	}

	var map:Object = _root.killStats.byType;
	var seen:Object = {};
	var scanned:Number = 0;
	var added:Number = 0;

	for(var unitType in _root.兵种库){
		var attr:Object = _root.兵种库[unitType];
		if(attr == undefined || attr.是否为敌人 != true) continue;
		var spriteName:String = (attr.兵种名 == undefined) ? "" : String(attr.兵种名);
		if(spriteName == "" || seen[spriteName] == true) continue;

		seen[spriteName] = true;
		scanned++;

		var oldCount:Number = Number(map[spriteName]);
		if(isNaN(oldCount) || oldCount <= 0){
			map[spriteName] = 1;
			added++;
		}
	}

	var total:Number = Number(_root.killStats.total);
	if(isNaN(total) || total < 0) total = 0;
	_root.killStats.total = total + added;
	if(_root.存档系统 != undefined){
		_root.存档系统.dirtyMark = true;
	}

	_root.最上层发布文字提示("已解锁敌方击杀记录：" + scanned + "种，新增" + added + "种。重新打开竞技场面板生效。");
}
_root.cheatFunction.unlockallenemies = _root.cheatFunction.unlockkills;
_root.cheatFunction.arenakills = _root.cheatFunction.unlockkills;

// ============================================================
// A. 查询类命令
// ============================================================

_root.cheatFunction.status = function() {
	var hero:MovieClip = TargetCacheManager.findHero();
	var lines:Array = [];
	lines.push("=== 玩家状态 ===");
	lines.push("等级: " + _root.等级 + " | 经验: " + _root.经验值 + "/" + _root.升级需要经验值);
	if (hero != undefined) {
		lines.push("HP: " + hero.hp + "/" + hero.hp满血值 + " | MP: " + hero.mp + "/" + hero.mp满血值);
		lines.push("坐标: (" + Math.round(hero._x) + ", " + Math.round(hero._y) + ")");
		lines.push("攻击力: " + hero.空手攻击力 + " | 防御力: " + hero.防御力);
	}
	lines.push("难度: " + (["困难","简单","挑战"])[_root.difficultyMode]);
	lines.push("调试模式: " + (_root.调试模式 ? "开" : "关"));
	_root.最上层发布文字提示(lines.join("\n"));
};

_root.cheatFunction.scene = function() {
	var lines:Array = [];
	lines.push("=== 场景信息 ===");
	lines.push("当前关卡: " + _root.当前通关的关卡);
	lines.push("地图帧值: " + _root.关卡地图帧值);
	if (_root.gameworld != undefined) {
		lines.push("gameworld: " + _root.gameworld);
	}
	_root.最上层发布文字提示(lines.join("\n"));
};

// ============================================================
// B. 状态修改类命令
// ============================================================

_root.cheatFunction.god = function() {
	if (!_root._godMode) {
		_root._godMode = true;
		var hero:MovieClip = TargetCacheManager.findHero();
		if (hero != undefined) {
			hero.hp = hero.hp满血值;
			hero.mp = hero.mp满血值;
		}
		_root._godInterval = setInterval(function() {
			var h:MovieClip = TargetCacheManager.findHero();
			if (h != undefined) {
				h.hp = h.hp满血值;
				h.mp = h.mp满血值;
			}
		}, 200);
		_root.最上层发布文字提示("无敌模式开启！");
	} else {
		_root._godMode = false;
		clearInterval(_root._godInterval);
		_root.最上层发布文字提示("无敌模式关闭！");
	}
};

_root.cheatFunction.heal = function() {
	var hero:MovieClip = TargetCacheManager.findHero();
	if (hero != undefined) {
		hero.hp = hero.hp满血值;
		hero.mp = hero.mp满血值;
		_root.最上层发布文字提示("HP/MP 已回满！HP:" + hero.hp + " MP:" + hero.mp);
	} else {
		_root.最上层发布文字提示("找不到主角单位");
	}
};

_root.cheatFunction.sp = function() {
	// 通过 cheatCode 的 #sp:数量 语法调用
	_root.最上层发布文字提示("当前技能点: " + _root.技能点数);
};

// ============================================================
// C. 世界控制类命令
// ============================================================

_root.cheatFunction.killall = function() {
	var count:Number = 0;
	for (var name in _root.gameworld) {
		var unit:MovieClip = _root.gameworld[name];
		if (unit.是否为敌人 == true && unit.hp > 0) {
			unit.hp = 0;
			count++;
		}
	}
	_root.最上层发布文字提示("已击杀 " + count + " 个敌人");
};

// ============================================================
// D. 表达式求值类命令（通过 #eval: #get: #set: 前缀触发）
// ============================================================
// 用法详见 cheatCode 函数中新增的分支

// ============================================================
// 系统辨识：开环阶跃响应自动化测试
// ============================================================
//
// 用法：
//   输入 sysid  → 自动执行 3 阶段开环阶跃测试（0→1→0）
//   输入 stopsysid → 中止测试并导出已收集的日志
//
// 原理：
//   forceLevel() 切换性能等级但不创建保护窗口，evaluate() 持续采样；
//   量化器锁定（minLevel = maxLevel = targetLevel）阻止 PID 改变等级，
//   实现开环条件下的阶跃响应数据采集。
//
// 每阶段保持 30 秒（30000ms），总测试时长 ≈ 1.5 分钟。
// 日志包含 EVT_SAMPLE + EVT_PID_DETAIL，标签格式 "OL:from>to"。
// 注：2 档模型后降级为二值辨识（0→1→0），不再等价于旧 4 段辨识。
// ============================================================

// sysid / stopsysid: 系统辨识功能已迁移到 C# PerfDecisionEngine，
// AS2 端的 PerformanceLogger / Kalman / PID 已移除。
// 保留入口提示用户使用新方式。
_root.cheatFunction.sysid = function() {
	_root.最上层发布文字提示("系统辨识已迁移到 C# launcher 端，查看 launcher.log");
};

_root.cheatFunction.stopsysid = function() {
	_root.最上层发布文字提示("系统辨识已迁移到 C# launcher 端");
};

// ============================================================
// 闭环日志：记录正常闭环运行时的性能调度数据
// ============================================================
//
// 用法：
//   输入 cllog    → 开始记录闭环日志（不干预调度逻辑）
//   输入 stopcllog → 停止记录并导出日志
//
// 与 sysid 的区别：
//   sysid  锁定量化器 + 强制等级 = 开环测试
//   cllog  不做任何干预 = 闭环观察
//
// 日志包含 EVT_SAMPLE + EVT_PID_DETAIL + EVT_LEVEL_CHANGED，
// 用于评估迟滞确认、切档频率、极限环等闭环行为。
// ============================================================

// cllog / stopcllog: 闭环日志已迁移到 C# launcher 端（[PerfActive] 标签）
_root.cheatFunction.cllog = function() {
	_root.最上层发布文字提示("闭环日志已迁移到 C# launcher 端，查看 launcher.log [PerfActive]");
};

_root.cheatFunction.stopcllog = function() {
	_root.最上层发布文字提示("闭环日志已迁移到 C# launcher 端");
};

_root._cheatNormalizeTaskChainName = function(chainName:String):String {
	var name:String = String(chainName).split(" ").join("").split("　").join("").split("\t").join("");
	var lower:String = name.toLowerCase();
	if (name == "主" || name == "主线任务" || lower == "main" || lower == "story") return "主线";
	if (name == "铁枪" || name == "铁枪会支线" || lower == "iron" || lower == "ironspear" || lower == "tieqiang") return "铁枪会";
	return name;
};

_root._cheatTaskChainMaxProgress = function(chainName:String):Number {
	var seqArr:Array = TaskUtil.task_in_chains_by_sequence[chainName];
	if (seqArr == undefined) return 0;
	var maxProgress:Number = 0;
	for (var i:Number = 0; i < seqArr.length; i++) {
		var seq:Number = Number(seqArr[i]);
		if (!isNaN(seq) && seq > maxProgress) maxProgress = seq;
	}
	return maxProgress;
};

_root._cheatRemoveActiveTasksInChain = function(chainName:String):Number {
	if (_root.tasks_to_do == undefined) return 0;
	var removed:Number = 0;
	for (var i:Number = _root.tasks_to_do.length - 1; i > -1; i--) {
		var taskID = _root.tasks_to_do[i].id;
		var taskData:Object = TaskUtil.getRawTaskData(taskID);
		if (taskData != undefined && taskData.chain != undefined && taskData.chain[0] == chainName) {
			_root.tasks_to_do.splice(i, 1);
			removed++;
		}
	}
	return removed;
};

_root._cheatSetTaskChainProgress = function(rawChainName:String, rawProgress:Number):Boolean {
	if (TaskUtil.task_chains == undefined || TaskUtil.task_in_chains_by_sequence == undefined) {
		_root.最上层发布文字提示("任务数据未加载，无法调整任务进度");
		return false;
	}

	var chainName:String = _root._cheatNormalizeTaskChainName(rawChainName);
	var chainObj:Object = TaskUtil.task_chains[chainName];
	var seqArr:Array = TaskUtil.task_in_chains_by_sequence[chainName];
	if (chainObj == undefined || seqArr == undefined) {
		_root.最上层发布文字提示("不存在任务链：" + chainName);
		return false;
	}

	var targetProgress:Number = Math.floor(Number(rawProgress));
	if (isNaN(targetProgress) || targetProgress < 0) targetProgress = 0;
	var maxProgress:Number = _root._cheatTaskChainMaxProgress(chainName);
	if (targetProgress > maxProgress) targetProgress = maxProgress;

	if (_root.tasks_finished == undefined) _root.tasks_finished = {};
	if (_root.task_chains_progress == undefined) _root.task_chains_progress = {};

	var marked:Number = 0;
	var cleared:Number = 0;
	for (var i:Number = 0; i < seqArr.length; i++) {
		var seq:Number = Number(seqArr[i]);
		var taskID = chainObj[seqArr[i]];
		var taskKey:String = String(taskID);
		if (!isNaN(seq) && seq <= targetProgress && targetProgress > 0) {
			_root.tasks_finished[taskKey] = 1;
			marked++;
		} else {
			if (_root.tasks_finished[taskKey] > 0) {
				delete _root.tasks_finished[taskKey];
				cleared++;
			}
		}
	}

	_root.task_chains_progress[chainName] = targetProgress;
	var removed:Number = _root._cheatRemoveActiveTasksInChain(chainName);
	if (typeof _root.UpdateTaskProgress == "function") _root.UpdateTaskProgress();
	if (typeof _root.检查任务数据完整性 == "function") _root.检查任务数据完整性();
	if (typeof _root.是否达成任务检测 == "function") _root.是否达成任务检测();
	if (_root.存档系统 != undefined) _root.存档系统.dirtyMark = true;

	_root.最上层发布文字提示("任务链进度已设置：" + chainName + " = " + targetProgress + "/" + maxProgress + "，完成" + marked + "项，清理" + cleared + "项，移除进行中" + removed + "项");
	return true;
};

_root.cheatFunction.taskprogress = function() {
	if (TaskUtil.task_chains == undefined) {
		_root.最上层发布文字提示("任务数据未加载");
		return;
	}
	var lines:Array = [];
	lines.push("=== 任务链进度 ===");
	for (var chainName in TaskUtil.task_chains) {
		var progress:Number = Number(_root.task_chains_progress[chainName]);
		if (isNaN(progress)) progress = 0;
		lines.push(chainName + ": " + progress + "/" + _root._cheatTaskChainMaxProgress(chainName));
	}
	lines.push("进行中任务: " + (_root.tasks_to_do == undefined ? 0 : _root.tasks_to_do.length));
	_root.最上层发布文字提示(lines.join("\n"));
};
_root.cheatFunction.taskstatus = _root.cheatFunction.taskprogress;

_root.cheatFunction.shownpc = function() {
	_root.cheatFlags.强制显示NPC = !(_root.cheatFlags.强制显示NPC === true);
	_root.最上层发布文字提示("强制显示任务NPC：" + (_root.cheatFlags.强制显示NPC ? "开" : "关") + "-切换场景生效");
};

_root.cheatCode = function(作弊码){
	if(typeof _root.cheatFunction[作弊码] === "function"){
		_root.cheatFunction[作弊码]();
		return;
	}

	var 执行代码;
	if(作弊码.indexOf("#code:")>-1){
		执行代码  = 作弊码.split("#code:")[1];
		_root.发布消息("执行代码："+执行代码);
		//eval(执行代码);
		//_root.发布消息("执行失败！因为as2不支持eval()直接解析，等fs处理吧");
		EvalParser.getPropertyValue(testObj, "user.name");
	}else if(作弊码.indexOf("#_root.")>-1){
		执行代码  = 作弊码.split("#_root.")[1].split("=");
		var 变量名  = 执行代码[0].split(" ").join("");
		var 变量值  = 执行代码[1];
		if(变量值.indexOf(";")>-1){
			var 变量值初始值 = 变量值.split(";");
			变量值=变量值初始值[0];
			var 参数类型 = 变量值初始值[1];
			if(参数类型.indexOf("int")>-1  or 参数类型.indexOf("数")>-1  or 参数类型.indexOf("float")>-1  or 参数类型.indexOf("number")>-1  or 参数类型.indexOf("Number")>-1 ){
				变量值 = Number(变量值);
				_root.发布消息("传入数字型");
			}else if(参数类型.indexOf("bool")>-1  or 参数类型.indexOf("布尔")>-1 ){
				if(变量值=="false" or 变量值=="0" or !变量值){
					变量值 = false;
				}else{
					变量值 = true;
				}
				_root.发布消息("传入布尔型："+变量值);
			}
		}
		_root.发布消息("变更变量：_root."+变量名);
		_root[变量名] = 变量值;
		_root.发布消息("值已变更为:"+变量值);
	}else if(作弊码.indexOf("#func:_root.")>-1){
		执行代码  = 作弊码.split("#func:_root.")[1].split("(");
		var 执行函数  = 执行代码[0].split(" ").join("");
		var 执行参数初始值  = 执行代码[1].split(")");
		var 执行参数  = 执行参数初始值[0];
		var 参数类型  = 执行参数初始值[1];
		_root.发布消息("执行函数：_root."+执行函数+"("+执行参数+")");
		var 执行参数数组 = 执行参数.split(",");
		for(var i=0;i<执行参数数组.length;i++){
			if(执行参数数组.length==1){
				var 前缀="";
			}else{
				前缀=i+1;
				前缀=前缀+":"
			}
			if(参数类型.indexOf(前缀+"int")>-1  or 参数类型.indexOf(前缀+"数")>-1  or 参数类型.indexOf(前缀+"float")>-1  or 参数类型.indexOf(前缀+"num")>-1  or 参数类型.indexOf(前缀+"Num")>-1 ){
				执行参数数组[i] = Number(执行参数数组[i]);
				_root.发布消息("传入数字型:"+执行参数数组[i]);
			}else if(参数类型.indexOf(前缀+"变量")>-1 or 参数类型.indexOf(前缀+"var")>-1){
				if(作弊码.indexOf("_root.")>-1){
					执行参数数组[i] = 执行参数数组[i].split("_root.")[1].split(" ").join("");
				}else{
					执行参数数组[i] = 执行参数数组[i].split(" ").join("");
				}
				_root.发布消息("传入root变量:_root."+执行参数数组[i]);
				执行参数数组[i] = _root[执行参数数组[i]];
			}else if(参数类型.indexOf(前缀+"bool")>-1  or 参数类型.indexOf(前缀+"布尔")>-1 ){
					if(执行参数数组[i]=="false" or 执行参数数组[i]=="0" or !执行参数数组[i]){
						执行参数数组[i] = false;
					}else{
						执行参数数组[i] = true;
					}
					_root.发布消息("传入布尔型："+执行参数数组[i]);
			}
		}
		
		//_root[执行函数](执行参数);
		_root[执行函数].apply(this, 执行参数数组);
		_root.发布消息("执行完毕！");
	}else if(作弊码.indexOf("#change:")>-1){
		执行代码  = 作弊码.split("#change:")[1];
		_root.特殊操作单位 = 执行代码;
		if(_root.特殊操作单位=="false" or _root.特殊操作单位=="0"){
			_root.特殊操作单位="";
		}
		_root.加载我方人物(_root.gameworld.出生地._x,_root.gameworld.出生地._y);
		if(_root.特殊操作单位){
			_root.最上层发布文字提示("当前操作目标变更为："+_root.特殊操作单位+"-切换场景生效");
		}else{
			_root.最上层发布文字提示("当前操作目标恢复！"+"-切换场景生效");
		}
	}else if(作弊码.indexOf("#level:")>-1){
		执行代码  = 作弊码.split("#level:")[1].split(" ").join("");

		_root.等级 = Number(执行代码);
		_root.经验值 = _root.根据等级得升级所需经验(_root.等级-1);
		_root.升级需要经验值 = _root.根据等级得升级所需经验(_root.等级);
		_root.上次升级需要经验值 = _root.等级 > 1 ? _root.根据等级得升级所需经验(_root.等级 - 1) : 0;
		_root.玩家信息界面.刷新经验值显示();
		_root.最上层发布文字提示("当前等级变更为："+_root.等级+",经验值变更为："+_root.经验值+"-切换场景生效");

	}else if(作弊码.indexOf("#eval:")>-1){
		// 表达式求值：#eval:player.stats.attack + 10
		var evalExpr:String = 作弊码.split("#eval:")[1];
		var evaluator:PrattEvaluator = PrattEvaluator.createStandard();
		evaluator.setVariable("root", _root);
		evaluator.setVariable("hero", TargetCacheManager.findHero());
		evaluator.setVariable("gameworld", _root.gameworld);
		var evalResult = evaluator.evaluateSafe(evalExpr, "[eval error]");
		_root.发布消息("eval(" + evalExpr + ") = " + evalResult);
	}else if(作弊码.indexOf("#get:")>-1){
		// 属性读取：#get:等级  或  #get:gameworld.出生地._x
		var getPath:String = 作弊码.split("#get:")[1].split(" ").join("");
		var getResult = EvalParser.getPropertyValue(_root, getPath);
		_root.发布消息("_root." + getPath + " = " + getResult);
	}else if(作弊码.indexOf("#set:")>-1){
		// 属性写入：#set:等级=50
		var setParts:Array = 作弊码.split("#set:")[1].split("=");
		var setPath:String = setParts[0].split(" ").join("");
		var setVal:String = setParts[1];
		// 尝试数字转换
		if (!isNaN(Number(setVal)) && setVal.length > 0) {
			EvalParser.setPropertyValue(_root, setPath, Number(setVal));
		} else if (setVal == "true") {
			EvalParser.setPropertyValue(_root, setPath, true);
		} else if (setVal == "false") {
			EvalParser.setPropertyValue(_root, setPath, false);
		} else {
			EvalParser.setPropertyValue(_root, setPath, setVal);
		}
		_root.发布消息("_root." + setPath + " = " + EvalParser.getPropertyValue(_root, setPath));
	}else if(作弊码.indexOf("#task:")>-1){
		var taskSpec:String = 作弊码.split("#task:")[1];
		taskSpec = taskSpec.split("，").join(",");
		taskSpec = taskSpec.split(";").join(",");
		taskSpec = taskSpec.split("；").join(",");
		var taskParts:Array = taskSpec.split(",");
		if (taskParts.length < 2) {
			_root.最上层发布文字提示("用法：#task:任务链名,进度  例如 #task:主线,13 或 #task:铁枪会,1");
		} else {
			var taskChainName:String = taskParts[0].split(" ").join("").split("　").join("").split("\t").join("");
			var taskProgress:Number = Number(taskParts[1].split(" ").join("").split("　").join("").split("\t").join(""));
			_root._cheatSetTaskChainProgress(taskChainName, taskProgress);
		}
	}else if(作弊码.indexOf("#supplytime:") == 0){
		var supplyText:String = 作弊码.split("#supplytime:")[1]
			.split(" ").join("").split("　").join("").split("\t").join("");
		var supplyMinutes:Number = Number(supplyText);
		if (_root.帧计时器 == undefined
				|| typeof _root.帧计时器.设置在线补给测试分钟 != "function") {
			_root.最上层发布文字提示("在线补给帧计时器尚未就绪");
		} else {
			var supplyResult:Object = _root.帧计时器.设置在线补给测试分钟(supplyMinutes);
			if (supplyResult != null && supplyResult.success === true) {
				_root.最上层发布文字提示("在线补给测试时间已设为 "
					+ supplyResult.minutes + " 分钟（仅影响本次运行的圣诞树）");
			} else {
				_root.最上层发布文字提示("用法：#supplytime:分钟（允许 0 至 1440）");
			}
		}
	}else if(作弊码.indexOf("#time:") == 0){
		var timeText:String = 作弊码.split("#time:")[1]
			.split(" ").join("").split("　").join("").split("\t").join("");
		var timeParts:Array = timeText.split(":");
		var timeHours:Number = Number(timeParts[0]);
		var timeMins:Number = (timeParts.length > 1) ? Number(timeParts[1]) : 0;
		var timeTotal:Number = Math.floor(timeHours * 60 + timeMins);
		if (_root.天气系统 == undefined
				|| typeof _root.天气系统.setSleepTime != "function") {
			_root.最上层发布文字提示("天气系统尚未就绪");
		} else if (isNaN(timeTotal) || timeTotal < 0 || timeTotal > 1439) {
			_root.最上层发布文字提示("用法：#time:小时 或 #time:时:分（0:00 至 23:59）");
		} else {
			_root.天气系统.setSleepTime(timeTotal);
			var displayH:Number = Math.floor(timeTotal / 60);
			var displayM:Number = timeTotal % 60;
			_root.最上层发布文字提示("时间已设为 "
				+ displayH + ":" + (displayM < 10 ? "0" : "") + displayM
				+ "（仅本次运行）");
		}
	}else if(作弊码.indexOf("#gold:")>-1){
		var goldVal:Number = Number(作弊码.split("#gold:")[1].split(" ").join(""));
		var goldBefore:Number = Number(_root.金钱);
		_root.金钱 = goldVal;
		org.flashNight.arki.item.PlayerAssetTransaction.recordCurrencyDeltas(
			goldVal - goldBefore, 0,
			{source:"cheat", reason:"cheat_set_gold", mergeScope:"operation"});
		if (_root.存档系统 != undefined) _root.存档系统.dirtyMark = true;
		_root.最上层发布文字提示("金钱设置为: " + _root.金钱);
	}else if(作弊码.indexOf("#sp:")>-1){
		var spVal:Number = Number(作弊码.split("#sp:")[1].split(" ").join(""));
		_root.技能点数 = spVal;
		_root.最上层发布文字提示("技能点设置为: " + _root.技能点数);
	}else if(作弊码.indexOf("#give:")>-1){
		var giveParts:Array = 作弊码.split("#give:")[1].split(",");
		var giveName:String = giveParts[0];
		var giveCount:Number = (giveParts.length > 1) ? Number(giveParts[1]) : 1;
		org.flashNight.arki.item.ItemUtil.acquire([{name: giveName, value: giveCount}],
			{source:"cheat", reason:"cheat_grant"});
		_root.最上层发布文字提示("获得: " + giveName + " x" + giveCount);
	}else if(作弊码.indexOf("#spawn:")>-1){
		var spawnParts:Array = 作弊码.split("#spawn:")[1].split(",");
		var spawnType:String = spawnParts[0];
		var spawnLevel:Number = (spawnParts.length > 1) ? Number(spawnParts[1]) : 1;
		var hero:MovieClip = TargetCacheManager.findHero();
		var spawnX:Number = (hero != undefined) ? hero._x : 0;
		var spawnY:Number = (hero != undefined) ? hero._y : 0;
		_root.加载游戏世界人物(spawnType, spawnType + "_spawn" + getTimer(), _root.gameworld.getNextHighestDepth(), {_x: spawnX, _y: spawnY, 等级: spawnLevel, 名字: spawnType, 是否为敌人: true, 身高: 175, 产生源: null});
		_root.最上层发布文字提示("召唤: " + spawnType + " Lv." + spawnLevel);
	}else if(作弊码.indexOf("#tp:")>-1){
		var tpParts:Array = 作弊码.split("#tp:")[1].split(",");
		var tpHero:MovieClip = TargetCacheManager.findHero();
		if (tpHero != undefined && tpParts.length >= 2) {
			tpHero._x = Number(tpParts[0]);
			tpHero._y = Number(tpParts[1]);
			_root.最上层发布文字提示("传送到: (" + tpHero._x + ", " + tpHero._y + ")");
		}
	}else if(作弊码.substring(0,2)==".."){
		执行代码  = 作弊码.split("..")[1].split(" ").join("");
		if(!isNaN(Number(执行代码))){
			_root.等级 = Number(执行代码);
			_root.经验值 = _root.根据等级得升级所需经验(_root.等级-1);
			_root.升级需要经验值 = _root.根据等级得升级所需经验(_root.等级);
			_root.上次升级需要经验值 = _root.等级 > 1 ? _root.根据等级得升级所需经验(_root.等级 - 1) : 0;
			_root.玩家信息界面.刷新经验值显示();
			_root.最上层发布文字提示("当前等级变更为："+_root.等级+",经验值变更为："+_root.经验值+"-切换场景生效");
		}

	}
	//_root.发布消息(作弊码.substring(0,2));
}

/*
作弊码语法参考：

=== 快捷命令 ===
test                调试模式开关
easymode            简单模式
hardmode            困难模式
challengemode       挑战模式
status              查看玩家状态（等级/HP/MP/坐标/攻防）
scene               查看场景信息
heal                满血满蓝
god                 无敌模式开关（持续锁血）
killall             击杀所有敌人
add1                召唤一个僵尸
fire                无限火力（技能CD降为1秒）
getallmods          获得所有配件
getallintelligence  获得所有情报
unlockkills         解锁所有敌方兵种击杀记录
unlockallenemies    unlockkills 的别名
arenakills          unlockkills 的别名
taskprogress        查看所有任务链进度
taskstatus          taskprogress 的别名
shownpc             强制显示任务限定NPC（toggle，本次游戏有效）

=== 前缀命令 ===
#level:15           设置等级为15
..15                设置等级的简写
#gold:99999         设置金钱
#sp:99              设置技能点
#give:物品名,数量   给予物品（如 #give:急救包,10）
#spawn:兵种,等级    召唤单位（如 #spawn:敌人-光头军人僵尸1,5）
#tp:100,200         传送到坐标
#change:兵种名      变更操控单位
#task:链名,进度      设置任务链进度（如 #task:主线,13 / #task:铁枪会,1 / #task:铁枪会,0）

=== 变量操作 ===
#_root.变量=值;类型  设置_root变量（如 #_root.abc=123;int）
#get:变量路径        读取属性（如 #get:等级）
#set:路径=值         设置属性（如 #set:等级=50）
#eval:表达式         Pratt求值（如 #eval:hero.hp * 2 + 100）

=== 函数调用 ===
#func:_root.函数(参数);类型

=== 性能测试 ===
sysid / stopsysid   系统辨识开环测试
cllog / stopcllog   闭环性能日志

=== Agent 远程控制 ===
通过 HTTP POST /console 发送命令：
  curl -X POST http://localhost:1192/console -d "command=status"
*/
