# CF6 大头机器人：阶段 7、档次 16

**文档角色**：本角色的源稿、装配、属性与验证入口。用户固定阶段 7、档次 16，并要求同等级稳定击败方舟爪豪，允许将光束设为波属性。其余系数按动作观测及下述适配口径生成。兵种 `470`，显示名“大头机器人”，默认展示等级 40、身高 185。真实可用状态以本轮验证证据为准。

## 唯一源与装配

- 原生编辑源：[Codex大头机器人素材](../../flashswf/arts/new/Codex大头机器人素材/)。导出 `敌人-CF6大头机器人`，由 `things-new.fla` 的第四帧共享锚点装载。
- 冻结源稿：[CF6大头机器人-R3](../../flashswf/arts/new/Codex素材源稿/CF6大头机器人-R3/)，来自用户的 `06-source-and-local.zip`。包含 R3 顶壳和进气口修正、18 个 SVG 分件、时间轴及原作者源代码；本次不执行包内重建脚本，也不新增其外部依赖。
- [archive-origin.json](../../flashswf/arts/new/Codex素材源稿/CF6大头机器人-R3/archive-origin.json) 保存包身份和逐文件 SHA-256。[原作行为证据](../../flashswf/arts/new/Codex素材源稿/CF6大头机器人-R3/reference/cf7-source-evidence.json) 绑定实际读取的 CF6 SWF；原 AS2 的简化反编译结果只作 `.as.txt` 证据，不进入游戏。
- [build.py](build.py) 保留原始深度、仿射矩阵、颜色变换及动作帧数。站立与行走共用 933 的 45 帧悬浮循环；936 双臂光束 18 帧、937 伸缩冲击 37 帧、938 受击 25 帧、951 碎裂死亡 58 帧，共 183 个原稿帧。934 单帧枪臂包装保留原注册。939/940 是连接杆和底盘组合，不是裂纹。
- [vector.py](vector.py) 复用已存在的 Windows WPF 离线矢量交集，将身体与碎片图集裁成实际可见轮廓。原渐变矩阵不变；输出不含运行时遮罩或位图缓存。裁切容差为设计像素 `0.0025`；随后只删除 1/20 像素网格上严格重复、同向共线的顶点。原生光束与闪光直接保留二次曲线。
- [native-manifest.json](native-manifest.json) 记录输入、输出和工程身份。已有工程若偏离记录，生成器拒绝覆盖，不提供强制开关。

外层统一减去原站姿阴影中心的 `0.339094543457` 像素偏移，保留身体离地的悬浮间隙。独立阴影使用原 926 径向渐变，位于 `man` 内部，以世界 Z 接地；站立、攻击、受击及死亡均可跟随阴影开关。原稿每个动作里的漂移阴影不再重复装配。

## 动作与数值

[HeadbotAI.as](HeadbotAI.as) 仅负责本单位的移动、选招和动作时钟。通用 AI 提供仇恨目标。远处先靠近并对齐纵深，距离和纵深使用不同的开始、停止阈值，避免来回抖动。155 像素内、低位目标用伸缩冲击；330 像素内的其他可达目标用光束。手动控制仍委托通用行走入口。

| 动作 | 原稿接触帧 | 每次倍率 | 伤害类型 | CF7 判定 |
|---|---|---|---|---|
| 双臂光束 | 3、11 | 空手攻击力 ×1 | 魔法／波 | 原水平跨度，光束中心上下共 30 像素 |
| 伸缩冲击 | 3、5、8、12 | 空手攻击力 ×1 | 物理 | 原水平跨度，底盘中心上下共 50 像素 |

原作两招均为瞬时物理接触；本次按用户定位将光束改为波属性，伸缩冲击保持物理。适配使用 CF7 区域子弹及 `UniversalDamageHandle` 结算；不复制旧版直接修改玩家 HP 的脚本，不另加远程武器属性。方舟爪豪具有高物理防御，已发布脚本的魔法基础抗性为 `10 + 等级 × 0.2`；波属性走该基础抗性，不将“机械”等标签解释为额外波弱点，亦不绕过闪避、弹开等既有结算。每次动作绑定独立普通对象 token、当前身体和接触帧，拒绝早到、重复、旧动作、硬直及死亡后的判定。所有身体时间轴由私有时钟推进；暂停期间到达的加载事件不消耗伤害，恢复后先完成本帧唯一接触，再继续动作。

受击两分支分别在第 6、12 帧恢复，每支 6 帧。保持原稿悬浮特征：允许水平击退，击倒、倒地、被投映射为短受击，不进入浮空物理；没有额外减伤或永久刚体。HP 耗尽优先进入死亡，即使攻击方要求的是“击倒”状态。标准击杀与 `DeathEventComponent` 仍负责单位死亡事件；身体内部驱动在清理后继续播放 58 帧碎裂，第 58 帧委托标准死亡检测注销。火花、小烟雾只作表现，不产生死亡爆炸伤害。

[balance.py](balance.py) 调用仓库怪物公式生成属性，并更新单位登记和人工固定值台账。[balance-inputs.json](balance-inputs.json) 是完整计算记录。

- 用户固定：阶段 7、档次 16。
- 动作观测：首发前摇均值 2 帧，末发后尾帧均值 16 帧；按现行尾帧权重 0.2 得攻速系数 5。两招平均 3 次接触，每次威力倍率 1；魔法／物理分类系数分别为 2／1，因此属性公式的攻击倍率为 1.5。
- 适配：速度 45–60，速度系数 2；短受击且不击飞为霸体档 4，韧性 100 再加 0.5，合计 4.5。重量 200，装甲/机械/首领抗性沿用现有机械单位口径。
- 成长、高攻低血防、高防低血系数均为 1。对手定位来自用户后续要求，阶段、档次不因对战结果改变。

模板端点为生命 `43531–126280`、空手攻击 `274–742`、基本防御 `192–512`、经验 `3133–19950`。这些是 XML 的最小/最大端点；实际等级属性由游戏加载器决定。光束改为波属性后，攻击面板依公式重新计算；没有沿用物理版面板叠加属性优势。

## 生成与复验

从仓库根执行，PowerShell 先 `chcp.com 65001`：

```powershell
python -X utf8 -B tools/cf6-headbot-assets/balance.py --write
python -X utf8 -B tools/cf6-headbot-assets/build.py --import-approved
python -X utf8 -B tools/cf6-headbot-assets/build.py --check
python -X utf8 -B tools/cf6-headbot-assets/register.py --write
node tools/derive-arena-unit-catalog.js
node tools/derive-arena-unit-catalog.js --check
powershell -File scripts/compile_test.ps1 -Target 'flashswf/arts/new/Codex大头机器人素材/Codex大头机器人素材.xfl' -PublishOnly -VerifySwf 'flashswf/arts/new/Codex大头机器人素材.swf' -TimeoutSeconds 600
# 共享锚点变化时才重编 things-new。
powershell -File scripts/compile_test.ps1 -Target 'flashswf/arts/things-new.fla' -PublishOnly -VerifySwf 'flashswf/arts/things-new.swf' -TimeoutSeconds 600
powershell -File scripts/run-cf6-headbot-asset-tests.ps1
powershell -File scripts/run-cf6-headbot-render-tests.ps1 -Capture
python -X utf8 -B tools/cf6-headbot-assets/decode-native-capture.py <本轮完整trace> <新图片目录>
# 单独查看第 31 帧的碎片散开姿势；保存该轮 trace 后解码。
powershell -File scripts/run-cf6-headbot-render-tests.ps1 -Fragment
python -X utf8 -B tools/cf6-headbot-assets/decode-native-capture.py <碎片trace> <新碎片目录> --fragment
python -X utf8 -B tools/cf6-headbot-assets/verify.py
```

行为测试用真实发布库、隔离的伤害与模板桩，检查双向状态、接触次数和几何、暂停与恢复、打断、防重、移动停步、短受击及标准死亡清理。绘制测试逐一抽取全部 183 个原稿帧，另加三张镜像关键帧；默认只测绘制及非空像素，`-Capture` 另输出 16 张无损像素图，`-Fragment` 单独输出碎片散开的第 31 帧。默认行为等待 600 秒；完整像素导出默认 1800 秒，可显式覆盖。编码器用全部 RGBA 通道确定非零边界，省略透明留白的逐像素读取，但仍完整重建每行。绘制采样不等于完整游戏帧耗时，也不代替低配机器或人类体感验收。

```powershell
node tools/cf6-headbot-assets/arena-plan.js <显式隔离配置.json>
node tools/arena-calibration/run-worker-experiment.js --plan <生成的experiment-plan.json>
python -X utf8 -B tools/cf6-headbot-assets/verify.py --runtime-root <冻结资源工作树>
```

[arena-plan.js](arena-plan.js) 要求显式选择 `physical`／`wave` 版本；默认以方舟爪豪为对手，等级为 30、60、99，双方换位各重复三场，共 18 场。可使用一或两个隔离工作树；两工作树须逐项匹配源码、SWF、属性与独立候选 runtime 身份。小规模试运行可显式缩小等级和重复次数；不能替代完整定位验证。工作判据为全部获胜、无超时，并记录最低剩余血量及战斗帧数；有限重复不能证明所有随机局面必胜。每次执行使用新目录，保留失败、超时和取消记录；关闭后核对真实非目标存档与 SharedObject，不触碰正式发布链。

早期物理版的行为、逐帧矢量绘制与大刀机器人接入对战保存在 [20261016 证据](evidence/20261016/summary.json)，该目录冻结后不再改写。其胜负不作为后续方舟爪豪定位的验收。

## 本轮波属性定位验证

[20261016-wave 证据](evidence/20261016-wave/summary.json) 绑定实际运行的独立资源、候选程序、源码、属性与原始逐场结果。18 场均已正常结束，大头机器人全部获胜；所有组的退出、资源身份、只读种子和真实非目标存档检查通过。

| 同等级 | 双方换位合计 | 最低剩余生命 | 战斗帧数范围 |
|---|---|---|---|
| 30 | 6 胜 / 6 场 | 51.5% | 1437–1589 |
| 60 | 6 胜 / 6 场 | 51.5% | 1249–1516 |
| 99 | 6 胜 / 6 场 | 38.8% | 1372–1720 |

此前 60 级物理版换位两场虽均获胜，但仅剩 2.18%／5.55% 生命，分别耗时 3593／3580 帧，接近 3600 帧上限；原始回执完整保留。波版两场试跑同样保留，不计入上述 18 场。波版行为测试为 `368 passed, 0 failed; 24 actual timeline cases`，包含真实 `UniversalDamageHandle` 的波抗性路径。47 个原生 XML 与已逐帧检查过的物理版相比，仅根脚本变化，绘图内容一致；该比较不冒充重新进行完整像素捕获。

上述为隔离候选中的有限重复定位验证；全游戏节奏、低配机器表现及标准入口的人类体验仍须分别验收。当前资源仅在工作区，尚未提交或推广正式 runtime。

## 公共击退修正后的复验（2026-10-17）

大刀联动检查发现公共被击移动回调使用了未限定归属的减速度，真实执行会令速度成为 NaN。修正为单位自身减速度后重新发布 asLoader，并用本单位相同的波属性素材完成三档等级、双阵营、每侧三次的 18 场复验。大头本身的 AI、矢量和面板未改。

| 等级 | 胜场 / 场数 | 机器人结算余血 |
|---|---:|---:|
| 30 | 6 / 6 | 27.8%–65.0% |
| 60 | 6 / 6 | 50.0%–65.6% |
| 99 | 6 / 6 | 51.7%–64.1% |

全部自然结束，存档、只读种子、资源和进程清理检查通过；[新回执](evidence/20261017-knockback/summary.json)绑定修正后的 asLoader、实际候选身份及完整数据文件。此前 20261016-wave 的 18 场仍是旧 asLoader 下的历史结果，原包保留。本次未重新生成角色图形，也未进行正式 runtime 发布；有限斗兽结果不代替人类外观与操作验收。
