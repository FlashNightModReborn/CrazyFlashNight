﻿


// 拾取相关函数
_root.pickupItemManager = new PickUpManager();

// 保持原有全局函数调用方式的兼容性
_root.创建可拾取物 = function(物品名, 数量, X位置, Y位置, 是否飞出, parameterObject) {
    return _root.pickupItemManager.createCollectible(物品名, 数量, X位置, Y位置, 是否飞出, parameterObject);
};



// 出生点相关
_root.初始化出生点 = function() {
    //确定方向
    方向 = 方向 === "左" ? "左" : "右";
    if (方向 === "左") {
        this._xscale = -100;
    }
    //将碰撞箱附加到地图
    var gameworld = _root.gameworld;

    if (this.开门 == null) {
        this.开门 = function() {
            gotoAndPlay("开门");
        }
    }
    if (this.Hide) {
        this.生成完毕 = function() {
            this.gotoAndStop("正常");
            _root.通过影片剪辑外框绘制地图碰撞箱(this.area);
            this.生成完毕 = null;
        }
        this.gotoAndStop("隐藏");
    } else {
        _root.通过影片剪辑外框绘制地图碰撞箱(this.area);
    }
}

_root.地图元件 = new Object();

_root.地图元件.初始化地图元件 = function(target:MovieClip, presetName:String):Void {
    StaticInitializer.initializeMapElement(target, presetName);
}

_root.地图元件.初始化投影召唤器 = function(target:MovieClip) {
    target.taunt = true;

    _root.地图元件.初始化地图元件(target, "投影召唤器");

    var Projector:MovieClip = target.projector;

    // 关闭信息框绘制
    var infoVisible:Boolean = Projector.新版人物文字信息._visible;
    Projector.新版人物文字信息._visible = false;

    /* ---------- B. 生成Projector“全息投影” ---------- */
    // 1. 计算Projector包围盒（局部坐标系）
    var bb:Object = Projector.getBounds(Projector); // {xMin, xMax, yMin, yMax}
    var bmpW:Number = bb.xMax - bb.xMin;
    var bmpH:Number = bb.yMax - bb.yMin;

    // 宽高异常时提前返回，避免空 BitmapData
    if (bmpW <= 0 || bmpH <= 0) {
        return;
    }

    // 2. 准备位图并把Projector绘制进去
    var holoBmp:BitmapData = new BitmapData(bmpW, bmpH, true, 0x00000000);

    // 在绘制到位图时处理朝向
    var mtx:Matrix = new Matrix();
    mtx.translate(-bb.xMin, -bb.yMin);

    // 如果Projector朝左，添加水平翻转
    if (Projector._xscale < 0) {
        mtx.scale(-1, 1); // 水平翻转
        mtx.translate(bmpW, 0); // 调整位置
    }


    /* 颜色变换：轻微蓝化，保持更多原色 */
    var blueCT:ColorTransform = new ColorTransform(0.60, 0.75, 1.10, 0.70, 0, 0, 20, 0);

    holoBmp.draw(Projector, mtx, blueCT, "normal");

    Projector.新版人物文字信息._visible = infoVisible;

    // 3. 在投影召唤器里创建承载 MC 并贴 Bitmap
    var holoMC:MovieClip = target.createEmptyMovieClip("hologram", target.getNextHighestDepth());
    holoMC.attachBitmap(holoBmp, 0, "auto", true);

    // 4. 定位：根据朝向精确计算位置
    if (Projector._xscale < 0) {
        // 朝左时，图像已经在绘制时翻转，需要重新计算中心点
        holoMC._x = -bmpW * 0.42; // 调整到圆盘中心
    } else {
        // 朝右时正常
        holoMC._x = -bmpW / 5;
    }

    holoMC._y = -bmpH + 180;

    // 缩放保持一致
    holoMC._xscale = 66;
    holoMC._yscale = 66;

    // 5. 额外效果：加亮融合，夜色更显眼
    holoMC.blendMode = "add";

    /* ---------- C. 投影随召唤器销毁时释放位图内存 ---------- */
    target.onUnload = function() {
        if (holoBmp != null) {
            holoBmp.dispose();
        }
    };
}

#include "../逻辑/关卡系统/关卡系统_lsy_资源箱回调.as"


_root.地图元件.资源箱贴背景图 = function(target:MovieClip) {
    target.stop();
    _root.add2map(target, 2);
    target.removeMovieClip();
}


/**
 * 地图元件破碎动画包装方法
 *
 * 此函数作为新碎片动画系统的包装接口，保持与原有调用方式的兼容性。
 * 资源SWF文件可以直接调用此方法，无需导入任何类文件。
 *
 * 设计目标：
 * - 向后兼容：保持原有的调用方式和参数结构
 * - 零依赖：资源SWF不需要导入类文件
 * - 功能增强：支持更多配置选项和预设效果
 * - 智能转换：自动将旧格式配置转换为新系统
 *
 * 使用场景：
 * - 资源SWF中的破碎效果调用
 * - 旧项目的平滑迁移
 * - 快速原型制作和测试
 * - 简化的API接口
 *
 * @author FlashNight
 * @version 1.0
 * @since AS2
 */

/**
 * 地图元件破碎动画包装函数
 *
 * 这是原有动画系统的现代化替代方案，保持完全的向后兼容性。
 * 函数内部会自动检测配置类型并调用相应的处理逻辑。
 *
 * 支持的调用方式：
 * 1. 传统方式：传入Object格式的配置
 * 2. 预设方式：传入字符串指定预设名称
 * 3. 混合方式：传入预设名称+自定义覆盖参数
 * 4. 空配置：使用默认设置
 *
 * @param scope:MovieClip 当前作用域(this)，包含碎片MovieClip的容器
 * @param fragmentPrefix:String 碎片名称前缀(如"资源箱碎片")
 * @param cfg:Object|String 配置参数，支持多种格式：
 *   - Object: 传统的配置对象
 *   - String: 预设名称 ("wood", "metal", "glass"等)
 *   - null/undefined: 使用默认配置
 * @return Number 动画实例ID，可用于后续控制(-1表示失败)
 *
 * @example
 * // 传统方式（完全兼容原有调用）
 * var cfg:Object = {
 *     gravity: 1.4,
 *     bounce: 0.35,
 *     fragmentCount: 10,
 *     enableDebug: true
 * };
 * _root.地图元件.地图元件破碎动画(this, "资源箱碎片", cfg);
 *
 * @example
 * // 预设方式（新增功能）
 * _root.地图元件.地图元件破碎动画(this, "木箱碎片", "wood");
 *
 * @example
 * // 混合方式（预设+自定义）
 * var cfg:Object = {
 *     preset: "metal",          // 基础预设
 *     gravity: 2.0,            // 覆盖重力
 *     fragmentCount: 15,       // 覆盖碎片数量
 *     enableDebug: true
 * };
 * _root.地图元件.地图元件破碎动画(this, "装甲碎片", cfg);
 *
 * @example
 * // 最简调用
 * _root.地图元件.地图元件破碎动画(this, "碎片");
 */
_root.地图元件.地图元件破碎动画 = function(scope:MovieClip, fragmentPrefix:String, cfg:Object):Number {

    // ======================== 参数验证 ========================

    if (!scope) {
        trace("[地图元件破碎动画] 错误：scope参数不能为空");
        return -1;
    }
    if (!fragmentPrefix) {
        trace("[地图元件破碎动画] 错误：fragmentPrefix参数不能为空");
        return -1;
    }

    // ======================== 配置处理 ========================

    var config:FragmentConfig;
    var debugEnabled:Boolean = false;

    try {
        // 检测配置类型并进行相应处理
        if (!cfg) {
            // 情况1：无配置，使用默认
            config = FragmentPresets.getDefault();

        } else if (typeof cfg == "string") {
            // 情况2：字符串预设名称
            config = FragmentPresets.getPreset(String(cfg));
            if (!config) {
                trace("[地图元件破碎动画] 警告：未知预设 '" + cfg + "'，使用默认配置");
                config = FragmentPresets.getDefault();
            }

        } else if (typeof cfg == "object") {
            // 情况3：对象配置（传统方式或混合方式）

            if (cfg.preset) {
                // 混合方式：从预设开始，然后覆盖参数
                config = FragmentPresets.getPreset(String(cfg.preset));
                if (!config) {
                    trace("[地图元件破碎动画] 警告：未知预设 '" + cfg.preset + "'，使用默认配置作为基础");
                    config = FragmentPresets.getDefault();
                }

                // 从配置对象加载覆盖参数
                var loadResult:Boolean = config.loadFromObject(cfg);
                if (cfg.enableDebug) {
                    trace("[地图元件破碎动画] 混合配置模式：基础预设 '" + cfg.preset + "' + 自定义覆盖");
                }

            } else {
                // 传统方式：纯对象配置
                config = FragmentPresets.getDefault();
                var loadResult:Boolean = config.loadFromObject(cfg);

                if (cfg.enableDebug) {
                    trace("[地图元件破碎动画] 传统配置模式：" + (loadResult ? "配置加载成功" : "配置加载失败"));
                }
            }

            debugEnabled = Boolean(cfg.enableDebug);

        } else {
            // 情况4：无效配置类型
            trace("[地图元件破碎动画] 警告：无效的配置类型，使用默认配置");
            config = FragmentPresets.getDefault();
        }

        // ======================== 配置验证和调试 ========================

        // 验证配置有效性
        if (!config.validate()) {
            trace("[地图元件破碎动画] 配置参数存在问题，已自动修正");
        }

        // 输出调试信息
        if (debugEnabled || config.enableDebug) {
            trace("[地图元件破碎动画] ===== 动画启动信息 =====");
            trace("  作用域: " + scope);
            trace("  碎片前缀: " + fragmentPrefix);
            trace("  配置类型: " + typeof cfg);
            trace("  预设使用: " + (cfg && cfg.preset ? cfg.preset : "默认"));
            config.printSummary();
            trace("=========================================");
        }

        // ======================== 启动动画 ========================

        // 调用新的动画系统
        var animationId:Number = FragmentAnimator.startAnimation(scope, fragmentPrefix, config);

        if (animationId >= 0) {
            if (debugEnabled || config.enableDebug) {
                trace("[地图元件破碎动画] 动画启动成功，ID: " + animationId);
                trace("  当前活动动画数: " + FragmentAnimator.getActiveAnimationCount());
            }
            return animationId;
        } else {
            trace("[地图元件破碎动画] 错误：动画启动失败");
            return -1;
        }

    } catch (error:Error) {
        // ======================== 错误处理 ========================

        trace("[地图元件破碎动画] 捕获到异常: " + error.message);

        // 尝试使用最基础的配置作为后备方案
        try {
            trace("[地图元件破碎动画] 尝试使用后备配置...");
            var fallbackConfig:FragmentConfig = new FragmentConfig();
            fallbackConfig.enableDebug = debugEnabled;

            var fallbackId:Number = FragmentAnimator.startAnimation(scope, fragmentPrefix, fallbackConfig);

            if (fallbackId >= 0) {
                trace("[地图元件破碎动画] 后备方案成功，动画ID: " + fallbackId);
                return fallbackId;
            }

        } catch (fallbackError:Error) {
            trace("[地图元件破碎动画] 后备方案也失败: " + fallbackError.message);
        }

        return -1;
    }
};

// NPC
//_root.初始化NPC(this);
_root.初始化NPC = function(目标) {
    if (org.flashNight.arki.map.MapWorldNpcController.intercept(目标)) return;
    if (目标.NPC初始化完毕 === true)
        return;
    // 作弊开关 shownpc：开启后放行一切任务出现门槛（本次游戏有效，不进存档）。
    // 与 C# presence 许可同一边界：只要任一为真，就不再用任务进度挡人。
    var 允许驻场:Boolean = (_root.cheatFlags && _root.cheatFlags.强制显示NPC)
            || org.flashNight.arki.map.MapWorldNpcController.hasPresencePermit(目标);
    if (!允许驻场
            && 目标.任务需求 > 1 && _root.主线任务进度 < 目标.任务需求) {
        目标.stop();
        目标._visible = false;
        return;
    }
    // 未接管 NPC 保留上游支线门槛；已显式接管的驻点只认本次 C# presence 许可，与主线门槛同一边界。
    if (!允许驻场
            && 目标.任务需求支线 != undefined && 目标.任务需求支线 != null && 目标.任务需求支线.length > 0) {
        var 支线需求:Array = 目标.任务需求支线;
        var 支线未完成:Boolean = false;
        for (var ri:Number = 0; ri < 支线需求.length; ri++) {
            var 支线任务ID:Number = Number(支线需求[ri]);
            if (isNaN(支线任务ID)) continue;
            if (isNaN(_root.tasks_finished[String(支线任务ID)]) || _root.tasks_finished[String(支线任务ID)] < 1) {
                支线未完成 = true;
                break;
            }
        }
        if (支线未完成) {
            目标.stop();
            目标._visible = false;
            return;
        }
    }
    var npcBaseName:String = String(目标.名字);
    var npcDialogueName:String = npcBaseName;
    var npcTaskName:String = npcBaseName;
    var npcShopName:String = npcBaseName;
    var npcSkillName:String = npcBaseName;

    if (目标.对话名 != undefined && 目标.对话名 != null && String(目标.对话名).length > 0) {
        npcDialogueName = String(目标.对话名);
    }
    if (目标.任务名 != undefined && 目标.任务名 != null && String(目标.任务名).length > 0) {
        npcTaskName = String(目标.任务名);
    }
    if (目标.商店检索名 != undefined && 目标.商店检索名 != null && String(目标.商店检索名).length > 0) {
        npcShopName = String(目标.商店检索名);
    }
    if (目标.技能检索名 != undefined && 目标.技能检索名 != null && String(目标.技能检索名).length > 0) {
        npcSkillName = String(目标.技能检索名);
    }

    目标._name = npcBaseName;
    目标.NPC对话名 = npcDialogueName;
    目标.NPC任务名 = npcTaskName;
    目标.NPC商店检索名 = npcShopName;
    目标.NPC技能检索名 = npcSkillName;

    // 对话绑定：通过 Launcher 查询（Launcher 是唯一数据源）
    // 注意：AS2 中 _name 作局部变量名会引发编译器冲突
    if (目标.默认对话 == null) {
        var npcNameStr:String = npcDialogueName;
        if (npcNameStr != undefined && npcNameStr != null && npcNameStr.length > 0) {
            目标.默认对话 = [];  // 占位
            var npcRef:MovieClip = 目标;
            org.flashNight.neur.Server.DataQueryService.query(
                "npc_dialogue",
                {key: npcNameStr, taskProgress: _root.主线任务进度},
                function(response:Object):Void {
                    if (npcRef._parent == null) return;  // MC 已销毁
                    if (response.success) {
                        if (response.result != null && response.result.length > 0) {
                            var assembled:Array = [];
                            for (var i:Number = 0; i < response.result.length; i++) {
                                assembled[i] = _root.组装单次对话(response.result[i]);
                            }
                            npcRef.默认对话 = assembled;
                        }
                        npcRef.NPC对话已绑定 = true;
                    } else {
                        _root.服务器.发布服务器消息("[初始化NPC] 查询失败:", npcNameStr, "error:", response.error);
                    }
                }
            );
        }
    }

        // _root.服务器.发布服务器消息("NPC默认对话: " + ObjectUtil.stringify(目标.默认对话));
    if (目标.物品栏 == null)
        目标.物品栏 = _root.getNPCShop(npcShopName);
    if (目标.可学的技能 == null)
        目标.可学的技能 = _root.getNPCSkills(npcSkillName);
    if (_root.NPCTaskCheck(npcTaskName).result == "接受任务") {
        _root.发布消息(目标.名字 + "也许需要你的帮助");
        //目标.文字信息.任务接取提示._visible = 1;
        // if (目标.文字信息 && !目标.文字信息.任务接取提示) {
        //     目标.文字信息.任务接取提示 = 目标.文字信息.attachMovie("任务接取提示", "任务接取提示", 目标.文字信息.getNextHighestDepth());
        //     目标.文字信息.任务接取提示._x = 32.5;
        //     目标.文字信息.任务接取提示._y = 12.1;
        // }
    }
    //  else {
    //     //目标.文字信息.任务接取提示._visible = 0;
    //     if (目标.文字信息 && 目标.文字信息.任务接取提示) {
    //         目标.文字信息.任务接取提示.removeMovieClip();
    //         delete 目标.文字信息.任务接取提示;
    //     }
    // }
    if (目标.文字信息 && !目标.文字信息.任务接取提示) {
        目标.文字信息.任务接取提示 = 目标.文字信息.attachMovie("任务接取提示", "任务接取提示", 目标.文字信息.getNextHighestDepth());
        目标.文字信息.任务接取提示._x = 32.5;
        目标.文字信息.任务接取提示._y = 12.1;
    }
    // 目标.是否为敌人 = false;
    //目标.击中效果 = "飙血"; //意义不明
    if (目标.方向 == null)
        目标.方向 = "右";
    if (isNaN(目标.身高))
        目标.身高 = 175;
    var 缩放系数 = UnitUtil.getHeightPercentage(目标.身高) / 100;
    目标._yscale *= 缩放系数;
    if (目标.方向 == "左") {
        目标._xscale *= -缩放系数;
        目标.文字信息._xscale = -100;
        目标.商店名._xscale = -100;
    } else {
        目标._xscale *= 缩放系数;
    }

    // 出生 seed：立即注册进深度管理器，将创建暂存深度替换为 Twip 深度
    org.flashNight.gesh.depth.DepthManager.instance.updateDepth(目标, 目标._y);
    // 劫持 swapDepths：将帧脚本的原生调用重定向到 DepthManager
    org.flashNight.gesh.depth.DepthManager.instance.installHijack(目标);

    目标.NPC初始化完毕 = true;
}
