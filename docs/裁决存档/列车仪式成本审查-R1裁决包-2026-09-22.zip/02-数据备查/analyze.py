# 列车仪式成本统计脚本（裁决包原料生成器）
# 输入：tmp/train-cost-20260922/raw/ 下的 git-log.txt、consensus-commits.txt、
#       cloud-builder-runs.json、audit-runs.json、candidate-stage-seconds.json，
#       以及 docs/runtime-build-reproducibility.md（列车历史记录权威文本）。
# 输出：raw/commit-classification.csv、raw/train-inventory.csv、raw/analysis-summary.json
# 所有分类规则均为确定性正则，可完整重放。
import json, re, csv, os
from datetime import datetime, timezone, timedelta

RAW = 'tmp/train-cost-20260922/raw'
DOC = 'docs/runtime-build-reproducibility.md'
SINCE = '2026-08-20'
UNTIL = '2026-09-23'
CST = timezone(timedelta(hours=8))

# ---------- 1. 提交分类 ----------
commits = []
for line in open(f'{RAW}/git-log.txt', encoding='utf-8'):
    line = line.rstrip('\n')
    if not line:
        continue
    h, ts, subj = line.split('|', 2)
    commits.append({'hash': h, 'ts': ts, 'subject': subj})

# 部署提交集合（consensus 变更 = promotion 落盘，机器真源信号）
deploy_keys = set()
for line in open(f'{RAW}/consensus-commits.txt', encoding='utf-8'):
    line = line.rstrip('\n')
    if line:
        ts, subj = line.split('|', 1)
        deploy_keys.add((ts, subj))

def classify(c):
    s = c['subject']
    if s.startswith('发布列车'):
        return 'ceremony-tag-pointer'
    if (c['ts'], s) in deploy_keys:
        return 'ceremony-deploy'
    if re.search(r'冻结|重新冻结|刷新.{0,12}(派生|来源|指纹|字典)|补齐.{0,12}(闭包|来源|指纹)|同步.{0,10}冻结|重派生', s):
        return 'ceremony-freeze-derive'
    if re.search(r'^docs', s) and re.search(r'发布审计|发布并|收口.{0,12}发布|发布收口|部署.{0,4}记录', s):
        return 'ceremony-audit-doc'
    return 'business-or-other'

for c in commits:
    c['cls'] = classify(c)

in_window = [c for c in commits if SINCE <= c['ts'][:10] < UNTIL]
with open(f'{RAW}/commit-classification.csv', 'w', encoding='utf-8-sig', newline='') as f:
    w = csv.writer(f)
    w.writerow(['hash', 'ts', 'class', 'subject'])
    for c in in_window:
        w.writerow([c['hash'][:12], c['ts'], c['cls'], c['subject']])

cls_counts = {}
for c in in_window:
    cls_counts[c['cls']] = cls_counts.get(c['cls'], 0) + 1

# 按周汇总
week = {}
for c in in_window:
    d = c['ts'][:10]
    key = f"{d[:7]}-W{(int(d[8:10]) - 1) // 7 + 1}"
    t = week.setdefault(key, {'total': 0, 'ceremony': 0})
    t['total'] += 1
    if c['cls'] != 'business-or-other':
        t['ceremony'] += 1

# ---------- 2. 文档列车记录解析 ----------
doc = open(DOC, encoding='utf-8').read()
# 不可变 tag：runtime-build-v2/<id>-vN
tags = {}
for m in re.finditer(r'runtime-build-v2/([0-9a-z-]+?)-v(\d+)', doc):
    tid, v = m.group(1), int(m.group(2))
    tags.setdefault(tid, set()).add(v)
tag_versions = {k: sorted(vv) for k, vv in tags.items()}
superseded_tags = sum(max(vv) - 1 for vv in tags.values())  # 每个 id 的非首个版本意味着前面有废弃版
# release source（最终源）
final_sources = set()
for m in re.finditer(r'(?:最终 )?release source (?:为 )?`([0-9a-f]{10,40})`', doc):
    final_sources.add(m.group(1))
# 文档中 supersede 提及次数（request 级返工代理指标）
supersede_mentions = len(re.findall(r'supersede', doc))
# 窗口内 tag（id 以窗口内日期开头）
win_tags = {k: v for k, v in tag_versions.items()
            if any(k.startswith(f'2026{mm}{dd}') for mm in ('08', '09')
                   for dd in range(20 if mm == '08' else 1, 32))}
win_superseded_tags = sum(max(v) - 1 for v in win_tags.values())

# ---------- 3. 云构建运行 ----------
cloud = json.load(open(f'{RAW}/cloud-builder-runs.json', encoding='utf-8'))
cloud = [r for r in cloud if SINCE <= r['createdAt'][:10] < UNTIL]
def dur_min(r):
    st = datetime.fromisoformat(r['startedAt'].replace('Z', '+00:00'))
    up = datetime.fromisoformat(r['updatedAt'].replace('Z', '+00:00'))
    return (up - st).total_seconds() / 60
cloud_total_min = sum(dur_min(r) for r in cloud)
cloud_matched = [r for r in cloud if any(r['headSha'].startswith(fs[:len(r['headSha'])]) or fs.startswith(r['headSha']) for fs in final_sources)]
cloud_retry = [r for r in cloud if r not in cloud_matched]
per_day_cloud = {}
for r in cloud:
    per_day_cloud[r['createdAt'][:10]] = per_day_cloud.get(r['createdAt'][:10], 0) + 1

# ---------- 4. 审计 workflow ----------
audit = json.load(open(f'{RAW}/audit-runs.json', encoding='utf-8'))
audit = [r for r in audit if SINCE <= r['createdAt'][:10] < UNTIL]
audit_total_min = sum(dur_min(r) for r in audit)
audit_by_conclusion = {}
for r in audit:
    audit_by_conclusion[r['conclusion']] = audit_by_conclusion.get(r['conclusion'], 0) + 1

# ---------- 5. 本地构建耗时 ----------
cand = json.load(open(f'{RAW}/candidate-stage-seconds.json', encoding='utf-8'))
totals = [v['totalSeconds'] for v in cand.values() if v.get('totalSeconds')]
stage_sum = {}
stage_n = {}
for v in cand.values():
    for k, x in (v.get('stageSeconds') or {}).items():
        stage_sum[k] = stage_sum.get(k, 0) + x
        stage_n[k] = stage_n.get(k, 0) + 1
stage_avg = {k: round(stage_sum[k] / stage_n[k], 1) for k in stage_sum}

# ---------- 6. 逐列车清单（部署锚点） ----------
deploys = []
for c in in_window:
    if c['cls'] == 'ceremony-deploy':
        deploys.append({'ts': c['ts'], 'subject': c['subject'], 'hash': c['hash'][:12]})
deploys.sort(key=lambda d: d['ts'])
with open(f'{RAW}/train-inventory.csv', 'w', encoding='utf-8-sig', newline='') as f:
    w = csv.writer(f)
    w.writerow(['deploy_ts_local', 'hash', 'subject'])
    for d in deploys:
        w.writerow([d['ts'], d['hash'], d['subject']])

# ---------- 6.5 冻结→部署挂钟（启发式配对，量级估计） ----------
# 对每个匹配最终源的云构建 run，取其后 24h 内最近的部署提交；多列车日可能错配，
# 仅作量级参考，不作单趟结论。
freeze_to_deploy = []
deploy_ts_sorted = sorted(
    datetime.fromisoformat(d['ts']) for d in deploys)
for r in cloud_matched:
    run_ts = datetime.fromisoformat(r['createdAt'].replace('Z', '+00:00')).astimezone(CST)
    later = [t for t in deploy_ts_sorted if t >= run_ts]
    if later and (later[0] - run_ts).total_seconds() < 86400:
        freeze_to_deploy.append(round((later[0] - run_ts).total_seconds() / 60, 1))
freeze_to_deploy.sort()

# ---------- 7. 汇总 ----------
summary = {
    'window': {'since': SINCE, 'until': UNTIL, 'days': 34},
    'commits': {'total': len(in_window), 'by_class': cls_counts,
                'ceremony_total': sum(v for k, v in cls_counts.items() if k.startswith('ceremony')),
                'weekly': {k: {'total': v['total'], 'ceremony': v['ceremony'],
                               'ratio_pct': round(100 * v['ceremony'] / v['total'], 1)} for k, v in sorted(week.items())}},
    'trains': {'promotions_consensus_touches': len(deploys),
               'doc_tag_ids': len(tag_versions),
               'window_tag_ids': len(win_tags),
               'window_superseded_tags_est': win_superseded_tags,
               'doc_tag_versions': {k: v for k, v in sorted(tag_versions.items())},
               'doc_superseded_tags_est': superseded_tags,
               'doc_supersede_mentions': supersede_mentions},
    'cloud': {'runs': len(cloud), 'total_min': round(cloud_total_min, 1),
              'avg_min': round(cloud_total_min / len(cloud), 2),
              'matched_final_source': len(cloud_matched),
              'retry_or_superseded_runs': len(cloud_retry),
              'per_day': dict(sorted(per_day_cloud.items()))},
    'audit': {'runs': len(audit), 'total_min': round(audit_total_min, 1),
              'by_conclusion': audit_by_conclusion},
    'local_build': {'samples': len(totals), 'avg_s': round(sum(totals) / len(totals), 1),
                    'min_s': round(min(totals), 1), 'max_s': round(max(totals), 1),
                    'stage_avg_s': stage_avg},
    'freeze_to_deploy_min': {'samples': len(freeze_to_deploy),
                             'median': freeze_to_deploy[len(freeze_to_deploy) // 2] if freeze_to_deploy else None,
                             'p25': freeze_to_deploy[len(freeze_to_deploy) // 4] if freeze_to_deploy else None,
                             'p75': freeze_to_deploy[3 * len(freeze_to_deploy) // 4] if freeze_to_deploy else None,
                             'max': max(freeze_to_deploy) if freeze_to_deploy else None},
}
json.dump(summary, open(f'{RAW}/analysis-summary.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print(json.dumps(summary, ensure_ascii=False, indent=1))
