#!/usr/bin/env python3
"""Read-only audit of the supplied CF7 issue #78 R1 evidence package.

Usage: python verify_r1.py R1.zip --output audit.json
       python verify_r1.py unpacked_directory --output audit.json
Only Python's standard library is used. No git, network, build, or release
commands are invoked. Event annotations are evidence-based labels, not
cryptographic or runtime verification of the historical release records.
"""
from __future__ import annotations
import argparse
import collections
import csv
import hashlib
import io
import json
import re
import statistics
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

TZ = timezone(timedelta(hours=8))
START = datetime(2026, 8, 20, tzinfo=TZ)
END = datetime(2026, 9, 23, tzinfo=TZ)


def dt(value: str) -> datetime:
    return datetime.fromisoformat(value.replace('Z', '+00:00'))


def inside(value: str) -> bool:
    return START <= dt(value) < END


def elapsed_seconds(run: dict) -> float:
    return (dt(run['updatedAt']) - dt(run['startedAt'])).total_seconds()


def load_inputs(path: Path) -> dict[str, bytes]:
    if path.is_dir():
        result = {p.relative_to(path).as_posix(): p.read_bytes()
                  for p in path.rglob('*') if p.is_file()}
    elif path.is_file() and zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as archive:
            result = {x.filename: archive.read(x) for x in archive.infolist()
                      if not x.is_dir()}
    else:
        raise ValueError('Input must be an existing evidence directory or ZIP.')
    return result


def audit(files: dict[str, bytes]) -> dict:
    def read(name: str) -> str:
        keys = [k for k in files if k == name or k.endswith('/' + name)]
        if len(keys) != 1:
            raise ValueError(f'Expected one {name!r}; found {len(keys)}.')
        return files[keys[0]].decode('utf-8-sig')

    commits = []
    for line in read('git-log.txt').splitlines():
        if line:
            sha, timestamp, subject = line.split('|', 2)
            if inside(timestamp):
                commits.append({'hash': sha, 'ts': timestamp, 'subject': subject})
    consensus_keys = set()
    for line in read('consensus-commits.txt').splitlines():
        if line:
            timestamp, subject = line.split('|', 1)
            consensus_keys.add((timestamp, subject))

    def classify(c: dict) -> str:
        s = c['subject']
        if s.startswith('发布列车'):
            return 'ceremony-tag-pointer'
        if (c['ts'], s) in consensus_keys:
            return 'ceremony-deploy'
        if re.search(r'冻结|重新冻结|刷新.{0,12}(派生|来源|指纹|字典)|补齐.{0,12}(闭包|来源|指纹)|同步.{0,10}冻结|重派生', s):
            return 'ceremony-freeze-derive'
        if re.search(r'^docs', s) and re.search(r'发布审计|发布并|收口.{0,12}发布|发布收口|部署.{0,4}记录', s):
            return 'ceremony-audit-doc'
        return 'business-or-other'

    for c in commits:
        c['class'] = classify(c)
    bins = collections.Counter(c['class'] for c in commits)
    promotions = [c for c in commits if c['class'] == 'ceremony-deploy']
    days = collections.Counter(dt(c['ts']).astimezone(TZ).date().isoformat()
                               for c in promotions)
    weekly = {}
    for c in commits:
        iso = dt(c['ts']).astimezone(TZ).isocalendar()
        key = f'{iso.year}-W{iso.week:02d}'
        row = weekly.setdefault(key, {'total': 0, 'narrow_match': 0})
        row['total'] += 1
        row['narrow_match'] += int(c['class'].startswith('ceremony'))
    for row in weekly.values():
        row['pct'] = row['narrow_match'] / row['total'] * 100

    doc = read('runtime-build-reproducibility.md')
    versions: dict[str, set[int]] = {}
    for m in re.finditer(r'runtime-build-v2/([0-9a-z-]+?)-v(\d+)', doc):
        versions.setdefault(m[1], set()).add(int(m[2]))
    window_versions = {k: sorted(v) for k, v in versions.items()
                       if '20260820' <= k[:8] < '20260923'}
    buggy_versions = {k: v for k, v in versions.items()
                      if any(k.startswith(f'2026{month}{day}')
                             for month in ('08', '09')
                             for day in range(20 if month == '08' else 1, 32))}
    finals = {m[1] for m in re.finditer(
        r'(?:最终 )?release source (?:为 )?`([0-9a-f]{10,40})`', doc)}
    cloud = [r for r in json.loads(read('cloud-builder-runs.json')) if inside(r['createdAt'])]
    audits = [r for r in json.loads(read('audit-runs.json')) if inside(r['createdAt'])]
    matched = [r for r in cloud if any(r['headSha'].startswith(f) or f.startswith(r['headSha']) for f in finals)]
    unmatched = [r for r in cloud if r not in matched]
    local = list(json.loads(read('candidate-stage-seconds.json')).values())

    def run_stats(runs: list[dict]) -> dict:
        elapsed = sum(elapsed_seconds(r) for r in runs)
        return {'count': len(runs), 'conclusions': dict(collections.Counter(r['conclusion'] for r in runs)),
                'workflow_elapsed_seconds': elapsed,
                'workflow_elapsed_minutes': elapsed / 60,
                'mean_elapsed_minutes': elapsed / 60 / len(runs) if runs else None}

    # These three sets are disjoint subsets of the ORIGINAL 29 unmatched runs.
    # Lines refer to the ORIGINAL runtime-build-reproducibility.md.
    annotations = {
        'documented_final_use_missed_by_regex': {
            35672805431: [943, 945, 951],
            33255138023: [757, 759, 760],
            33220240979: [769, 771, 772]},
        'documented_intermediate_local_promotion': {
            33957634090: [679, 685],
            33945207841: [702, 704]},
        'explicit_documented_nonpromotion_subset': {
            34745615347: [371], 34702454701: [387],
            34641981631: [416, 420], 34455545619: [470],
            34376555533: [510], 34097840213: [595, 604]}}
    annotation_stats = {}
    assigned = set()
    unmatched_ids = {r['databaseId'] for r in unmatched}
    for label, evidence in annotations.items():
        ids = set(evidence)
        if not ids <= unmatched_ids or ids & assigned:
            raise ValueError(f'Invalid evidence partition: {label}')
        assigned |= ids
        selected = [r for r in unmatched if r['databaseId'] in ids]
        annotation_stats[label] = {**run_stats(selected), 'protocol_lines_by_run': evidence}
    remaining = [r for r in unmatched if r['databaseId'] not in assigned]
    strict_derived_ids = {34641981631, 34455545619, 34376555533}
    strict_derived = [r for r in cloud if r['databaseId'] in strict_derived_ids]
    derived_seconds = sum(elapsed_seconds(r) for r in strict_derived)

    pairs = []
    for r in matched:
        later = [p for p in promotions if dt(p['ts']) >= dt(r['createdAt'])]
        if later:
            p = min(later, key=lambda x: dt(x['ts']))
            minutes = (dt(p['ts']) - dt(r['createdAt'])).total_seconds() / 60
            if minutes < 1440:
                pairs.append({'run_id': r['databaseId'], 'deployment_commit': p['hash'], 'minutes': minutes})
    suspect_ids = {'c07760a977db', 'e434434596e1', '678cb32cdea1',
                   '31892397a224', 'b6e555d47293', 'b994d87b0545', '96c7be5f7a69'}
    adjusted_days = days.copy()
    adjusted_days['2026-09-05'] -= 2  # Two documented same-business v1 -> v2 local redeployments.
    return {
        'scope': 'Frozen package only. No live repository, Actions, signatures, artifacts, or tests verified.',
        'time_window': {'start_inclusive': START.isoformat(), 'end_exclusive': END.isoformat(),
                        'calendar_date_labels': 34, 'note': 'Date labels do not prove a completed final day or collection completeness.'},
        'input_sha256': {k: hashlib.sha256(v).hexdigest() for k, v in sorted(files.items())},
        'commits': {'total': len(commits), 'narrow_regex_matches': sum(v for k, v in bins.items() if k.startswith('ceremony')),
                    'broad_keyword_matches': sum(bool(re.search('发布|部署|冻结|列车|审计', c['subject'])) for c in commits),
                    'original_narrow_classes': dict(bins), 'iso_weeks': dict(sorted(weekly.items())),
                    'narrow_suspect_semantics_not_diff_verified': [c for c in commits if c['hash'][:12] in suspect_ids]},
        'promotion_proxies': {'count': len(promotions), 'active_days': len(days),
                              'day_distribution': dict(sorted(collections.Counter(days.values()).items())),
                              'raw_daily_cap_one_hypothetical_reduction': sum(max(0, n - 1) for n in days.values()),
                              'raw_daily_cap_two_hypothetical_reduction': sum(max(0, n - 2) for n in days.values()),
                              'after_only_two_known_same_business_redeployment_dedup_count': sum(adjusted_days.values()),
                              'dedup_daily_cap_one_hypothetical_reduction': sum(max(0, n - 1) for n in adjusted_days.values()),
                              'dedup_daily_cap_two_hypothetical_reduction': sum(max(0, n - 2) for n in adjusted_days.values()),
                              'note': 'No proof of batching eligibility, urgency, readiness, or actual avoidability.'},
        'tag_text_extraction': {'correctly_date_filtered_vN_ids': len(window_versions),
                                'ids_with_max_version_at_least_two': sum(max(v) >= 2 for v in window_versions.values()),
                                'sum_max_version_minus_one_not_observed_abandoned_count': sum(max(v) - 1 for v in window_versions.values()),
                                'buggy_filter_ids': len(buggy_versions),
                                'buggy_filter_ids_with_max_version_at_least_two': sum(max(v) >= 2 for v in buggy_versions.values()),
                                'buggy_filter_sum_max_version_minus_one': sum(max(v) - 1 for v in buggy_versions.values()),
                                'omitted_ids': sorted(window_versions.keys() - buggy_versions.keys()),
                                'note': 'Not a tag registry. w1/w2 variants are missed; different date IDs may refer to one business train.'},
        'cloud': {**run_stats(cloud), 'original_final_source_regex_matches': len(matched),
                  'original_unmatched': run_stats(unmatched), 'annotation_subsets': annotation_stats,
                  'remaining_unclassified_in_this_audit': {**run_stats(remaining), 'run_ids': [r['databaseId'] for r in remaining]},
                  'strict_derived_failure_opportunity_subset': {**run_stats(strict_derived), 'run_ids': sorted(strict_derived_ids),
                      'illustrative_break_even_check_seconds_if_all_three_prevented': {str(n): derived_seconds / n for n in [534, 63, 78]},
                      'note': 'Historical opportunity subset, not a total causal rate or guaranteed future savings. 63 and 78 are illustrative check counts, not measured freeze-attempt counts.'}},
        'audit': {**run_stats(audits), 'success_pct': sum(r['conclusion'] == 'success' for r in audits) / len(audits) * 100},
        'local_candidates': {'count': len(local), 'mean_seconds': statistics.mean(x['totalSeconds'] for x in local),
                             'min_seconds': min(x['totalSeconds'] for x in local), 'max_seconds': max(x['totalSeconds'] for x in local),
                             'note': 'Mixed local candidate metadata. Not a measured formal-worker per-release cost.'},
        'heuristic_dispatch_to_next_promotion': {'count': len(pairs), 'unique_promotion_commits': len({p['deployment_commit'] for p in pairs}),
                                               'median_minutes': statistics.median(p['minutes'] for p in pairs),
                                               'minimum_minutes': min(p['minutes'] for p in pairs),
                                               'maximum_minutes': max(p['minutes'] for p in pairs),
                                               'note': 'Not freeze time, isolated post-cloud tail, or human active attention.'}}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        result = audit(load_inputs(args.evidence))
    except (OSError, ValueError, KeyError, json.JSONDecodeError, zipfile.BadZipFile) as exc:
        parser.exit(2, f'Audit failed: {exc}\n')
    text = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding='utf-8')
    else:
        print(text, end='')


if __name__ == '__main__':
    main()
