#!/usr/bin/env python3
"""Read-only R8 archive audit. Does not execute or import code from the archive.
Usage: python audit_evidence.py INPUT.zip OUTPUT_DIRECTORY
Only writes newly generated audit JSON and source excerpts under OUTPUT_DIRECTORY.
"""
from __future__ import annotations
import collections
import hashlib
import json
import pathlib
import sys
import zipfile

RANGES = {
 'E01': ('docs/reports/统一输入-R8取消机制判定与协作域-2026-09-23.md', [(1,80)]),
 'E02': ('docs/统一合成与输入归属-分阶段施工计划-2026-09-22.md', [(111,131),(199,230),(278,309)]),
 'E03': ('launcher/native/world-compositor/flash-hover-fixture/CooperativeHost.cs', [(15,111),(129,221)]),
 'E04': ('launcher/native/world-compositor/flash-hover-fixture/cooperative/CooperativeProbe.as', [(1,143)]),
 'E05': ('launcher/native/world-compositor/flash-hover-fixture/cooperative-child/CooperativeChild.as', [(1,2)]),
 'E06': ('launcher/native/world-compositor/flash-hover-fixture/Program.cs', [(79,104),(106,140),(239,278)]),
 'E07': ('flashswf/levels/基地场景合集/LIBRARY/地图/医务室.xml', [(9,10),(20,59),(70,115),(126,141)]),
 'E08': ('flashswf/levels/基地场景合集/LIBRARY/sprite/理发师/理发师-NPC.xml', [(25,47)]),
 'E09': ('scripts/展现/UI交互/UI交互_lsy_UI管理.as', [(1,110)]),
 'E10': ('scripts/类定义/org/flashNight/arki/ui/PlasticSurgeryPanelService.as', [(15,91),(115,175)]),
 'E11': ('launcher/src/Guardian/LauncherCommandRouter.cs', [(3182,3209),(3299,3317)]),
 'E12': ('launcher/src/Guardian/PanelHostController.cs', [(688,722),(3180,3259)]),
 'E13': ('launcher/src/Guardian/WorldCompositor/WorldCompositionSurface.cs', [(72,147),(195,241),(267,288)]),
 'E14': ('launcher/src/Guardian/WorldCompositor/WorldCompositorController.cs', [(48,57),(246,268),(326,352)]),
 'E15': ('launcher/native/world-compositor/InputBridge.cpp', [(153,165),(213,245)]),
 'E16': ('launcher/native/world-compositor/flash-hover-fixture/experiments/README.md', [(1,11)]),
 'E17': ('tmp/r8-capture-candidate/evidence-foreground/host.log', [(100,112),(135,159)]),
 'E18': ('tmp/r8-capture-candidate/evidence-foreground/as2.jsonl', [(391,393),(419,423)]),
 'E19': ('tmp/r8-cooperative-final/evidence/as2.jsonl', [(732,738),(792,800),(806,811),(843,851)]),
 'E20': ('tmp/r8-raw-full/evidence/host.log', [(1,8)]),
}
RUNS = ['r8-capture-baseline/evidence','r8-direct-control/evidence','r8-oracle-baseline/evidence','r8-capture-candidate/evidence-foreground','r8-cooperative-final/evidence','r8-raw-full/evidence']

def audit(src: pathlib.Path, out: pathlib.Path) -> None:
    if not src.is_file():
        raise FileNotFoundError(src)
    out.mkdir(parents=True, exist_ok=True)
    result = {'audit_kind':'static_archive_hash_and_log_recount_not_runtime_test', 'archive_name':src.name,
              'archive_sha256':hashlib.sha256(src.read_bytes()).hexdigest(), 'runtime_tests_executed_here':False}
    with zipfile.ZipFile(src) as z:
        if sum(i.file_size for i in z.infolist()) > 100_000_000:
            raise ValueError('Archive exceeds the expected audit size bound')
        def text(name: str) -> str:
            return z.read(name).decode('utf-8-sig')
        manifest=json.loads(text('manifest.json'))
        checks=[]
        for f in manifest['files']:
            b=z.read(f['path'])
            actual=hashlib.sha256(b).hexdigest()
            checks.append({'path':f['path'],'bytes':len(b),'sha256':actual,
                           'matches':len(b)==f['bytes'] and actual.lower()==f['sha256'].lower()})
        listed={x['path'] for x in checks}
        result['identity']={k:manifest[k] for k in ['createdUtc','head','scope']}
        result['manifest']={'checked':len(checks),'matched':sum(c['matches'] for c in checks),
                            'extra_entries':[n for n in z.namelist() if not n.endswith('/') and n!='manifest.json' and n not in listed],
                            'files':checks}
        result['runs']=[]
        for run in RUNS:
            base='tmp/'+run+'/'
            summary=json.loads(text(base+'summary.json'))
            assertions=summary['assertions']
            host=text(base+'host.log').splitlines()
            rows=[]
            for n,line in enumerate(text(base+'as2.jsonl').splitlines(),1):
                outer=json.loads(line); inner=json.loads(outer['Raw'])
                rows.append((n,outer,inner))
            gaps=[{'before':a[2]['seq'],'after':b[2]['seq']} for a,b in zip(rows,rows[1:]) if b[2]['seq']!=a[2]['seq']+1]
            result['runs'].append({'path':'tmp/'+run,'recorded_result':summary['result'],
                'assertions':len(assertions),'passed':sum(x['okay'] for x in assertions),
                'failed':sum(not x['okay'] for x in assertions),'unique_assertion_names':len({x['name'] for x in assertions}),
                'failure_details':[a for a in assertions if not a['okay']],
                'host_assert_pass_lines':sum('ASSERT PASS ' in s for s in host),'host_assert_fail_lines':sum('ASSERT FAIL ' in s for s in host),
                'as2_records':len(rows),'as2_recorded_sequence_gaps':gaps,
                'as2_events':dict(collections.Counter(x[1]['Event'] for x in rows)),
                'runtime_identity_record':json.loads(text(base+'identity.json'))})
        native=json.loads(text('launcher/native/world-compositor/flash-hover-fixture/experiments/capture-sources.json'))
        roots={'production':'launcher/native/world-compositor/','observation':'tmp/r8-capture-baseline/source/','rejectedCaptureRevoke':'tmp/r8-capture-candidate/source/'}
        result['native_source_identity_checks']={kind:{n:hashlib.sha256(z.read(roots[kind]+n)).hexdigest()==digest for n,digest in values.items()} for kind,values in native.items()}
        host=text('tmp/r8-host-regression.log').splitlines()
        result['recorded_host_regression_tail']=host[-12:]
        result['limitations']=['No Windows, CS6, projector, browser, Native, IME, runtime or production tests executed in this audit.',
           'No executable SWF/Host/projector/native binaries are included; their actual runtime hashes cannot be independently recomputed here.',
           'A contiguous recorded AS2 sequence is not proof that an OS hook never missed input.',
           'Manifest equality is integrity of the supplied package, not provenance, a clean checkout, or deployment authorization.']
        extracts=['# R8 冻结证据逐行摘录','', '此文件由 audit_evidence.py 从输入 ZIP 静态生成；行号为包内原文件行号。JSONL 同时给出解码后的内层 Raw；未执行包内源码。','',
                  '输入 ZIP SHA-256：`'+result['archive_sha256']+'`','']
        for eid,(path,ranges) in RANGES.items():
            lines=text(path).splitlines()
            extracts += ['## '+eid,'','来源：`'+path+'`','']
            for a,b in ranges:
                extracts += ['### L'+str(a)+'–L'+str(min(b,len(lines))),'','```text']
                for n in range(a,min(b,len(lines))+1):
                    line=lines[n-1]
                    if path.endswith('as2.jsonl'):
                        outer=json.loads(line);inner=json.loads(outer.pop('Raw'))
                        line=json.dumps({'outer':outer,'decodedRaw':inner},ensure_ascii=False,separators=(',',':'))
                    extracts.append(str(n)+': '+line)
                extracts += ['```','']
        (out/'R8-逐行证据摘录.md').write_text('\n'.join(extracts),encoding='utf-8')
    (out/'R8-证据核对.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    if result['manifest']['matched'] != result['manifest']['checked'] or result['manifest']['extra_entries']:
        raise ValueError('Manifest mismatch')
    print(json.dumps({'manifest':str(result['manifest']['matched'])+'/'+str(result['manifest']['checked']),
          'runs':[{k:v for k,v in x.items() if k in ['path','recorded_result','assertions','passed','failed','unique_assertion_names','as2_records']} for x in result['runs']]},ensure_ascii=False,indent=2))

if __name__=='__main__':
    if len(sys.argv)!=3:
        raise SystemExit(__doc__)
    audit(pathlib.Path(sys.argv[1]),pathlib.Path(sys.argv[2]))
