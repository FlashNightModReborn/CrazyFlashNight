﻿/**
 * 战技路由器 - 容器化战技支持
 *
 * 目的：将所有"战技启动的跳帧入口"收口到统一路由
 *
 * 依赖：RoutingLifecycle（生命周期/浮空/结束清理），引擎_fs_路由基础.as 保留为旧资源兼容门面
 *
 * 与技能路由的区别：
 *   - 技能路由处理的是"技能"状态（技能槽触发的主动技能）
 *   - 战技路由处理的是"战技"状态（武器绑定的主动战技）
 *   - 战技由装备的主动战技配置触发，走 _root.主动战技函数 链路
 *   - 二者共享武器加成逻辑（根据技能名判断空手/技能）
 *
 * API说明：
 *   - 战技标签跳转_旧(unit, skillName, playbackMode): 战技声明可选播放方式，缺省沿用角色模板
 *   - 战技man载入后跳转_旧(man, unit): man加载完成后跳转到战技帧（旧实现，非主角-男使用）
 *   - 载入后跳转战技容器(container, unit): 容器化战技入口（主角-男使用）
 *
 * @author flashNight
 * @version 3.0 - 容器化完成，移除兼容性分支
 */


_root.战技路由 = {};

/**
 * 战技标签跳转（旧实现）
 * 用于外部代码触发战技时调用，如主动战技函数.释放等场景
 * 容器化战技跳过此步骤（由载入后跳转战技容器处理）
 *
 * @param unit:MovieClip 执行战技的单位（需要有man子剪辑）
 * @param skillName:String 战技名称（对应man时间轴上的帧标签）
 * @return MovieClip 本次实际装入的动作；缺失时 undefined，避免重名旧 man 延迟卸载造成误判
 * @param playbackMode:String 可选，由战技定义声明container；缺省沿用角色模板
 */
_root.战技路由.战技标签跳转_旧 = function(unit:MovieClip, skillName:String, playbackMode:String):MovieClip {
    unit.技能名 = skillName;
    RoutingLifecycle.ensureTempY(unit);

    // 兼容战技元件 onClipEvent(load) 的旧逻辑：hp<=0 时直接进入血腥死
    if (unit.hp <= 0) {
        unit.状态改变("血腥死");
        return;
    }

    // 进入战技状态（容器化与旧跳帧都依赖该状态载入man）
    unit.状态改变("战技");

    RoutingLifecycle.preparePoseAndBonus(unit);

    // AI 事件：战技释放开始（供日志/分析/未来响应式系统）
    if (unit.dispatcher != undefined && unit.dispatcher != null) {
        unit.dispatcher.publish("skillStart", unit, skillName);
    }

    // 战技可声明容器播放；没有声明时沿用角色模板默认值。
    if (playbackMode == "container" || unit.兵种 === "主角-男") {
        return _root.战技路由.载入后跳转战技容器(unit.container, unit);
    }

    // 回退：传统man跳帧逻辑
    var newMan:MovieClip = unit.man;
    RoutingLifecycle.bindMovement(newMan);
    RoutingLifecycle.bindEndCleanup(newMan, unit, undefined, "技能结束", "技能浮空");
    _root.战技路由.战技man载入后跳转_旧(newMan, unit);
    return newMan;
};

/**
 * 战技man载入后跳转（旧实现）
 * 用于man剪辑加载完成后，根据unit.技能名跳转到对应帧
 * 典型场景：主角进入"战技"状态时，man加载后的第一帧调用
 *
 * @param man:MovieClip man剪辑自身
 * @param unit:MovieClip man的父级单位（通过unit.技能名获取目标帧）
 */
_root.战技路由.战技man载入后跳转_旧 = function(man:MovieClip, unit:MovieClip):Void {
    man.gotoAndPlay(unit.技能名);
};

/**
 * 容器化战技入口（从"战技容器"状态的container onClipEvent(load)调用）
 * 入口已由战技标签跳转_旧统一判断，此处直接执行容器化逻辑
 *
 * @param container:MovieClip 战技容器状态下的占位容器（保持不可见）
 * @param unit:MovieClip 执行战技的单位
 */
_root.战技路由.载入后跳转战技容器 = function(container:MovieClip, unit:MovieClip):MovieClip {
    var 技能名:String = unit.技能名;
    var initObj:Object = RoutingLifecycle.buildPublicContainerInit(container);
    var attachResult:Object = ContainerAttachAction.attach(unit, ContainerSpec.KIND_BATTLE_SKILL, 技能名, initObj);
    if (attachResult.status !== ContainerAttachAction.STATUS_OK) {
        // 同 技能路由 短路理由：missing 容器时 handleFloat 仍会把 unit.浮空 等字段写脏，
        // 且无 onUnload 回收路径 — 静默跳过 lifecycle 而非"继续跑下游"。
        return;
    }
    var newMan:MovieClip = attachResult.man;

    RoutingLifecycle.handleFloat(newMan, unit, "技能浮空");
    RoutingLifecycle.bindEndCleanup(newMan, unit, undefined, "技能结束", "技能浮空");
    return newMan;
};

// ============================================================================
// 【兼容性实现参考 - 符号缺失时的回退处理】
// 用于渐进式容器化阶段，容器符号不存在时回退到旧帧跳帧逻辑
// ============================================================================
// _root.战技路由.载入后跳转战技容器 = function(container:MovieClip, unit:MovieClip):Void {
//     var 技能名:String = unit.技能名;
//     var initObj:Object = RoutingLifecycle.buildPublicContainerInit(container);
//     var newMan:MovieClip = unit.attachMovie("战技容器-" + 技能名, "man", 0, initObj);
//     if (newMan == undefined) {
//         _root.发布消息("战技容器-" + 技能名 + "符号缺失，尝试回退到旧跳帧逻辑");
//         unit.gotoAndStop("战技");
//         var fallbackMan:MovieClip = unit.man;
//         if (fallbackMan != undefined) {
//             RoutingLifecycle.bindMovement(fallbackMan);
//             RoutingLifecycle.bindEndCleanup(fallbackMan, unit, undefined, "技能结束", "技能浮空");
//             _root.战技路由.战技man载入后跳转_旧(fallbackMan, unit);
//         }
//         return;
//     }
//     _root.发布消息("战技容器-" + 技能名 + "加载完成，进入容器化战技逻辑");
//     RoutingLifecycle.handleFloat(newMan, unit, "技能浮空");
//     RoutingLifecycle.bindEndCleanup(newMan, unit, undefined, "技能结束", "技能浮空");
// };
// ============================================================================

/**
 * 动画完毕处理
 * @param enableDoubleJump:Boolean 可选，传入true则保留空中二段跳特性
 */
_root.战技路由.动画完毕 = function(man:MovieClip, unit:MovieClip, enableDoubleJump:Boolean):Void {
    RoutingLifecycle.completeAnimation(man, unit, enableDoubleJump);
};
