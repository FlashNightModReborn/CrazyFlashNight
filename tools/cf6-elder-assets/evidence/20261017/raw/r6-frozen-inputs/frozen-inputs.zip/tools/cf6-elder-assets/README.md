# CF6 老头与老头机器人装配

本目录维护人形 R7、机器人 R7 和角色局部变形的确定性 XFL 装配。用户指定人形为阶段 8／档次系数 9，机器人为阶段 8／档次系数 20；默认先人形、再生成机器人，目标是对方舟兽王及 EXUSIAI 指挥官造成明显威胁但最终落败。工作区改动暂缓提交，等待用户验收。

## 真源与入口

- 唯一编辑工程：`flashswf/arts/new/Codex老头素材/Codex老头素材.xfl`，由本目录生成器装配并交给真实 CS6 发布。
- 原稿：`flashswf/arts/new/Codex素材源稿/CF6老头人形-R7`、`CF6老头机器人-R7`、`CF6老头变形-R2`。每份 `archive-origin.json` 绑定收到的原始 ZIP 和保留文件；包内 Python 只作历史来源，不执行。
- 人形注册：兵种 471，`敌人-CF6老头人形`，默认 50 级、身高 180。
- 机器人注册：兵种 472，`敌人-CF6老头机器人`，默认 50 级、身高 190。
- 两者从同一 `Codex老头素材` 共享锚点经 `things-new.fla` 第 4 帧装载；锚点显式包含两种形态。Include 的 itemID 必须等于对应 DOMSymbolItem 的实际 itemID。

## 动作与适配

| 形态 | 原动作 | 帧数 | 伤害触发帧 | CF7 行为 |
|---|---|---:|---|---|
| 人形 | 970 连射 | 53 | 13、21、29、37 | 四发普通子弹，每发空手攻击力 ×1 |
| 人形 | 972 刺击 | 34 | 7 | 物理近战 ×1，随后有界推进 |
| 机器人 | 994 光束 | 64 | 29 | 波属性魔法 ×1，沿实际光束区域 |
| 机器人 | 997 连踢 | 40 | 9、26 | 两次物理近战 ×1，保留两次推进段 |
| 机器人 | 1007 砸击 | 62 | 37 | 物理近战 ×1，较大的接触区域 |

人形使用原 12／13 帧受击分支和 89 帧倒地恢复；独立人形死亡在原停止帧 31 注销。机器人使用 12／13 帧短受击、不浮空；111 帧死亡演出由身体内部时钟完成。暂停、硬直和旧动作 token 不允许新增攻击。近战区域子弹、普通子弹、冲击和伤害结算均走现有 CF7 入口，没有直接扣目标 HP。

身体使用收到的最新版矢量稿。共用刺刀 484 在原包仍为位图，本目录的 `bayonet.svg` 保留其原轮廓与配准，明确改为原生矢量；金色仍由原时间轴颜色变换产生。原位图枪口与机器人爆炸改用已装载的 CF7 枪火／火花／小烟雾，不把参考位图带入运行库。

## 连续两阶段

人形默认 `老头变身=true`；显式 `false`、`0`、`"false"`、`"0"` 使用独立人形。非法值明确诊断并关闭变身。关卡人数留给机器人阶段结算，人形不重复掉钱；经验沿用标准死亡检测。

变形采用原 2008 的前 93 帧角色部分，换入当前两份 R7 分件，保留身体替换顺序和过渡碎片。原 94–283 帧全屏放大、主角立绘、场景跳转和音乐控制保存在原稿中，不执行为战斗单位脚本。这里不是完整剧情过场的接入声明。

第 93 帧只尝试生成一次机器人。继承位置、方向、等级、阵营和产生源；不继承旧 HP、MP、面板或 Buff。普通对象 token 绑定世界、父实例、身体和新实例，初始化版本及上下文一致后才显示后继、退出前阶段。返回为空、名称碰撞、身份丢失、上下文不一致或初始化超时均进入明确错误状态，不自动重放生成。

## 构建与验证

在仓库根目录执行；PowerShell 先 `chcp.com 65001`：

```powershell
python -X utf8 -B tools/cf6-elder-assets/build.py --import-approved
python -X utf8 -B tools/cf6-elder-assets/build.py --check
python -X utf8 -B tools/cf6-elder-assets/balance.py --write
python -X utf8 -B tools/cf6-elder-assets/balance.py
python -X utf8 -B tools/cf6-elder-assets/register.py --write
node tools/derive-arena-unit-catalog.js
node tools/derive-arena-unit-catalog.js --check
scripts/compile_test.ps1 -Target 'flashswf/arts/new/Codex老头素材/Codex老头素材.xfl' -PublishOnly -VerifySwf 'flashswf/arts/new/Codex老头素材.swf'
scripts/run-cf6-elder-asset-tests.ps1
scripts/run-cf6-elder-render-tests.ps1 -Probe
scripts/run-cf6-elder-render-tests.ps1
```

共享锚点发生变化时另发布 `flashswf/arts/things-new.fla`，验证对应 `things-new.swf` 的实际 Import 记录。图像导出用 render runner 的 `-Capture`，其运行时间较长；完整集必须由 `decode-native-capture.py` 默认模式核对，`--partial` 只用于在途预览。

`balance.py` 从同一怪物工作簿公式计算面板，`balance-inputs.json` 记录动作前后摇、伤害类型倍率、有效段数和自由分配量；不手改生成 XML。`arena-plan.js` 使用两套已隔离的资源和候选 runtime，固定敌方身份并交换阵营，所有失败、超时和胜局都须保留。原生绘制、候选斗兽结果和用户实际观感分别记录，均不自动构成正式 runtime 发布或用户验收。

## 当前验证状态

施工中。行为版 R2 已通过 445 项断言（32 组动作、13 组阶段），但随后完整绘制发现机器人身体未进入实际 SWF；因此该版不能交付。原绘制失败和没有进入有效战斗的 `bridge_lost` 试跑均保留，当前正在修正并重验原生闭包。最终身份和实战结论以本目录后续证据包为准。
