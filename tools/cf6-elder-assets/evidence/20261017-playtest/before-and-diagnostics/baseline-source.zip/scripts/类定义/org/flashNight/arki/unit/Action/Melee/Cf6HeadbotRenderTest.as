﻿import flash.display.BitmapData;
import flash.geom.Matrix;

/** Every source frame is drawn by Flash; isolated fixture, no save or combat writes. */
class org.flashNight.arki.unit.Action.Melee.Cf6HeadbotRenderTest {
    private static var library:MovieClip,driver:MovieClip,actor:MovieClip,loader:MovieClipLoader;
    private static var listener:Object,bitmap:BitmapData,points:Array;
    private static var tickCount:Number,index:Number,passed:Number,failed:Number,settle:Number;
    private static var loaded:Boolean,done:Boolean;
    private static var activeState:String;
    private static function check(value:Boolean,label:String):Void {
        if(value)passed++;else{failed++;trace("[TEST_FAIL] Cf6HeadbotRenderTest: "+label);}
    }
    public static function runAllTests():Void {
        tickCount=index=passed=failed=settle=0;loaded=done=false;points=[];activeState="";
        var states:Array=["空手站立","空手攻击","近战","被击","血腥死"];
        var counts:Array=[45,18,37,25,58],tags:Array=["stand","beam","thrust","hit","death"];
        var selected:Object={},keys:Array=["stand-1","stand-22","beam-3","beam-11","thrust-3","thrust-12","hit-1","hit-7","death-1","death-15","death-30","death-45","death-58"];
        for(var keyIndex:Number=0;keyIndex<keys.length;keyIndex++)selected[keys[keyIndex]]=true;
        for(var s:Number=0;s<states.length;s++)for(var f:Number=1;f<=counts[s];f++) {
            var key:String=tags[s]+"-"+f;
            points.push({state:states[s],frame:f,key:key,side:0,capture:selected[key]===true});
        }
        points.push({state:"空手攻击",frame:3,key:"beam-left-3",side:1,capture:true});
        points.push({state:"近战",frame:12,key:"thrust-left-12",side:1,capture:true});
        points.push({state:"血腥死",frame:30,key:"death-left-30",side:1,capture:true});
        if(_root.headbotRenderFrames!=undefined){
            var keys:Array=_root.headbotRenderFrames,wanted:Object={},selectedPoints:Array=[];
            for(var keyIndex:Number=0;keyIndex<keys.length;keyIndex++)wanted[keys[keyIndex]]=true;
            for(var pointIndex:Number=0;pointIndex<points.length;pointIndex++)if(wanted[points[pointIndex].key]===true){
                points[pointIndex].capture=true;selectedPoints.push(points[pointIndex]);
            }
            check(selectedPoints.length==keys.length,"selected frame keys exist exactly once");
            points=selectedPoints;
        }
        library=_root.createEmptyMovieClip("__headbotRenderLibrary",_root.getNextHighestDepth());
        driver=_root.createEmptyMovieClip("__headbotRenderDriver",_root.getNextHighestDepth());
        library._visible=false;_root.gameworld=library;
        _root.暂停=true;_root.是否阴影=true;_root.控制目标="__none";_root.控制目标全自动=false;
        _root.播放音效=function():Void {};_root.发布消息=function():Void {};_root.效果=function():Void {};
        _root.敌人函数={配置音效:function():Void {}};
        _root.初始化思考标签=function(mc:MovieClip):Void {mc.stop();mc._visible=false;};
        _root.初始化敌人模板=function():Void {
            this.hp=this.hp满血值=1000;this.等级=40;this.名字="原生绘制隔离大头机器人";
            this.状态="空手站立";this.方向="右";this.攻击目标="无";this.是否为敌人=true;
            this._x=this._y=this.Z轴坐标=0;this.myxscale=100;
            this.方向改变=function(direction:String):Void {this.方向=direction;this._xscale=direction=="左"?-100:100;};
            this.动画完毕=function():Void {};this.死亡检测=function():Void {};
            this.swapDepths=function():Void {};this.stop();
        };
        listener={onLoadInit:function(mc:MovieClip):Void {
            mc.stop();mc._visible=false;Cf6HeadbotRenderTest.actor=mc.attachMovie("敌人-CF6大头机器人","probe",mc.getNextHighestDepth());
            Cf6HeadbotRenderTest.loaded=true;Cf6HeadbotRenderTest.tickCount=0;
        },onLoadError:function(mc:MovieClip,error:String):Void {Cf6HeadbotRenderTest.check(false,"load "+error);Cf6HeadbotRenderTest.finish();}};
        loader=new MovieClipLoader();loader.addListener(listener);bitmap=new BitmapData(1100,500,true,0);
        check(loader.loadClip("../flashswf/arts/new/Codex大头机器人素材.swf",library),"load published SWF");
        driver.onEnterFrame=function():Void {Cf6HeadbotRenderTest.tick();};
    }
    private static function tick():Void {
        if(done)return;tickCount++;
        if(!loaded){if(tickCount>300){check(false,"load timeout");finish();}return;}
        if(tickCount<4)return;
        if(index>=points.length){finish();return;}
        var point:Object=points[index];
        if(activeState!=point.state){
            activeState=point.state;actor.状态改变(point.state);settle=2;return;
        }
        if(settle>0){settle--;return;}
        index++;actor.方向改变(point.side==0?"右":"左");actor.man.gotoAndStop(point.frame);
        actor.man.headbotShadow.updateHeadbotShadow();
        check(actor.man._currentframe==point.frame,"actual body frame "+point.key);
        var matrix:Matrix=actor.man.transform.matrix,sign:Number=point.side==0?1:-1;
        matrix.a*=1.2*sign;matrix.c*=1.2*sign;matrix.b*=1.2;matrix.d*=1.2;
        matrix.tx=matrix.tx*1.2*sign+(point.side==0?180:920);matrix.ty=matrix.ty*1.2+330;
        bitmap.fillRect(bitmap.rectangle,0);var start:Number=getTimer();bitmap.draw(actor.man,matrix);
        var first:Number=getTimer()-start,durations:Array=[];
        for(var i:Number=0;i<3;i++) {
            bitmap.fillRect(bitmap.rectangle,0);start=getTimer();bitmap.draw(actor.man,matrix);durations.push(getTimer()-start);
        }
        var visible:Number=0;
        for(var y:Number=0;y<500;y+=5)for(var x:Number=0;x<1100;x+=5)if((bitmap.getPixel32(x,y)>>>24)>0)visible++;
        check(visible>0,"nonempty native drawing "+point.key);
        if(_root.headbotRenderCapture===true && point.capture)capture(point.key);
        trace("[HEADBOT_RENDER_SAMPLE] key="+point.key+" firstMs="+first+" repeatMs="+durations.join(",")+" pixels="+visible);
    }
    private static function capture(key:String):Void {
        trace("[HEADBOT_IMAGE_BEGIN] "+key+" 1100 500");
        // Native bounds avoid reading the transparent letterbox pixel by pixel.
        // Mask all channels: a transparent pixel with nonzero RGB is still retained.
        var bounds:Object=bitmap.getColorBoundsRect(0xffffffff,0,false);
        var left:Number=bounds.x,right:Number=bounds.x+bounds.width;
        for(var row:Number=0;row<500;row++) {
            if(row<bounds.y || row>=bounds.y+bounds.height || bounds.width==0){
                trace("[HEADBOT_IMAGE_ROW] "+key+" "+row+" 00000000:1100");continue;
            }
            var parts:Array=[];
            if(left>0)parts.push("00000000:"+left);
            var last:Number=bitmap.getPixel32(left,row),count:Number=1;
            for(var col:Number=left+1;col<right;col++) {
                var value:Number=bitmap.getPixel32(col,row);
                if(value==last)count++;else{parts.push(pixelHex(last)+":"+count);last=value;count=1;}
            }
            parts.push(pixelHex(last)+":"+count);
            if(right<1100)parts.push("00000000:"+(1100-right));
            trace("[HEADBOT_IMAGE_ROW] "+key+" "+row+" "+parts.join(","));
        }
        trace("[HEADBOT_IMAGE_END] "+key);
    }
    private static function pixelHex(value:Number):String {
        var digits:String="0123456789abcdef",text:String="";
        for(var shift:Number=28;shift>=0;shift-=4)text+=digits.charAt((value>>>shift)&15);
        return text;
    }
    private static function finish():Void {
        if(done)return;done=true;delete driver.onEnterFrame;
        loader.removeListener(listener);bitmap.dispose();library.removeMovieClip();driver.removeMovieClip();
        trace("Cf6HeadbotRenderTest: "+passed+" passed, "+failed+" failed; "+index+" draw points");
        _root.cf6HeadbotRenderComplete();
    }
}