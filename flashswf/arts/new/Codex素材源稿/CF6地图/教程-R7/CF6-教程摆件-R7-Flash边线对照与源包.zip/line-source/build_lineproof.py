from pathlib import Path
from lxml import etree as E
import copy,json,hashlib,re
P=Path(__file__).parent;S='http://www.w3.org/2000/svg'
source=P/'reference/r6-neutral.svg'
# These are existing true model silhouette/hard crease edges, already clipped
# against nearer geometry by the R6 depth-plane visibility solver.
# Filled faces and their anti-crack same-fill boundaries are NOT outlined.
profiles={'moderate':{'outer':.78,'crease':.43,'small_outer':.29,'small_crease':.20},'bold':{'outer':1.08,'crease':.58,'small_outer':.40,'small_crease':.25}}
def styled(src,profile):
 r=E.parse(str(src)).getroot();g=r.xpath('//*[@id="geometry-derived-furniture-r6"]')[0];counts={'silhouette':0,'crease':0,'small':0}
 for n in g:
  # Direct model-generated shapes only; never traverse original M134 subtree.
  part=n.get('data-model-part');sw=n.get('stroke-width');stroke=n.get('stroke')
  if not part or E.QName(n).localname!='path':continue
  small=part.startswith(('keyboard_key','keyboard_spacebar','cabinet_handle','computer_drawer_handle'))
  if stroke=='#172e3c' and sw=='.37':
   n.set('stroke','#090f14');n.set('stroke-width',str(profile['small_outer' if small else 'outer']));n.set('data-line-class','visible-silhouette');counts['silhouette']+=1;counts['small']+=small
  elif stroke=='#405966' and sw=='.2':
   n.set('stroke','#182329');n.set('stroke-width',str(profile['small_crease' if small else 'crease']));n.set('data-line-class','structural-crease');counts['crease']+=1
 return r,counts
def save(root,path):E.ElementTree(root).write(str(path),encoding='utf-8',xml_declaration=True)
def crop(root,view,name,width=1400):
 r=copy.deepcopy(root);x,y,w,h=view;r.set('viewBox',' '.join(map(str,view)));r.set('width',str(width));r.set('height',str(width*h/w));save(r,P/'art'/name)
roots={'r6-original':E.parse(str(source)).getroot()};audit={}
for name,profile in profiles.items():
 r,counts=styled(source,profile);roots[name]=r;audit[name]={'weights_game_units':profile,'modified_true_edges':counts}
 save(r,P/'art'/f'full-group-{name}.svg')
 tr=copy.deepcopy(r)
 for n in list(tr):
  if E.QName(n).localname=='rect':tr.remove(n)
 save(tr,P/'art'/f'transparent-{name}.svg')
 # Rendered game-scale check: same art, 2x source-game pixels, no new camera.
 c=copy.deepcopy(r);c.set('width','770');c.set('height','440');save(c,P/'art'/f'game-scale-{name}.svg')
 crop(r,[24,-25,194,70],f'bed-{name}.svg')
 crop(r,[185,43,163,140],f'workbench-{name}.svg',1000)
 pr,_=styled(P/'reference/r6-pc-closeup.svg',profile);save(pr,P/'art'/f'computer-{name}.svg')
# Same-camera comparison at modest size, not three massive copies.
board=E.Element('{'+S+'}svg',nsmap={None:S},viewBox='0 0 385 690',width='1155',height='2070')
def el(p,t,**a):return E.SubElement(p,'{'+S+'}'+t,**{k.replace('_','-'):str(v) for k,v in a.items()})
el(board,'rect',width=385,height=690,fill='#26343c')
for idx,(key,label) in enumerate([('r6-original','R6 | original thin edges'),('moderate','R7-A | moderate Flash outlines'),('bold','R7-B | bold Flash outlines')]):
 yy=idx*230
 el(board,'rect',x=0,y=yy,width=385,height=10,fill='#16242b');t=el(board,'text',x=7,y=yy+7,font_family='sans-serif',font_size=5,fill='#d1dbd8');t.text=label
 # Namespace every panel's defs so comparisons cannot accidentally mix gradients.
 rr=copy.deepcopy(roots[key]);ids={n.get('id'):f'panel{idx}-'+n.get('id') for n in rr.iter() if n.get('id')}
 for n in rr.iter():
  for k,v in list(n.attrib.items()):
   if k=='id':n.set(k,ids[v]);continue
   v=re.sub(r'url\(#([^)]*)\)',lambda m:'url(#'+ids.get(m.group(1),m.group(1))+')',v)
   n.set(k,v)
 g=el(board,'g',transform=f'translate(35 {yy+40})')
 for n in rr:g.append(n)
save(board,P/'art'/'r6-r7-lineweight-comparison.svg')
# Exact preservation audit: no path geometry/fills/transforms or weapon changed.
orig=E.parse(str(source)).getroot();og=orig.xpath('//*[@id="geometry-derived-furniture-r6"]')[0]
for name in profiles:
 rg=roots[name].xpath('//*[@id="geometry-derived-furniture-r6"]')[0]
 audit[name]['geometry_fills_transforms_unchanged']=all(a.get('d')==b.get('d') and a.get('fill')==b.get('fill') and a.get('transform')==b.get('transform') for a,b in zip(og,rg))
 a=og.xpath('.//*[@id="repository-M134"]')[0];b=rg.xpath('.//*[@id="repository-M134"]')[0]
 audit[name]['M134_subtree_byte_identical']=E.tostring(a)==E.tostring(b)
 audit[name]['root_viewBox_unchanged']=orig.get('viewBox')==roots[name].get('viewBox')
audit['source_svg_sha256']=hashlib.sha256(source.read_bytes()).hexdigest();audit['method']='Restyle ONLY pre-existing depth-clipped true mesh silhouette and noncoplanar crease paths. No face tessellation, clipping boundary or coplanar triangulation outlines. Small keycaps/handles receive reduced weights.'
(P/'lineproof-audit.json').write_text(json.dumps(audit,indent=2));print(audit)
