# R6 原始证据摘录
所有 L 行号均对应输入 ZIP 内原文件；未改写摘录。此文件由静态读取产生，不代表重新执行测试。

## 01-request.md:L1–L24
```text
L1: # R6 裁决请求：真实 AVM1 取消语义仍缺口
L2: 
L3: 请先读本文件、02-report.md 和 evidence/final/summary.json，再审阅 src。你裁决的是当前协议如何证明取消，不是确认所有焦点问题已根治。
L4: 
L5: ## 已完成与不得混淆
L6: - 已复现并修补：焦点不变且坐标在按钮内，源 F 的 WM_MOUSELEAVE 使 AS2 反复 rollOut。原始真实 Flash 切片修补前 8/15，修补后 15/15；每档十次单击恢复十次 press/release。
L7: - 已补正：P 离开 (-1,-1) 哨兵经 DPI 链变正坐标，最终保留明确离开哨兵为负坐标。
L8: - 最终真实 Flash 扩展 33/34；只有 fresh_click_after_focus_return 失败。同进程窗口和独立进程切出都见到该反例。
L9: - 原生 27 项、G1 queue 55 项、Host 5714 pass/4 skip 不能代签这个 AS2 失败。
L10: 
L11: ## 反例链
L12: AS2 press 已发生；保持按住切到独立进程；Host 撤销并提升 floor；原 WndProc WM_CANCELMODE 返回且 native cancel ACK；旧 Up stale 拒绝；真实返回后 fresh Down/Up 都进原 WndProc，却只有 AS2 release 没有新的 press。无后台夺回前台，也没在切出时执行 release。这显示 native cancel ACK 不等于 AVM1 手势清空。
L13: 
L14: ## 约束
L15: 不改真实存档；不自动补发 MouseUp 或重放点击；不靠固定延时/重复抢焦/重载游戏掩盖；不把 onReleaseOutside 无条件当无副作用；保持外部应用前台所有权。现役主游戏 AS2 尚未修改，fixture 的 AS2 只有两个按钮并回传事件，不加载游戏。
L16: 
L17: ## 请输出
L18: 1. 对反例和证据强度的判断，指出尚需的最小观测。
L19: 2. 是否存在保留当前 Flash 宿主、无业务 release 副作用的可证取消路径；若有，给出状态机/前置条件/反例矩阵，而不是一句补 Up。
L20: 3. 若需要 AS2 协作，最小协议及如何覆盖旧按钮/跨 SWF；区分迁移按钮和未迁移按钮，不能假设全局 Mouse listener 能阻止所有按钮回调。
L21: 4. R6 悬停窄修补可否独立人验，以及该缺口如何约束 C1/B；不要把源码成立、模拟输入、小样或维护者体验升级为正式发布。
L22: 5. 推荐一条最小可验证施工路线与明确停止条件。
L23: 
L24: 输入包含当前实现、原始 AS2/Host 日志、最终与失败摘要、未采纳的按下前状态实验摘要及 15 项因果对照 hash。早期被外部窗口遮挡、SetCursorPos 未完整入钩子的探索轮不作为负控。Windows 事件说明只是 API 背景，根因依赖真实实验。
```

## 02-report.md:L1–L58
```text
L1: # 统一输入 R6：悬停根因实验、窄修补与取消语义边界
L2: 
L3: **文档角色**：本轮真实 Flash 实验和候选交付记录；阶段权威仍为[施工计划](../统一合成与输入归属-分阶段施工计划-2026-09-22.md)。基线为 `5c02a10360` 加现有未提交工作区，不冒充干净 release tree。
L4: 
L5: ## 结论与范围
L6: 
L7: 真实 Flash 小样复现了“坐标在按钮内、实际焦点未变，却不断 rollOut，点击不响应”。根因实验指向**被覆盖的源窗口 F 的原生 WM_MOUSELEAVE 与呈现窗口 P 的映射鼠标语义冲突**。在映射输入生效时隔离源 LEAVE 后，同一小样的 67%/100% 悬停与各 10 次单击恢复，15/15 通过。未增加自动抢焦、重复点击、扩大命中区或补发 MouseUp；主游戏 AS2/asLoader 没有修改。
L8: 
L9: 扩展验证同时发现：按住按钮切到另一个窗口/进程后，native WM_CANCELMODE 已返回、旧包已被拒绝，但真实 AVM1 仍可能保留旧按下；切回的第一击只有 release、没有 fresh press。扩展是 **30/31**，不能宣布全输入或取消语义已验收。本轮交付是悬停修补的限定待验候选；取消边界另交架构裁决，不以这一候选放行 C1/B 或正式发布。
L10: 
L11: ## 实验与证据
L12: 
L13: 夹具源码及准确操作归 [Flash hover fixture](../../launcher/native/world-compositor/flash-hover-fixture/README.md)。独立 SWF 仅两个动态 MovieClip 按钮，不加载游戏/存档，TCP 只绑定 loopback，回传原生 AS2 rollOver/rollOut/press/release/releaseOutside、坐标与帧号。Host 原样编译生产 Controller/Surface/Bridge，使用实际 x64 projector、broker、DLL 与 WGC；输入是明确标注的 SendInput，不称人工物理输入。
L14: 
L15: CS6 新鲜 `Compiler 0/0` 与对应 SWF 更新见 `tmp/r6-hover-compile-verified.log`、`tmp/r6-hover-compiler.txt`。首次误将 VerifySwf 指向 XFL 子目录导致目标缺失，已纠正为真实发布位置上一级；失败保留在 `tmp/r6-hover-compile.log`，不以首轮 marker 冒充编译验收。publish 未刷新 trace 属正常；真正行为证据来自随后本轮 AS2 TCP 回执。
L16: 
L17: | 样本 | 结果 | 准确解释 |
L18: |---|---|---|
L19: | `tmp/r6-hover-baseline/`、`baseline-visible/` | 实验无效 | 实验未取得桌面前台，截图显示 CS6 覆盖；不当产品负控 |
L20: | `tmp/r6-hover-inspect/`、`diagnostic/` | 夹具探索，不作最终对照 | SetCursorPos 未完整刺激低级 hook，AS2 坐标陈旧；后改 SendInput 移动并加坐标断言 |
L21: | `tmp/r6-hover-full-motion/` | 8/15 | 67%/100% 移动样本各 47/53 次 rollOut；坐标仍在 A 内，focus HWND 保持相同；两组各 10 次单击的 press/release 均为 0 |
L22: | `tmp/r6-hover-fixed/` | 15/15 | 同一 Host/SWF，映射期间隔离源 LEAVE；rollOut=0，坐标正确，各 10 press/10 release |
L23: | `tmp/r6-hover-boundaries/` | 30/31 | 真离开/重入、拖出释放、移动/resize/最小化恢复通过；同进程外部窗口交接后 fresh press 缺失 |
L24: | `tmp/r6-hover-cross-process/` | 30/31 | 独立进程确为前台、无后台夺回、无切出时按钮提交；返回首击仍只有 release；证明不局限同进程 Form |
L25: | `tmp/r6-pre-down-experiment/` | 30/31，未采纳 | 临时源码副本把 Down 前的 re-hover 按键状态设为未按下，仍不能消除取消反例；未合入生产源，也不加入候选 |
L26: 
L27: 每轮目录保存 `identity.json`、`as2.jsonl`、`host.log`、截图与 `summary.json`。15 项因果对照的 Host/修补后原生模块与 hash 冻结在 `tmp/r6-causal-pair/`；修补前诊断 DLL 在 `tmp/r6-diagnostic-native/`，修补后在 `tmp/r6-fixed-native/`。只在设置阶段用 computer-use 激活一次已枚举的准确夹具窗口、确认两个按钮可见，再释放 `continue.flag`；观察区间不每次点击前自动激活。测试中的用户返回、独立进程切换和生产 Down 自带 focus 请求另按日志记录。
L28: 
L29: ## 代码变更与安全边界
L30: 
L31: - `InputBridge.cpp`：仅在映射输入 `enabled` 时不把源窗口 WM_MOUSELEAVE 交给 Flash 原 WndProc；真正 P 的离开仍经 Host 映射 outside 点，实际 WM_KILLFOCUS/ENTERMENULOOP 仍撤销资格并关闭此隔离。正常 native LEAVE 在失焦后恢复传递。
L32: - 独立 trace 增加 native pointer 消息、虚拟/物理 Cursor 查询来源、源 LEAVE 隔离事件。Cursor 采样限目标 UI 线程且最长每 250ms 一次或来源改变时一次，保留环覆盖声明；不改变 v4 输入共享映射或发包协议。源 LEAVE 日志不等于 AS2 按钮成功。
L33: - 原生 selftest 新增映射生效时 LEAVE 被隔离、真实失焦后恢复原传递两项。trace analyzer 识别新事件，保持其为 lifecycle observation，不升级成 edge delivery 或业务 ACK。
L34: 
L35: 这里没有证明旧玩家 NPC 难点一定同源，也没有证明真实修改器已经修好；最后一项仍要维护者在配对候选上体验。战斗异常独立保留为 [#119](https://github.com/FlashNightModReborn/CrazyFlashNight/issues/119)，本次不清单位池、不改阵营或真实存档。
L36: 
L37: ## 取消边界的裁决请求
L38: 
L39: 已证：旧 Down 到达 AS2；外部窗口成为前台；共享 floor/原窗口 WM_CANCELMODE 返回；旧 Up 被 stale 拒绝；回到游戏的 fresh Down/Up 都进原 WndProc，但 AS2 只产生 release。**native 取消确认不等于 AVM1 取消确认。** 不由此断言 Flash 绝对不能取消，只说明当前协议没有证明这种语义。
L40: 
L41: 需裁决：能否在保留 Flash 宿主的前提下取得不触发 onRelease/onReleaseOutside 业务的可靠取消；是否要引入 AS2 协作和端点资格确认；以及这条缺口对 C1 的顺序约束。不得默认通过补 MouseUp、自动重放、重载真实游戏或清存档恢复。人类验收只测普通悬停/单击，不用修改器发物品去验证未裁决的持键切出。
L42: 
L43: ## 验证状态
L44: 
L45: 首轮原生 selftest 26 项通过，trace parser 3 项通过；Host 全量 5714 通过、4 跳过，serial-policy marker 通过（`tmp/r6-native-selftest.log`、`tmp/r6-trace-parser-tests.log`、`tmp/r6-host-full.log`）。G1 queue 为 52 项队列/取消检查加 3 项端点 trace 检查通过（`tmp/r6-g1-queue.log`）；仍不代签 AVM1。真实 Flash 扩展的 30/31 失败保留，测试总量不能覆盖该失败。B0-05 旧 100.2569ms / 100ms 性能缺口及历史 Flash oracle 缺口未在此轮解决或重新代签。
L46: 
L47: 补测整个 P 的离开时又发现：Host 的 `(-1,-1)` 无按键哨兵进入坐标转换后，实际 AS2 得到 `(17.5,20.85)` 正坐标，见 `tmp/r6-hover-output-leave/`。这对左上角命中存在残留风险，不能只验证远离角落的两个按钮。最终实现保留这类明确离开哨兵为负坐标，不做屏幕 DPI 换算；普通坐标及有按键拖动仍沿用原转换。新增原生断言后 selftest **27 项通过**（`tmp/r6-final-native-selftest.log`）。最终 Flash 矩阵额外检查 P 离开坐标与重入，结果单独追加，不覆盖旧失败。
L48: 
L49: API 背景：[TrackMouseEvent](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-trackmouseevent) 定义的原窗口离开通知，与 [PhysicalToLogicalPointForPerMonitorDPI](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-physicaltologicalpointforpermonitordpi) 的成功/失败边界；根因与哨兵偏差以本轮实测为证，不用文档替代实际回执。
L50: 
L51: 候选与启动身份在本轮实际构建/启动后追加；不因本文或编译通过宣布 candidate_executed。未提交、推送或正式发布。
L52: 
L53: 
L54: 最终 `tmp/r6-hover-final/summary.json` 为 **33/34**，新增的整个 P 离开/负坐标/重入均通过，唯一保留失败仍为 `fresh_click_after_focus_return`。正式用于候选的三原生模块与最终夹具逐项 SHA 一致，见 `tmp/r6-native-pair.json`。
L55: 
L56: R6 开发候选 `tmp/flash-compositor/game-v4-r6-final-20260923` 已实际启动：17:38:48 Bootstrap ready，Core PID 25288、采集器 PID 14612、FocusTrace session `6b1193a0a118475cb392eff182bf1f1a`。实际路径、启动时间、Core SHA 和本轮配对 manifest 已核对；证据为 `tmp/world-input-run-20260923-173829-662/entry-observed.json`，input cap=0，人验 PENDING。64 项所选源码/诊断输入单独记 hash，不是正式发布闭包。未代选角色或执行业务。
L57: 
L58: 本轮人验只需进入角色，悬停并单击修改器的物品/关卡页签、打开 NPC 对话后取消，确认高亮/提示稳定及每次单击是否可靠；不必重复所有窗口测试，也不用发物品/购买验证未裁决的持键切出。正常退出自动归档。取消边界材料为 `tmp/统一输入-R6取消边界裁决包.zip`（01-request.md 起读），材料未自动外发。未提交、推送或发布正式 runtime。
```

## src/InputBridge.cpp:L80–L106
```text
L80: SHORT KeyValue(int key,bool asynchronous) {
L81:     WrapperScope invocation;
L82:     KeyProc fallback;
L83:     { ReadLock guard; fallback=asynchronous ? realAsync : realKey;
L84:       int mask=ButtonMask(key); if(enabled && mask) { if(shared)InterlockedIncrement(&shared->keyReads); return (buttons&mask) ? static_cast<SHORT>(0x8000) : 0; } }
L85:     return fallback(key);
L86: }
L87: SHORT WINAPI Async(int key) { return KeyValue(key,true); }
L88: SHORT WINAPI Key(int key) { return KeyValue(key,false); }
L89: HWND WINAPI Capture(HWND hwnd) {
L90:     WrapperScope invocation;
L91:     CaptureProc fallback;
L92:     { WriteLock guard; fallback=realCapture; if(enabled && hwnd==target) { HWND previous=captured ? target : nullptr; captured=true; return previous; } }
L93:     return fallback(hwnd);
L94: }
L95: HWND WINAPI GetCapture() {
L96:     WrapperScope invocation;
L97:     GetCaptureProc fallback;
L98:     { ReadLock guard; fallback=realGetCapture; if(enabled && captured)return target; }
L99:     return fallback();
L100: }
L101: BOOL WINAPI Release() {
L102:     WrapperScope invocation;
L103:     ReleaseProc fallback;
L104:     { WriteLock guard; fallback=realRelease; if(enabled) {captured=false; return TRUE;} }
L105:     return fallback();
L106: }
```

## src/InputBridge.cpp:L146–L166
```text
L146: LRESULT Original(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp) {
L147:     Depth depth(dispatchDepth);
L148:     if(shared)InterlockedExchange(&shared->dispatchDepth,dispatchDepth);
L149:     LRESULT result=CallWindowProcW(originalProc,hwnd,msg,wp,lp);
L150:     if(shared)InterlockedExchange(&shared->dispatchDepth,dispatchDepth-1);
L151:     return result;
L152: }
L153: void CancelEndpoint() {
L154:     if(!shared || dispatchDepth) return;
L155:     LONG ticket=ReadAtomic(&shared->cancelTicket);
L156:     if(ticket==ReadAtomic(&shared->cancelledTicket)) return;
L157:     { WriteLock guard; enabled=false; buttons=0; captured=false; activeGesture=0; }
L158:     InterlockedExchange(&shared->heldButtons,0);
L159:     if(reinterpret_cast<WNDPROC>(GetWindowLongPtrW(target,GWLP_WNDPROC))!=WindowProc) {
L160:         InterlockedExchange(&shared->restoreError,1);return; // original cancellation ownership is unconfirmed
L161:     }
L162:     Original(target,WM_CANCELMODE,0,0);
L163:     if(realGetCapture()==target)realRelease();
L164:     InterlockedExchange(&shared->cancelledTicket,ticket);
L165:     Observe(TraceCancel,0,ReadAtomic(&shared->issuedEpoch),WM_CANCELMODE);
L166: }
```

## src/InputBridge.cpp:L213–L291
```text
L213: LRESULT Deliver(HWND hwnd,WPARAM wp,LPARAM lp) {
L214:         UINT kind=static_cast<UINT>(wp)&255;
L215:         // v4 bounded envelope: flags/extra share the low word with v1; the high half carries
L216:         // the 24-bit input epoch, the geometry version, and the packet sequence.
L217:         // The v2 gesture field is gone: gesture ownership is endpoint-local state.
L218:         UINT flags=(static_cast<UINT>(wp)>>8)&127, extra=(static_cast<UINT>(wp)>>16)&0xFFFF;
L219:         UINT epoch=static_cast<UINT>((wp>>32)&0xFFFFFF);
L220:         UINT seq=static_cast<UINT>((static_cast<ULONGLONG>(lp)>>32)&0xFFFFFFFF);
L221:         UINT diagnosticType=kind==0xFE ? WM_CANCELMODE : WM_MOUSEFIRST+kind;
L222:         bool edge=diagnosticType!=WM_MOUSEMOVE;
L223:         if(!shared)return 0;
L224:         if(reinterpret_cast<WNDPROC>(GetWindowLongPtrW(hwnd,GWLP_WNDPROC))!=WindowProc){if(edge)Observe(TraceStopped,seq,epoch,diagnosticType);InterlockedExchange(&shared->stop,1);return 0;}
L225:         InterlockedExchange(&shared->consumedSeq,static_cast<LONG>(seq));
L226:         CancelEndpoint();
L227:         if(ReadAtomic(&shared->stop) || ReadAtomic(&shared->cancelTicket)!=ReadAtomic(&shared->cancelledTicket)) {
L228:             if(edge)Observe(TraceStopped,seq,epoch,diagnosticType);
L229:             InterlockedIncrement(&shared->stoppedRejected);return 0;
L230:         }
L231:         if(epoch==0 || epoch>static_cast<UINT>(InputEpochLimit) || seq==0 || seq>static_cast<UINT>(InputSequenceLimit)) {
L232:             if(edge)Observe(TraceInvalid,seq,epoch,diagnosticType);
L233:             InterlockedIncrement(&shared->invalidRejected);return 0;
L234:         }
L235:         UINT floor=static_cast<UINT>(ReadAtomic(&shared->minEpoch));
L236:         if(floor>static_cast<UINT>(InputEpochLimit+1)) {if(edge)Observe(TraceInvalid,seq,epoch,diagnosticType);InterlockedIncrement(&shared->invalidRejected);InterlockedExchange(&shared->stop,1);return 0;}
L237:         if(epoch<floor || epoch<localFloor) {
L238:             if(edge)Observe(TraceStale,seq,epoch,diagnosticType);
L239:             InterlockedIncrement(&shared->staleRejected);return 0;
L240:         }
L241:         UINT type=kind==0xFE ? WM_CANCELMODE : WM_MOUSEFIRST+kind;
L242:         if(type!=WM_MOUSEMOVE && type!=WM_LBUTTONDOWN && type!=WM_LBUTTONUP
L243:             && type!=WM_RBUTTONDOWN && type!=WM_RBUTTONUP && type!=WM_MBUTTONDOWN && type!=WM_MBUTTONUP
L244:             && type!=WM_XBUTTONDOWN && type!=WM_XBUTTONUP && type!=WM_MOUSEWHEEL && type!=WM_MOUSEHWHEEL && type!=WM_CANCELMODE) return 0;
L245:         lastEpoch=std::max(lastEpoch,epoch);
L246:         POINT point{static_cast<SHORT>(LOWORD(lp)),static_cast<SHORT>(HIWORD(lp))};
L247:         // Registered messages are not DPI-virtualized like native mouse messages.
L248:         // Convert the host's physical client pixels to this projector's DPI space.
L249:         // The host's unheld (-1,-1) leave sentinel is not an on-screen point.
L250:         // Preserve it: an unsuccessful outside-window DPI conversion must not
L251:         // turn it into a positive client point and retain a corner button hover.
L252:         bool presentationLeave=type==WM_MOUSEMOVE && point.x==-1 && point.y==-1 && (flags&0x73)==0;
L253:         if(!presentationLeave) {
L254:             POINT origin{};
L255:             ClientToScreen(hwnd,&origin);
L256:             LogicalToPhysicalPointForPerMonitorDPI(hwnd,&origin);
L257:             point.x+=origin.x; point.y+=origin.y;
L258:             PhysicalToLogicalPointForPerMonitorDPI(hwnd,&point);
L259:             ScreenToClient(hwnd,&point);
L260:         }
L261:         bool down=type==WM_LBUTTONDOWN || type==WM_RBUTTONDOWN || type==WM_MBUTTONDOWN || type==WM_XBUTTONDOWN;
L262:         bool up=type==WM_LBUTTONUP || type==WM_RBUTTONUP || type==WM_MBUTTONUP || type==WM_XBUTTONUP;
L263:         UINT bit=PacketButtonBit(type,extra);
L264:         // Gesture ownership is classified, not trusted: a down for an already-held
L265:         // button is a duplicate; an up/cancel without an open gesture is unowned.
L266:         // Both are still forwarded so the projector's own button state can release.
L267:         // The data envelope carries no gesture id: an admitted down opens the endpoint-owned
L268:         // gesture; the matching release or a cancel closes it again.
L269:         if(down) { if(bit && (buttons&bit)) InterlockedIncrement(&shared->duplicateDowns); activeGesture=1; SetFocus(hwnd); }
L270:         if((up && (!activeGesture || !(buttons&bit))) || (type==WM_CANCELMODE && !activeGesture && !buttons))
L271:             InterlockedIncrement(&shared->unownedReleases);
L272:         { WriteLock guard; enabled=true; virtualPoint=point; buttons=flags&0x73; }
L273:         InterlockedExchange(&shared->heldButtons,static_cast<LONG>(buttons));
L274:         WPARAM nativeFlags=flags;
L275:         LPARAM nativePosition=MAKELPARAM(static_cast<SHORT>(point.x),static_cast<SHORT>(point.y));
L276:         if(type==WM_MOUSEWHEEL || type==WM_MOUSEHWHEEL) {
L277:             nativeFlags=MAKEWPARAM(flags,extra);
L278:             POINT screen=point; ClientToScreen(hwnd,&screen);
L279:             nativePosition=MAKELPARAM(static_cast<SHORT>(screen.x),static_cast<SHORT>(screen.y));
L280:         } else if(type==WM_XBUTTONDOWN || type==WM_XBUTTONUP) nativeFlags=MAKEWPARAM(flags,extra);
L281:         if(type==WM_CANCELMODE) { WriteLock guard; buttons=0; captured=false; activeGesture=0; }
L282:         else if(up && !buttons) activeGesture=0;
L283:         // Activation can clear Flash's hover target. Re-establish the mapped
L284:         // location after focus and before the button edge, on its own UI thread.
L285:         if(down) Original(hwnd,WM_MOUSEMOVE,flags,nativePosition);
L286:         if(edge)Observe(TraceEnter,seq,epoch,type,point);
L287:         else if(static_cast<SHORT>(LOWORD(lp))<0 || static_cast<SHORT>(HIWORD(lp))<0)Observe(TraceLeave,seq,epoch,type,point);
L288:         LRESULT result=Original(hwnd,type,nativeFlags,nativePosition);
L289:         if(edge)Observe(TraceReturn,seq,epoch,type,point);
L290:         InterlockedExchange(&shared->completedSeq,static_cast<LONG>(seq));
L291:         return result;
```

## src/InputBridge.cpp:L293–L359
```text
L293: LRESULT CALLBACK WindowProc(HWND hwnd,UINT message,WPARAM wp,LPARAM lp) {
L294:     Depth depth(procedureDepth);
L295:     if(message==packetMessage)return 0; // only the dequeue hook may admit data
L296:     if(message==controlMessage) {
L297:         if(!shared || static_cast<uint64_t>(lp)!=shared->session)return 0;
L298:         UINT kind=static_cast<UINT>(wp);
L299:         if(kind==ControlPoll) {CancelEndpoint();return 1;}
L300:         if(kind==ControlQuiesce) {
L301:             if(static_cast<LONG>(wp>>32)!=ReadAtomic(&shared->closeTicket))return 0;
L302:             if(hookDepth || dispatchDepth || procedureDepth>1)return 0;
L303:             CancelEndpoint();
L304:             MSG queued{};
L305:             if(PeekMessageW(&queued,target,packetMessage,packetMessage,PM_NOREMOVE))return 0;
L306:             if(buttons || captured || activeGesture)return 0;
L307:             LONG ticket=ReadAtomic(&shared->closeTicket);
L308:             if(!ticket)return 0;
L309:             InterlockedExchange(&shared->quiescedTicket,ticket);return 1;
L310:         }
L311:         if(kind==ControlRetire) {
L312:             if(!ReadAtomic(&shared->stop) || static_cast<LONG>(wp>>32)!=ReadAtomic(&shared->closeTicket))return 0;
L313:             return Restore() ? 1 : 0;
L314:         }
L315:         if(kind==ControlRepaint && !ReadAtomic(&shared->stop)) {
L316:             LONG ticket=static_cast<LONG>(wp>>32);
L317:             if(!ticket || ticket!=ReadAtomic(&shared->paintTicket))return 0;
L318:             LONGLONG after=ReadAtomic64(&shared->paintRequestTicks);
L319:             RECT bounds{};GetClientRect(hwnd,&bounds);
L320:             if(lastPaintTicks<after || !EqualRect(&bounds,&lastPaintBounds))
L321:                 if(!RedrawWindow(hwnd,nullptr,nullptr,RDW_INVALIDATE|RDW_UPDATENOW|RDW_ALLCHILDREN))return 0;
L322:             GdiFlush();
L323:             if(lastPaintTicks<after || !EqualRect(&bounds,&lastPaintBounds))return 0;
L324:             if(ticket!=ReadAtomic(&shared->paintTicket))return 0;
L325:             InterlockedExchange64(&shared->paintResultTicks,lastPaintTicks);
L326:             InterlockedExchange(&shared->paintAck,ticket);return 1;
L327:         }
L328:         return 0;
L329:     }
L330:     // Flash arms TrackMouseEvent after the mapped WM_MOUSEMOVE. The physical
L331:     // pointer is over P, not this covered source F, so Windows immediately emits
L332:     // a source-window LEAVE even when the mapped pointer remains over a button.
L333:     // While mapped input owns hover, only the host's mapped outside point may
L334:     // leave it. Actual focus/menu revocation below still disables this guard.
L335:     if(enabled && message==WM_MOUSELEAVE) {
L336:         Observe(TraceSourceLeaveSuppressed,0,lastEpoch,message,virtualPoint);
L337:         return 0;
L338:     }
L339:     if(message==WM_MOUSELEAVE || message==WM_MOUSEHOVER || message==WM_CAPTURECHANGED || message==WM_SETFOCUS) {
L340:         Observe(TraceNativePointer,0,lastEpoch,message,virtualPoint);
L341:     }
L342:     if(message==WM_ENTERMENULOOP || message==WM_KILLFOCUS) {
L343:         { WriteLock guard; enabled=false; buttons=0; captured=false; activeGesture=0; }
L344:         if(shared) {
L345:             InterlockedExchange(&shared->heldButtons,0);
L346:             UINT issued=static_cast<UINT>(ReadAtomic(&shared->issuedEpoch));
L347:             if(issued>static_cast<UINT>(InputEpochLimit)) {InterlockedIncrement(&shared->invalidRejected);InterlockedExchange(&shared->stop,1);issued=InputEpochLimit;}
L348:             UINT top=std::max(lastEpoch,issued);
L349:             localFloor=std::max(localFloor,std::min(top+1,static_cast<UINT>(InputEpochLimit+2)));
L350:             Observe(TraceFocusLost,0,issued,message);
L351:         }
L352:     }
L353:     if(enabled && message==WM_MOUSEMOVE)return 0;
L354:     LRESULT result=Original(hwnd,message,wp,lp);
L355:     if(message==WM_PAINT) {
L356:         LARGE_INTEGER painted{};QueryPerformanceCounter(&painted);
L357:         lastPaintTicks=painted.QuadPart;GetClientRect(hwnd,&lastPaintBounds);
L358:     }
L359:     return result;
```

## src/InputBridge.h:L35–L62
```text
L35:     volatile LONG minEpoch;          // 56  host->bridge: lowest acceptable input epoch (cancel floor, low 24 bits)
L36:     volatile LONG consumedSeq;       // 60  bridge->host: low 32 of last packet sequence seen by WindowProc
L37:     volatile LONG staleRejected;     // 64  packets rejected by the epoch gates (shared floor or local focus-loss floor)
L38:     volatile LONG stoppedRejected;   // 68  packets rejected while stopping or without shared state
L39:     volatile LONG unownedReleases;   // 72  up/cancel with no open gesture or unheld button (forwarded, counted)
L40:     volatile LONG duplicateDowns;    // 76  down for an already-held button (forwarded, counted)
L41:     volatile LONG issuedEpoch;       // 80  host->bridge: newest epoch handed to the queue (low 24 bits),
L42:                                      //     published before every packet post; read at the focus-loss boundary
L43:     uint32_t reserved;               // 84  tail padding: the struct stays 8-aligned for the uint64 fields
L44:     uint64_t session;                   // 88 immutable control identity
L45:     volatile LONG closeTicket;          // 96 Host seals all producers before publishing stop
L46:     volatile LONG returnedTicket;       // 100 broker: retire SendMessage has RETURNED
L47:     volatile LONG cancelTicket;         // 104 persistent release request
L48:     volatile LONG cancelledTicket;      // 108 endpoint: original cancellation returned
L49:     volatile LONG dispatchDepth;        // 112 endpoint original-handler calls in flight
L50:     volatile LONG hookDepth;            // 116 endpoint getmessage calls in flight
L51:     volatile LONG completedSeq;         // 120 diagnostic original-return, not business ACK
L52:     volatile LONG heldButtons;          // 124 mouse mask only (0x73)
L53:     volatile LONG64 paintRequestTicks;  // 128 serialized repaint request
L54:     volatile LONG paintTicket;          // 136
L55:     volatile LONG paintAck;             // 140
L56:     volatile LONG64 paintResultTicks;   // 144
L57:     volatile LONG invalidRejected;      // 152
L58:     volatile LONG drained;              // 156
L59:     volatile LONG restoreError;         // 160 no successor on any restore error
L60:     volatile LONG targetExited;         // 164 broker observed actual process handle exit
L61:     volatile LONG graceful;            // 168 close mode; producer seal precedes request
L62:     volatile LONG quiescedTicket;       // 172 target UI: queue empty, no callback or held state
```

## src/NativePointerBridge.cs:L74–L94
```text
L74:         public PointerPostStatus Send(in PointerPacket packet,Point point)
L75:         {
L76:             lock(_gate) {
L77:                 if(_closing || _ended)return PointerPostStatus.BridgeClosed;
L78:                 if(GetWindowThreadProcessId(_source,out uint pid)==0 || pid!=_pid)return PointerPostStatus.SourceGone;
L79:                 if(packet.Epoch==0 || packet.Epoch>WorldPointerMapper.EpochLimit || packet.Sequence<1 || packet.Sequence>WorldPointerMapper.SequenceLimit)return PointerPostStatus.BridgeClosed;
L80:                 _state?.WriteIssuedEpoch(packet.Epoch);
L81:                 if(!PostMessage(_source,_message,new IntPtr(WorldPointerMapper.PackWParam(packet.Message,packet.Flags,packet.Data,packet.Epoch,packet.Geometry)),new IntPtr(WorldPointerMapper.PackLParam(point,packet.Sequence))))return PointerPostStatus.PostFailed;
L82:                 return PointerPostStatus.Posted;
L83:             }
L84:         }
L85:         public bool RaiseMinEpoch(uint epoch)
L86:         {
L87:             lock(_gate) {
L88:                 if(_closing || _ended || _state==null)return false;
L89:                 _state.WriteMinEpoch(epoch);
L90:                 _state.RequestCancellation(); // persistent, broker control wakes an otherwise idle endpoint
L91:                 return true;
L92:             }
L93:         }
L94:         public long EndpointConsumedSeq {get {lock(_gate)return _state?.ReadConsumedSeq() ?? -1;}}
```

## src/WorldCompositionSurface.cs:L74–L141
```text
L74:         internal bool RouteCapturedPointer(int x,int y,int message,uint mouseData)
L75:         {
L76:             if (!Visible || IsDisposed || !IsHandleCreated) return false;
L77:             Point screen=new Point(x,y);
L78:             bool owned=WindowFromPoint(screen)==Handle;
L79:             if (_physicalButtons!=0) {
L80:                 GetWindowThreadProcessId(GetForegroundWindow(),out uint pid);
L81:                 GetWindowThreadProcessId(_getFlash(),out uint flashPid);
L82:                 if (pid!=(uint)Environment.ProcessId && pid!=flashPid) { CancelPointer("foreground_lost"); return false; }
L83:             } else if (!owned) {
L84:                 if (_inside) { _inside=false; Enqueue(new PointerPacket(0x2A3,Point.Empty,Point.Empty,0,0,_inputEpoch,0,_geometryVersion,NextSequence())); }
L85:                 return false;
L86:             }
L87:             return IntakePointer(message,screen,mouseData);
L88:         }
L89:         // Queue/gesture intake, split from the WindowFromPoint/foreground checks so
L90:         // tests can drive the envelope path without a topmost physical window.
L91:         internal bool IntakePointer(int message,Point screen,uint mouseData)
L92:         {
L93:             _inside=true;
L94:             int bit=ButtonBit(message,mouseData);
L95:             if(_renewing || _awaitRelease) {
L96:                 if(IsDown(message))_physicalButtons|=bit;
L97:                 if(IsUp(message))_physicalButtons&=~bit;
L98:                 if(!_renewing && _readPhysicalButtons()==0){_awaitRelease=false;_physicalButtons=0;}
L99:                 return message!=0x200;
L100:             }
L101:             if(_awaitFreshDown && !IsDown(message) && message!=0x200)return message!=0x200;
L102:             // Soft boundary waits for an old gesture's release. The hard bound
L103:             // cancels explicitly; no packet can be encoded by masking overflow.
L104:             if((_physicalButtons==0 && (_inputEpoch>=_epochLimit-2 || _sequence>=_sequenceLimit-8))
L105:                 || (IsDown(message) && _physicalButtons==0 && _inputEpoch>=_epochLimit)) {
L106:                 if(IsDown(message))_physicalButtons|=bit;
L107:                 BeginRenewal();return message!=0x200;
L108:             }
L109:             // A physical down with no held buttons starts a new gesture and mints
L110:             // the next input epoch. This is what re-admits input after a focus
L111:             // loss: the projector revokes every epoch issued before its
L112:             // focus-loss boundary, so the first post-loss down must carry a
L113:             // newer epoch — and this advance is the only place that provides one.
L114:             if (IsDown(message) && _physicalButtons==0) { _awaitFreshDown=false;_openGesture=++_gestureSeed; ++_inputEpoch; }
L115:             if (IsDown(message)) _physicalButtons|=bit;
L116:             if (IsUp(message)) _physicalButtons&=~bit;
L117:             Enqueue(new PointerPacket(message,screen,PointToClient(screen),_physicalButtons|Modifiers(),mouseData,_inputEpoch,_openGesture,_geometryVersion,NextSequence()));
L118:             // Consuming a low-level MOVE also freezes the OS cursor itself. Let motion
L119:             // update the physical pointer; the surface's ordinary WndProc does not
L120:             // forward it. Button/wheel edges are exclusively delivered by this queue.
L121:             return message!=0x200;
L122:         }
L123:         private void BeginRenewal()
L124:         {
L125:             if(_renewing)return;
L126:             GracefulRenewal=_postedButtons==0;
L127:             _workGeneration++;_posted=false;
L128:             _renewing=true;_queue.Clear();_openGesture=0;_postedButtons=0;_inputTarget=IntPtr.Zero;
L129:             if(!GracefulRenewal)_bridge.RaiseMinEpoch(WorldPointerMapper.EpochLimit+1);
L130:             LogManager.Log("event=world_pointer_quiesce epoch="+_inputEpoch+" seq="+_sequence);
L131:             // Only queue the coordinator. Never wait for another UI thread inside a hook.
L132:             long generation=_workGeneration;
L133:             if(IsHandleCreated)BeginInvoke(new Action(()=> {if(!IsDisposed && _renewing && generation==_workGeneration)RenewalRequested?.Invoke();}));
L134:         }
L135:         internal void Rebind(IWorldPointerSink sink)
L136:         {
L137:             if(!_renewing)throw new InvalidOperationException("Input was not quiesced");
L138:             _workGeneration++;_posted=false;
L139:             _queue.Clear();_bridge=sink;_inputEpoch=1;_sequence=0;_gestureSeed=0;_openGesture=0;
L140:             _inputTarget=IntPtr.Zero;_postedButtons=0;_physicalButtons=_readPhysicalButtons();
L141:             _awaitRelease=_physicalButtons!=0;_awaitFreshDown=true;_renewing=false;
```

## src/WorldCompositionSurface.cs:L202–L243
```text
L202:         private void Deliver(PointerPacket packet)
L203:         {
L204:             var sink=_bridge;
L205:             IntPtr rootWindow=_getFlash();
L206:             if (rootWindow==IntPtr.Zero || !IsWindow(rootWindow)) { if(_openGesture!=0 || _postedButtons!=0) CancelPointer("source_gone"); return; }
L207:             // A rebuilt target never receives packets chosen for the old one.
L208:             if (_inputTarget!=IntPtr.Zero && rootWindow!=_inputTarget) { CancelPointer("target_rebuilt"); return; }
L209:             if (packet.Message==0x2A3) {
L210:                 if (_postedButtons==0) Post(new PointerPacket(0x200,Point.Empty,Point.Empty,0,0,packet.Epoch,0,packet.Geometry,packet.Sequence),new Point(-1,-1));
L211:                 return;
L212:             }
L213:             if (!Visible || !GetClientRect(rootWindow,out Rect bounds) || bounds.Right<1 || bounds.Bottom<1) return;
L214:             uint geometry=TrackGeometry(new Size(bounds.Right,bounds.Bottom));
L215:             // Packets carry the geometry they were queued under. A stale-geometry
L216:             // packet keeps its physical screen point and is remapped under the
L217:             // current sizes; the old client offset is never applied to a new size.
L218:             Point client=packet.Client;
L219:             if (packet.Geometry!=geometry) {
L220:                 client=PointToClient(packet.Screen);
L221:                 if (packet.Message!=0x200)
L222:                     LogManager.Log("event=world_pointer_remap msg=0x"+packet.Message.ToString("X")+" seq="+packet.Sequence+" geo="+packet.Geometry+"->"+geometry);
L223:             }
L224:             Point point=WorldPointerMapper.Map(client,ClientSize,new Size(bounds.Right,bounds.Bottom));
L225:             bool down=IsDown(packet.Message), up=IsUp(packet.Message);
L226:             int bit=ButtonBit(packet.Message,packet.Data);
L227:             var status=sink.Send(new PointerPacket(packet.Message,packet.Screen,client,packet.Flags,packet.Data,packet.Epoch,packet.Gesture,geometry,packet.Sequence),point);
L228:             if (status!=PointerPostStatus.Posted) {
L229:                 // A failed post must not leave a half-open gesture, and a local
L230:                 // rejection is never evidence of delivery.
L231:                 if (_openGesture!=0 || _postedButtons!=0 || down) CancelPointer("post_"+StatusName(status));
L232:                 else LogManager.Log("event=world_pointer_reject reason="+StatusName(status)+" msg=0x"+packet.Message.ToString("X")+" seq="+packet.Sequence);
L233:                 return;
L234:             }
L235:             if(down) {
L236:                 _inputTarget=rootWindow; _postedButtons|=bit;
L237:                 _focus?.Invoke();
L238:             }
L239:             if(down || up) LogManager.Log("event=world_pointer_posted msg=0x"+packet.Message.ToString("X")+" seq="+packet.Sequence
L240:                 +" epoch="+packet.Epoch+" gesture="+packet.Gesture+" geo="+geometry+" x="+point.X+" y="+point.Y
L241:                 +" source="+bounds.Right+"x"+bounds.Bottom+" session="+((sink as NativePointerBridge)?.SessionIdentity.ToString() ?? "fixture")+" consumed="+sink.EndpointConsumedSeq);
L242:             if(up) { _postedButtons&=~bit; if(_postedButtons==0) _openGesture=0; }
L243:         }
```

## src/WorldCompositionSurface.cs:L264–L288
```text
L264:         // Publish the atomic floor and a persistent release ticket before the
L265:         // advisory cancel data packet. Broker control wakes the endpoint after
L266:         // post failure. Already-admitted original calls are retired separately.
L267:         internal void CancelPointer(string reason="explicit")
L268:         {
L269:             if(_renewing)return;
L270:             _workGeneration++;_posted=false;_queue.Clear();
L271:             if(_inputEpoch>=_epochLimit || _sequence>=_sequenceLimit){BeginRenewal();return;}
L272:             uint epoch=++_inputEpoch;
L273:             bool floor=_bridge.RaiseMinEpoch(epoch);
L274:             bool had=_inputTarget!=IntPtr.Zero || _inside || _postedButtons!=0 || _physicalButtons!=0 || _openGesture!=0;
L275:             _physicalButtons=_postedButtons=0; _inputTarget=IntPtr.Zero; _inside=false; _openGesture=0;
L276:             if (had) {
L277:                 var packet=new PointerPacket(0x1F,Point.Empty,Point.Empty,0,0,epoch,0,_geometryVersion,NextSequence());
L278:                 var status=_bridge.Send(packet,new Point(-1,-1));
L279:                 LogManager.Log("event=world_pointer_cancel epoch="+epoch+" seq="+packet.Sequence+" reason="+reason
L280:                     +" floor="+floor+" post="+StatusName(status)+" consumed="+_bridge.EndpointConsumedSeq);
L281:             } else {
L282:                 LogManager.Log("event=world_pointer_cancel epoch="+epoch+" reason="+reason+" floor="+floor+" post=none");
L283:             }
L284:         }
L285:         private static bool IsDown(int m) => m==0x201 || m==0x204 || m==0x207 || m==0x20B;
L286:         private static bool IsUp(int m) => m==0x202 || m==0x205 || m==0x208 || m==0x20C;
L287:         private static int ButtonBit(int m,uint data) => m>=0x20B && m<=0x20D ? ((data>>16)==1 ? 32 : 64) : m>=0x207 && m<=0x209 ? 16 : m>=0x204 && m<=0x206 ? 2 : 1;
L288:         protected override void OnVisibleChanged(EventArgs e) { if(!Visible)CancelPointer("hidden"); base.OnVisibleChanged(e); }
```

## src/WorldCompositorController.cs:L246–L267
```text
L246:         private async Task RenewInputAsync()
L247:         {
L248:             if(_inputRenewRequested && !_inputClosed) {
L249:                     _starting=true;_inputRenewRequested=false;
L250:                     var old=_pointerBridge;var surface=_surface;var source=_flash;
L251:                     bool closed=await old.CloseAsync(surface.GracefulRenewal);
L252:                     if(_disposed || surface!=_surface || source!=_getFlash())return;
L253:                     if(!closed) {
L254:                         _inputClosed=true;_notify?.Invoke("输入恢复尚未确认，请保留日志后重新启动游戏");
L255:                     } else {
L256:                         try {
L257:                             var next=await NativePointerBridge.Start(source,_owner.Handle);
L258:                             if(_disposed || surface!=_surface || source!=_getFlash()) {next.Dispose();return;}
L259:                             _pointerBridge=next;surface.Rebind(next);InputRenewals++;
L260:                             LogManager.Log("event=world_pointer_renewed session="+next.SessionIdentity+" count="+InputRenewals);
L261:                         } catch(Exception error) {
L262:                             _inputClosed=true;LogManager.Log("event=world_pointer_closed_unconfirmed bind="+error.Message);
L263:                             _notify?.Invoke("输入恢复尚未确认，请保留日志后重新启动游戏");
L264:                         }
L265:                     }
L266:                 }
L267:         }
```

## src/WorldCompositorController.cs:L326–L362
```text
L326:         private void OnGeometryChanged(object sender,EventArgs e)
L327:         {
L328:             _schedulingAllowed=false;
L329:             if (_surface==null || _surface.IsDisposed) return;
L330:             if (!CanShow()) { _surface.Hide(); return; }
L331:             Rectangle screen=_anchor.RectangleToScreen(_anchor.ClientRectangle);
L332:             if (screen.Width<1 || screen.Height<1 || _surface.Bounds==screen) return;
L333:             // Windows' modal move loop can delay the render timer. Move P in the
L334:             // geometry callback itself, preserving its last full-size image and
L335:             // HWND. Hiding it here exposed the 67% DRS child and black remainder.
L336:             _surface.CancelPointer("geometry_changed");
L337:             _surface.Bounds=screen;
L338:             LogManager.Log("event=world_compositor_follow P="+screen+" visible="+_surface.Visible);
L339:         }
L340:         internal static bool TryResolveCaptureFrame(Rectangle extended,Rectangle window,Size content,out Rectangle frame)
L341:         {
L342:             frame=Rectangle.Empty;
L343:             if(content.Width<=0 || content.Height<=0)return false;
L344:             if(content==extended.Size){frame=extended;return true;}
L345:             if(content==window.Size){frame=window;return true;}
L346:             return false; // transition/unknown geometry: do not invent an origin
L347:         }
L348:         private void OnDpiChanged(object sender,DpiChangedEventArgs e) => OnGeometryChanged(sender,e);
L349:         private void OnClosed(object sender,FormClosedEventArgs e) => Dispose();
L350:         // 宿主失活同样撤销在途指针输入：Host 抬共享代次下界，是投影端 WM_KILLFOCUS
L351:         // 本地下界之外的第二道保险。
L352:         private void OnOwnerDeactivated(object sender,EventArgs e) => _surface?.CancelPointer("owner_deactivate");
L353:         private static double NowMs() => Stopwatch.GetTimestamp()*1000.0/Stopwatch.Frequency;
L354:         private void StopCapture()
L355:         {
L356:             _lastGeometryRejection=null;
L357:             _lastCaptureGeneration=0;
L358:             _inputRenewRequested=false;_inputClosed=false;
L359:             _viewportHeld=false; _paintFenceMs=0;
L360:             _everReady=false; _frameAdvancing=false; _progressKnown=false;
L361:             _surface?.Hide();
L362:             try { _native?.Dispose(); } finally { _native=null; _surface?.CancelPointer(); _surface?.Dispose(); _surface=null; if(_pointerBridge!=null)_retiringInput=_pointerBridge.CloseAsync(); _pointerBridge=null; _flash=IntPtr.Zero; }
```

## src/HoverProbe.as:L1–L35
```text
L1: stop();
L2: Stage.scaleMode = "showAll";
L3: Stage.align = "TL";
L4: var probeFrame:Number = 0;
L5: var hoverA:Boolean = false;
L6: var hoverB:Boolean = false;
L7: var serial:Number = 0;
L8: var connected:Boolean = false;
L9: var sock:XMLSocket = new XMLSocket();
L10: function emit(eventName:String, targetName:String):Void {
L11:     if (!connected) return;
L12:     serial++;
L13:     sock.send("{\"seq\":" + serial + ",\"timer\":" + getTimer() + ",\"frame\":" + probeFrame + ",\"event\":\"" + eventName + "\",\"target\":\"" + targetName + "\",\"x\":" + _root._xmouse + ",\"y\":" + _root._ymouse + ",\"hoverA\":" + hoverA + ",\"hoverB\":" + hoverB + "}");
L14: }
L15: function paint(mc:MovieClip, active:Boolean):Void {
L16:     mc.clear(); mc.beginFill(active ? 0x00DD55 : 0x336699, 100);
L17:     mc.moveTo(0,0); mc.lineTo(160,0); mc.lineTo(160,70); mc.lineTo(0,70); mc.lineTo(0,0); mc.endFill();
L18: }
L19: function makeButton(id:String, xpos:Number):Void {
L20:     var mc:MovieClip = _root.createEmptyMovieClip(id, _root.getNextHighestDepth());
L21:     mc._x = xpos; mc._y = 120; paint(mc,false);
L22:     mc.onRollOver = function():Void { if(this._name=="A") hoverA=true; else hoverB=true; paint(this,true); emit("over",this._name); };
L23:     mc.onRollOut = function():Void { if(this._name=="A") hoverA=false; else hoverB=false; paint(this,false); emit("out",this._name); };
L24:     mc.onPress = function():Void { emit("press",this._name); };
L25:     mc.onRelease = function():Void { emit("release",this._name); };
L26:     mc.onReleaseOutside = function():Void { emit("releaseOutside",this._name); };
L27:     mc.onDragOut = function():Void { emit("dragOut",this._name); };
L28:     mc.onDragOver = function():Void { emit("dragOver",this._name); };
L29: }
L30: makeButton("A",80); makeButton("B",350);
L31: _root.createTextField("label", 20, 30, 20, 580, 75);
L32: _root.label.text = "Disposable Flash pointer probe - no game or saves\nA: left rectangle / B: right rectangle";
L33: sock.onConnect = function(ok:Boolean):Void { connected=ok; emit("ready",""); };
L34: sock.connect("127.0.0.1",32187);
L35: _root.onEnterFrame = function():Void { probeFrame++; if (probeFrame % 3 == 0) emit("sample",""); };
```

## src/HoverHost.cs:L67–L85
```text
L67:     private async Task ReadProbe()
L68:     {
L69:         try {
L70:             using var client=await listener.AcceptTcpClientAsync();
L71:             using var stream=client.GetStream();var buffer=new byte[4096];var pending=new List<byte>();
L72:             int count;
L73:             while((count=await stream.ReadAsync(buffer))>0) {
L74:                 for(int i=0;i<count;i++) {
L75:                     if(buffer[i]!=0){pending.Add(buffer[i]);continue;}
L76:                     string raw=Encoding.UTF8.GetString(pending.ToArray());pending.Clear();
L77:                     using var json=JsonDocument.Parse(raw);var j=json.RootElement;
L78:                     var sample=new Sample(Stopwatch.GetTimestamp(),phase,j.GetProperty("event").GetString(),j.GetProperty("target").GetString(),
L79:                         j.GetProperty("x").GetDouble(),j.GetProperty("y").GetDouble(),j.GetProperty("hoverA").GetBoolean(),j.GetProperty("hoverB").GetBoolean(),raw);
L80:                     samples.Enqueue(sample);
L81:                     lock(logLock)File.AppendAllText(Path.Combine(evidence,"as2.jsonl"),JsonSerializer.Serialize(sample)+Environment.NewLine);
L82:                 }
L83:             }
L84:         } catch(Exception e) {Log("probe_receiver "+e.Message);}
L85:     }
```

## src/HoverHost.cs:L174–L215
```text
L174:     private async Task Clicks(string name)
L175:     {
L176:         phase=name;long mark=Stopwatch.GetTimestamp();
L177:         for(int i=0;i<10;i++){MovePointer(i%2==0?160:430,150);await Task.Delay(120);Edge(2);await Task.Delay(90);Edge(4);await Task.Delay(130);}
L178:         await Task.Delay(200);var observed=samples.Where(x=>x.Tick>=mark && x.Phase==name).ToArray();
L179:         Check(observed.Count(x=>x.Event=="press")==10 && observed.Count(x=>x.Event=="release")==10,name+"_exact_callbacks",
L180:             new{press=observed.Count(x=>x.Event=="press"),release=observed.Count(x=>x.Event=="release"),outside=observed.Count(x=>x.Event=="releaseOutside")});
L181:     }
L182:     private async Task Boundaries()
L183:     {
L184:         phase="leave-reenter";MovePointer(160,150);await Task.Delay(250);long mark=Stopwatch.GetTimestamp();
L185:         MovePointer(280,270);await Task.Delay(250);
L186:         var last=samples.Last();
L187:         Check(!last.HoverA && !last.HoverB && samples.Any(x=>x.Tick>=mark && x.Event=="out" && x.Target=="A"),"real_mapped_leave",last);
L188:         MovePointer(160,150);await Task.Delay(250);Check(samples.Last().HoverA,"real_reenter",samples.Last());
L189:         phase="presentation-leave";MovePointer(-60,150);await Task.Delay(300);last=samples.Last();
L190:         Check(!last.HoverA && !last.HoverB,"leave_presentation_clears_hover",last);
L191:         Check(last.X<0 || last.Y<0,"leave_presentation_has_outside_coordinates",last);
L192:         MovePointer(160,150);await Task.Delay(250);Check(samples.Last().HoverA,"presentation_reenter",samples.Last());
L193:         phase="drag-outside";mark=Stopwatch.GetTimestamp();Edge(2);await Task.Delay(100);MovePointer(280,270);await Task.Delay(200);Edge(4);await Task.Delay(250);
L194:         var drag=samples.Where(x=>x.Tick>=mark).ToArray();
L195:         Check(drag.Count(x=>x.Event=="press")==1 && drag.Count(x=>x.Event=="releaseOutside")==1 && !drag.Any(x=>x.Event=="release"),"drag_outside_does_not_click",drag.Select(x=>x.Event).ToArray());
L196:         phase="external-focus";MovePointer(160,150);await Task.Delay(200);mark=Stopwatch.GetTimestamp();Edge(2);await Task.Delay(120);
L197:         using(var external=Process.Start(new ProcessStartInfo(Path.Combine(AppContext.BaseDirectory,"FlashHoverHost.exe"),"--external"){UseShellExecute=false})) {
L198:           try {
L199:             await WaitFor(()=>{external.Refresh();return external.MainWindowHandle!=IntPtr.Zero;},"external process window");
L200:             SetForegroundWindow(external.MainWindowHandle);await Task.Delay(300);
L201:             Check(GetForegroundWindow()==external.MainWindowHandle,"external_foreground",new{hwnd=GetForegroundWindow().ToInt64(),pid=external.Id});
L202:             Edge(4);await Task.Delay(250);
L203:             Check(!samples.Any(x=>x.Tick>=mark && x.Event=="release"),"focus_loss_no_button_commit",samples.Where(x=>x.Tick>=mark).Select(x=>x.Event).ToArray());
L204:             await Task.Delay(400);Check(GetForegroundWindow()==external.MainWindowHandle,"no_background_focus_reclaim",GetForegroundWindow().ToInt64());
L205:           } finally {if(!external.HasExited){external.CloseMainWindow();if(!external.WaitForExit(3000))external.Kill();}}
L206:         }
L207:         Activate();FocusFlash();await Task.Delay(300);
L208:         MovePointer(280,270);await Task.Delay(200);MovePointer(160,150);await Task.Delay(250);mark=Stopwatch.GetTimestamp();
L209:         Edge(2);await Task.Delay(100);Edge(4);await Task.Delay(300);
L210:         Check(samples.Count(x=>x.Tick>=mark && x.Event=="press")==1 && samples.Count(x=>x.Tick>=mark && x.Event=="release")==1,"fresh_click_after_focus_return",samples.Where(x=>x.Tick>=mark).Select(x=>x.Event).ToArray());
L211:         phase="owner-move";Location=new Point(180,140);await Task.Delay(500);await Hover("hover-after-move",true);
L212:         phase="owner-resize";ClientSize=new Size(1120,630);ResizeSource(1);await Task.Delay(700);await Hover("hover-after-resize",true);
L213:         phase="minimize-restore";WindowState=FormWindowState.Minimized;await Task.Delay(250);WindowState=FormWindowState.Normal;Activate();FocusFlash();await Task.Delay(700);
L214:         MovePointer(280,270);await Task.Delay(150);MovePointer(160,150);Edge(2);await Task.Delay(100);Edge(4);await Task.Delay(200);
L215:         await Hover("hover-after-restore",true);
```

## evidence/final/host.log:L438–L470
```text
L438: 2026-09-23T09:34:49.9126349Z ASSERT PASS drag_outside_does_not_click ["press","sample","dragOut","sample","sample","sample","releaseOutside","sample","sample"]
L439: 2026-09-23T09:34:49.9618376Z event=world_pointer_bridge TRACE session=16077536075934503839 ordinal=261 qpc=4729484728428 frequency=10000000 stage=13 seq=0 epoch=23 msg=0x2A3 x=192 y=180 buttons=0 localFloor=0 focus=0x28103C
L440: 2026-09-23T09:34:50.0025363Z event=world_compositor_progress state=advancing everReady=True sceneReady=True captureQpcMs=472948500.4
L441: 2026-09-23T09:34:50.1448848Z event=world_pointer_posted msg=0x201 seq=199 epoch=24 gesture=23 geo=2 x=240 y=225 source=960x540 session=16077536075934503839 consumed=199
L442: 2026-09-23T09:34:50.1813546Z event=world_pointer_bridge TRACE session=16077536075934503839 ordinal=262 qpc=4729486946272 frequency=10000000 stage=1 seq=199 epoch=24 msg=0x201 x=192 y=180 buttons=1 localFloor=0 focus=0x28103C
L443: 2026-09-23T09:34:50.1822512Z event=world_pointer_bridge TRACE session=16077536075934503839 ordinal=263 qpc=4729486951508 frequency=10000000 stage=2 seq=199 epoch=24 msg=0x201 x=192 y=180 buttons=1 localFloor=0 focus=0x28103C
L444: 2026-09-23T09:34:50.1826822Z event=world_pointer_bridge TRACE session=16077536075934503839 ordinal=264 qpc=4729486957278 frequency=10000000 stage=13 seq=0 epoch=24 msg=0x2A3 x=192 y=180 buttons=1 localFloor=0 focus=0x28103C
L445: 2026-09-23T09:34:50.2364257Z event=world_compositor_progress state=stalled everReady=True sceneReady=True captureQpcMs=472948500.4
L446: 2026-09-23T09:34:50.5398884Z event=world_compositor_frame received=42 presented=39 size=960x540 ageMs=589.1 submitMs=0.189 presentMs=0.092 cpuReadbacks=0 adapter=Intel(R) UHD Graphics 630 light=7.000 scale=1.00 output=960x540 everReady=True advancing=False
L447: 2026-09-23T09:34:50.6348833Z event=world_pointer_cancel epoch=25 seq=200 reason=owner_deactivate floor=True post=posted consumed=199
L448: 2026-09-23T09:34:50.6975798Z event=world_compositor_progress state=advancing everReady=True sceneReady=True captureQpcMs=472949243.4
L449: 2026-09-23T09:34:50.7188445Z event=world_pointer_bridge TRACE session=16077536075934503839 ordinal=265 qpc=4729491869930 frequency=10000000 stage=6 seq=0 epoch=25 msg=0x8 x=0 y=0 buttons=0 localFloor=26 focus=0x0
L450: 2026-09-23T09:34:50.7201430Z event=world_pointer_bridge TRACE session=16077536075934503839 ordinal=266 qpc=4729491874502 frequency=10000000 stage=7 seq=0 epoch=25 msg=0x1F x=0 y=0 buttons=0 localFloor=26 focus=0x0
L451: 2026-09-23T09:34:50.7213057Z event=world_pointer_bridge TRACE session=16077536075934503839 ordinal=267 qpc=4729491879231 frequency=10000000 stage=3 seq=200 epoch=25 msg=0x1F x=0 y=0 buttons=0 localFloor=26 focus=0x0
L452: 2026-09-23T09:34:51.0399207Z ASSERT PASS external_foreground {"hwnd":57348152,"pid":26728}
L453: 2026-09-23T09:34:51.0418278Z event=world_pointer_posted msg=0x202 seq=201 epoch=25 gesture=0 geo=2 x=240 y=225 source=960x540 session=16077536075934503839 consumed=200
L454: 2026-09-23T09:34:51.1517636Z event=world_pointer_bridge TRACE session=16077536075934503839 ordinal=268 qpc=4729495915911 frequency=10000000 stage=3 seq=201 epoch=25 msg=0x202 x=0 y=0 buttons=0 localFloor=26 focus=0x0
L455: 2026-09-23T09:34:51.1670153Z event=world_compositor_progress state=stalled everReady=True sceneReady=True captureQpcMs=472949451.7
L456: 2026-09-23T09:34:51.2946253Z ASSERT PASS focus_loss_no_button_commit ["press","sample","sample","sample","sample","sample","sample","sample","sample","sample","sample","sample","sample"]
L457: 2026-09-23T09:34:51.5451060Z event=world_compositor_frame received=55 presented=49 size=960x540 ageMs=643.0 submitMs=1.299 presentMs=0.171 cpuReadbacks=0 adapter=Intel(R) UHD Graphics 630 light=7.000 scale=1.00 output=960x540 everReady=True advancing=False
L458: 2026-09-23T09:34:51.6994389Z ASSERT PASS no_background_focus_reclaim 57348152
L459: 2026-09-23T09:34:51.7985594Z event=world_compositor_progress state=advancing everReady=True sceneReady=True captureQpcMs=472950333.8
L460: 2026-09-23T09:34:51.8039228Z event=world_pointer_bridge TRACE session=16077536075934503839 ordinal=269 qpc=4729503430947 frequency=10000000 stage=10 seq=0 epoch=24 msg=0x7 x=192 y=180 buttons=0 localFloor=26 focus=0x28103C
L461: 2026-09-23T09:34:52.2573741Z event=world_compositor_progress state=stalled everReady=True sceneReady=True captureQpcMs=472950556.0
L462: 2026-09-23T09:34:52.5595436Z event=world_compositor_frame received=69 presented=59 size=960x540 ageMs=553.2 submitMs=0.476 presentMs=0.096 cpuReadbacks=0 adapter=Intel(R) UHD Graphics 630 light=7.000 scale=1.00 output=960x540 everReady=True advancing=False
L463: 2026-09-23T09:34:52.5795759Z event=world_pointer_posted msg=0x201 seq=204 epoch=26 gesture=24 geo=2 x=240 y=225 source=960x540 session=16077536075934503839 consumed=203
L464: 2026-09-23T09:34:52.6610990Z event=world_pointer_bridge TRACE session=16077536075934503839 ordinal=270 qpc=4729511293143 frequency=10000000 stage=1 seq=204 epoch=26 msg=0x201 x=192 y=180 buttons=1 localFloor=26 focus=0x28103C
L465: 2026-09-23T09:34:52.6617092Z event=world_pointer_bridge TRACE session=16077536075934503839 ordinal=271 qpc=4729511293435 frequency=10000000 stage=2 seq=204 epoch=26 msg=0x201 x=192 y=180 buttons=1 localFloor=26 focus=0x28103C
L466: 2026-09-23T09:34:52.6625383Z event=world_pointer_bridge TRACE session=16077536075934503839 ordinal=272 qpc=4729511293771 frequency=10000000 stage=13 seq=0 epoch=26 msg=0x2A3 x=192 y=180 buttons=1 localFloor=26 focus=0x28103C
L467: 2026-09-23T09:34:52.6813231Z event=world_pointer_posted msg=0x202 seq=205 epoch=26 gesture=24 geo=2 x=240 y=225 source=960x540 session=16077536075934503839 consumed=204
L468: 2026-09-23T09:34:52.7646011Z event=world_pointer_bridge TRACE session=16077536075934503839 ordinal=273 qpc=4729512310032 frequency=10000000 stage=1 seq=205 epoch=26 msg=0x202 x=192 y=180 buttons=0 localFloor=26 focus=0x28103C
L469: 2026-09-23T09:34:52.7652401Z event=world_pointer_bridge TRACE session=16077536075934503839 ordinal=274 qpc=4729512314365 frequency=10000000 stage=2 seq=205 epoch=26 msg=0x202 x=192 y=180 buttons=0 localFloor=26 focus=0x28103C
L470: 2026-09-23T09:34:52.9892713Z ASSERT FAIL fresh_click_after_focus_return ["sample","release","sample","sample","sample"]
```

## evidence/final/as2.jsonl:L599–L633
```text
L599: {"Tick":4729484708111,"Phase":"external-focus","Event":"over","Target":"A","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:599,\u0022timer\u0022:52001,\u0022frame\u0022:1517,\u0022event\u0022:\u0022over\u0022,\u0022target\u0022:\u0022A\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L600: {"Tick":4729484963378,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:600,\u0022timer\u0022:52027,\u0022frame\u0022:1518,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L601: {"Tick":4729486040642,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:601,\u0022timer\u0022:52133,\u0022frame\u0022:1521,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L602: {"Tick":4729486955349,"Phase":"external-focus","Event":"press","Target":"A","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:602,\u0022timer\u0022:52226,\u0022frame\u0022:1523,\u0022event\u0022:\u0022press\u0022,\u0022target\u0022:\u0022A\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L603: {"Tick":4729486975500,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:603,\u0022timer\u0022:52228,\u0022frame\u0022:1524,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L604: {"Tick":4729488016400,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:604,\u0022timer\u0022:52332,\u0022frame\u0022:1527,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L605: {"Tick":4729488929498,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:605,\u0022timer\u0022:52423,\u0022frame\u0022:1530,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L606: {"Tick":4729490253612,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:606,\u0022timer\u0022:52556,\u0022frame\u0022:1533,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L607: {"Tick":4729491325971,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:607,\u0022timer\u0022:52662,\u0022frame\u0022:1536,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L608: {"Tick":4729491960992,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:608,\u0022timer\u0022:52725,\u0022frame\u0022:1539,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L609: {"Tick":4729492989576,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:609,\u0022timer\u0022:52829,\u0022frame\u0022:1542,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L610: {"Tick":4729493911065,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:610,\u0022timer\u0022:52921,\u0022frame\u0022:1545,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L611: {"Tick":4729494931990,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:611,\u0022timer\u0022:53022,\u0022frame\u0022:1548,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L612: {"Tick":4729495942070,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:612,\u0022timer\u0022:53125,\u0022frame\u0022:1551,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L613: {"Tick":4729497023886,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:613,\u0022timer\u0022:53232,\u0022frame\u0022:1554,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L614: {"Tick":4729498001044,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:614,\u0022timer\u0022:53331,\u0022frame\u0022:1557,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L615: {"Tick":4729498915315,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:615,\u0022timer\u0022:53422,\u0022frame\u0022:1560,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L616: {"Tick":4729500003527,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:616,\u0022timer\u0022:53531,\u0022frame\u0022:1563,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L617: {"Tick":4729500959876,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:617,\u0022timer\u0022:53626,\u0022frame\u0022:1566,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L618: {"Tick":4729501955798,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:618,\u0022timer\u0022:53726,\u0022frame\u0022:1569,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L619: {"Tick":4729503438470,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:619,\u0022timer\u0022:53831,\u0022frame\u0022:1572,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L620: {"Tick":4729503901379,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:620,\u0022timer\u0022:53920,\u0022frame\u0022:1575,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L621: {"Tick":4729504961505,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:621,\u0022timer\u0022:54025,\u0022frame\u0022:1578,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L622: {"Tick":4729505938384,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:622,\u0022timer\u0022:54124,\u0022frame\u0022:1581,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L623: {"Tick":4729506958414,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:623,\u0022timer\u0022:54226,\u0022frame\u0022:1584,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L624: {"Tick":4729507903580,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:624,\u0022timer\u0022:54321,\u0022frame\u0022:1587,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L625: {"Tick":4729508928369,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:625,\u0022timer\u0022:54423,\u0022frame\u0022:1590,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L626: {"Tick":4729509902218,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:626,\u0022timer\u0022:54521,\u0022frame\u0022:1593,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L627: {"Tick":4729510937389,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:627,\u0022timer\u0022:54624,\u0022frame\u0022:1596,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L628: {"Tick":4729511892277,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:628,\u0022timer\u0022:54720,\u0022frame\u0022:1599,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L629: {"Tick":4729512317717,"Phase":"external-focus","Event":"release","Target":"A","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:629,\u0022timer\u0022:54762,\u0022frame\u0022:1600,\u0022event\u0022:\u0022release\u0022,\u0022target\u0022:\u0022A\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L630: {"Tick":4729512939118,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:630,\u0022timer\u0022:54824,\u0022frame\u0022:1602,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L631: {"Tick":4729513941421,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:631,\u0022timer\u0022:54925,\u0022frame\u0022:1605,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L632: {"Tick":4729514995026,"Phase":"external-focus","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:632,\u0022timer\u0022:55030,\u0022frame\u0022:1608,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
L633: {"Tick":4729515925454,"Phase":"owner-move","Event":"sample","Target":"","X":160,"Y":150,"HoverA":true,"HoverB":false,"Raw":"{\u0022seq\u0022:633,\u0022timer\u0022:55123,\u0022frame\u0022:1611,\u0022event\u0022:\u0022sample\u0022,\u0022target\u0022:\u0022\u0022,\u0022x\u0022:160,\u0022y\u0022:150,\u0022hoverA\u0022:true,\u0022hoverB\u0022:false}"}
```

## evidence/same-process/host.log:L423–L455
```text
L423: 2026-09-23T09:15:59.7307350Z ASSERT PASS drag_outside_does_not_click ["press","sample","sample","dragOut","sample","releaseOutside","sample","sample","sample"]
L424: 2026-09-23T09:15:59.8094194Z event=world_compositor_progress state=advancing everReady=True sceneReady=True captureQpcMs=471818330.5
L425: 2026-09-23T09:15:59.8649872Z event=world_pointer_bridge TRACE session=15133243061370550625 ordinal=258 qpc=4718183114178 frequency=10000000 stage=13 seq=0 epoch=23 msg=0x2A3 x=192 y=180 buttons=0 localFloor=1 focus=0x3841000
L426: 2026-09-23T09:15:59.9456838Z event=world_pointer_posted msg=0x201 seq=196 epoch=24 gesture=23 geo=2 x=240 y=225 source=960x540 session=15133243061370550625 consumed=195
L427: 2026-09-23T09:15:59.9652229Z event=world_pointer_bridge TRACE session=15133243061370550625 ordinal=259 qpc=4718184954546 frequency=10000000 stage=1 seq=196 epoch=24 msg=0x201 x=192 y=180 buttons=1 localFloor=1 focus=0x3841000
L428: 2026-09-23T09:15:59.9656193Z event=world_pointer_bridge TRACE session=15133243061370550625 ordinal=260 qpc=4718184957434 frequency=10000000 stage=2 seq=196 epoch=24 msg=0x201 x=192 y=180 buttons=1 localFloor=1 focus=0x3841000
L429: 2026-09-23T09:15:59.9659147Z event=world_pointer_bridge TRACE session=15133243061370550625 ordinal=261 qpc=4718184958334 frequency=10000000 stage=13 seq=0 epoch=24 msg=0x2A3 x=192 y=180 buttons=1 localFloor=1 focus=0x3841000
L430: 2026-09-23T09:16:00.0383630Z event=world_compositor_progress state=stalled everReady=True sceneReady=True captureQpcMs=471818330.5
L431: 2026-09-23T09:16:00.1014197Z event=world_pointer_cancel epoch=25 seq=197 reason=owner_deactivate floor=True post=posted consumed=196
L432: 2026-09-23T09:16:00.1293812Z event=world_compositor_progress state=advancing everReady=True sceneReady=True captureQpcMs=471818663.8
L433: 2026-09-23T09:16:00.1719185Z event=world_pointer_bridge TRACE session=15133243061370550625 ordinal=262 qpc=4718186511012 frequency=10000000 stage=7 seq=0 epoch=25 msg=0x1F x=0 y=0 buttons=0 localFloor=1 focus=0x3841000
L434: 2026-09-23T09:16:00.1723582Z event=world_pointer_bridge TRACE session=15133243061370550625 ordinal=263 qpc=4718186511066 frequency=10000000 stage=1 seq=197 epoch=25 msg=0x1F x=21 y=25 buttons=0 localFloor=1 focus=0x3841000
L435: 2026-09-23T09:16:00.1727262Z event=world_pointer_bridge TRACE session=15133243061370550625 ordinal=264 qpc=4718186511086 frequency=10000000 stage=2 seq=197 epoch=25 msg=0x1F x=21 y=25 buttons=0 localFloor=1 focus=0x3841000
L436: 2026-09-23T09:16:00.1730678Z event=world_pointer_bridge TRACE session=15133243061370550625 ordinal=265 qpc=4718186553937 frequency=10000000 stage=6 seq=0 epoch=25 msg=0x8 x=0 y=0 buttons=0 localFloor=26 focus=0x2B70E1C
L437: 2026-09-23T09:16:00.4236984Z ASSERT PASS external_foreground 45551132
L438: 2026-09-23T09:16:00.4247665Z event=world_pointer_posted msg=0x202 seq=198 epoch=25 gesture=0 geo=2 x=240 y=225 source=960x540 session=15133243061370550625 consumed=197
L439: 2026-09-23T09:16:00.4932579Z event=world_pointer_bridge TRACE session=15133243061370550625 ordinal=266 qpc=4718189745040 frequency=10000000 stage=3 seq=198 epoch=25 msg=0x202 x=0 y=0 buttons=0 localFloor=26 focus=0x2B70E1C
L440: 2026-09-23T09:16:00.6009398Z event=world_compositor_frame received=57 presented=49 size=960x540 ageMs=216.0 submitMs=0.368 presentMs=0.132 cpuReadbacks=0 adapter=Intel(R) UHD Graphics 630 light=7.000 scale=1.00 output=960x540 everReady=True advancing=True
L441: 2026-09-23T09:16:00.6495396Z event=world_compositor_progress state=stalled everReady=True sceneReady=True captureQpcMs=471818934.6
L442: 2026-09-23T09:16:00.6780193Z ASSERT PASS focus_loss_no_button_commit ["press","sample","sample","sample","sample","sample","sample","sample"]
L443: 2026-09-23T09:16:01.0870705Z ASSERT PASS no_background_focus_reclaim 45551132
L444: 2026-09-23T09:16:01.1288997Z event=world_pointer_bridge TRACE session=15133243061370550625 ordinal=267 qpc=4718196602145 frequency=10000000 stage=10 seq=0 epoch=25 msg=0x7 x=21 y=25 buttons=0 localFloor=26 focus=0x3841000
L445: 2026-09-23T09:16:01.1634987Z event=world_compositor_progress state=advancing everReady=True sceneReady=True captureQpcMs=471819684.5
L446: 2026-09-23T09:16:01.6451838Z event=world_compositor_progress state=stalled everReady=True sceneReady=True captureQpcMs=471819934.6
L447: 2026-09-23T09:16:01.6455985Z event=world_compositor_frame received=71 presented=59 size=960x540 ageMs=260.6 submitMs=0.245 presentMs=0.222 cpuReadbacks=0 adapter=Intel(R) UHD Graphics 630 light=7.000 scale=1.00 output=960x540 everReady=True advancing=False
L448: 2026-09-23T09:16:01.8942622Z event=world_pointer_posted msg=0x201 seq=201 epoch=26 gesture=24 geo=2 x=240 y=225 source=960x540 session=15133243061370550625 consumed=200
L449: 2026-09-23T09:16:01.9763176Z event=world_pointer_bridge TRACE session=15133243061370550625 ordinal=268 qpc=4718204440104 frequency=10000000 stage=1 seq=201 epoch=26 msg=0x201 x=192 y=180 buttons=1 localFloor=26 focus=0x3841000
L450: 2026-09-23T09:16:01.9768441Z event=world_pointer_bridge TRACE session=15133243061370550625 ordinal=269 qpc=4718204440426 frequency=10000000 stage=2 seq=201 epoch=26 msg=0x201 x=192 y=180 buttons=1 localFloor=26 focus=0x3841000
L451: 2026-09-23T09:16:01.9772407Z event=world_pointer_bridge TRACE session=15133243061370550625 ordinal=270 qpc=4718204441054 frequency=10000000 stage=13 seq=0 epoch=26 msg=0x2A3 x=192 y=180 buttons=1 localFloor=26 focus=0x3841000
L452: 2026-09-23T09:16:01.9989216Z event=world_pointer_posted msg=0x202 seq=202 epoch=26 gesture=24 geo=2 x=240 y=225 source=960x540 session=15133243061370550625 consumed=201
L453: 2026-09-23T09:16:02.0801673Z event=world_pointer_bridge TRACE session=15133243061370550625 ordinal=271 qpc=4718205487159 frequency=10000000 stage=1 seq=202 epoch=26 msg=0x202 x=192 y=180 buttons=0 localFloor=26 focus=0x3841000
L454: 2026-09-23T09:16:02.0805704Z event=world_pointer_bridge TRACE session=15133243061370550625 ordinal=272 qpc=4718205492502 frequency=10000000 stage=2 seq=202 epoch=26 msg=0x202 x=192 y=180 buttons=0 localFloor=26 focus=0x3841000
L455: 2026-09-23T09:16:02.3036595Z ASSERT FAIL fresh_click_after_focus_return ["sample","sample","release","sample","sample","sample"]
```

## evidence/native-selftest.log:L1–L38
```text
L1: [RuntimeBuildEnv] OK baseline=cf7-win-x64-2026-07-22 dotnet=10.0.300 msvc=19.44.35228.0 rustc=1.96.0/ac68faa20 sdk=10.0.22621.0
L2: [INFO] Pinned native tools selected: cl=C:\Program Files (x86)\CF7VS\BT1736\VC\Tools\MSVC\14.44.35207\bin\Hostx64\x64\cl.exe link=C:\Program Files (x86)\CF7VS\BT1736\VC\Tools\MSVC\14.44.35207\bin\Hostx64\x64\link.exe rc=C:\Program Files (x86)\Windows Kits\10\bin\10.0.22621.0\x64\rc.exe
L3: Compositor.cpp
L4:   正在创建库 C:\Program Files (x86)\Steam\steamapps\common\CRAZYFLASHER7StandAloneStarter\CrazyFlashNight\tmp\r6-final-native\FlashCompositorNative.lib 和对象 C:\Program Files (x86)\Steam\steamapps\common\CRAZYFLASHER7StandAloneStarter\CrazyFlashNight\tmp\r6-final-native\FlashCompositorNative.exp
L5: InputBridge.cpp
L6:   正在创建库 C:\Program Files (x86)\Steam\steamapps\common\CRAZYFLASHER7StandAloneStarter\CrazyFlashNight\tmp\r6-final-native\FlashInputBridge.lib 和对象 C:\Program Files (x86)\Steam\steamapps\common\CRAZYFLASHER7StandAloneStarter\CrazyFlashNight\tmp\r6-final-native\FlashInputBridge.exp
L7: InputBroker.cpp
L8: InputBridge.cpp
L9: InputBridgeSelfTest.cpp
L10:   正在创建库 C:\Program Files (x86)\Steam\steamapps\common\CRAZYFLASHER7StandAloneStarter\CrazyFlashNight\tmp\r6-final-native\InputBridgeSelfTest.lib 和对象 C:\Program Files (x86)\Steam\steamapps\common\CRAZYFLASHER7StandAloneStarter\CrazyFlashNight\tmp\r6-final-native\InputBridgeSelfTest.exp
L11: PASS trace_overwritten_record_is_not_fabricated
L12: PASS trace_committed_record_exact
L13: PASS trace_partial_record_refused
L14: PASS down_epoch5_admitted_focus_and_delivery
L15: PASS admitted_down_not_counted_stale
L16: PASS admitted_epoch_updates_endpoint_high_water
L17: PASS covered_source_leave_cannot_clear_mapped_hover
L18: PASS killfocus_floor_covers_issued_unseen_epoch
L19: PASS real_focus_loss_restores_native_leave_delivery
L20: PASS queued_epoch6_down_no_focus_no_delivery
L21: PASS queued_stale_rejection_counted
L22: PASS new_gesture_epoch7_readmitted_after_loss
L23: PASS entermenuloop_floor_covers_issued_epoch
L24: PASS queued_epoch7_down_rejected_after_menuloop
L25: PASS menuloop_stale_rejection_counted
L26: PASS new_gesture_epoch8_readmitted_after_menuloop
L27: PASS last_ordinary_epoch_admitted_with_old_floors
L28: PASS invalid_epoch_no_effect
L29: PASS invalid_epoch_no_effect
L30: PASS invalid_epoch_no_effect
L31: PASS invalid_epoch_no_effect
L32: PASS invalid_sequence_no_delivery
L33: PASS invalid_sequence_no_delivery
L34: PASS invalid_sequence_no_delivery
L35: PASS modifier_up_releases_mouse_gesture
L36: PASS presentation_leave_preserves_negative_sentinel
L37: PASS no_shared_section_refuses_delivery
L38: RESULT PASS failures=0
```

## evidence/g1-queue.log:L185–L205
```text
L185: 17:27:10.185 [prod] event=world_pointer_cancel epoch=13 seq=18 reason=s4_no_followup_data floor=True post=post_failed consumed=17
L186: 17:27:10.213 ASSERT PASS s4_release_without_followup_data :: minEpoch=13 consumedSeq=17 stale=4 stopped=0 unowned=1 dup=0 issued=13
L187: 17:27:10.223 ASSERT PASS s4_original_cancel :: original cancellation observed
L188: 17:27:10.223 === teardown ===
L189: 17:27:10.226 [prod] event=world_pointer_cancel epoch=14 reason=hidden floor=True post=none
L190: 17:27:10.227 [prod] event=world_pointer_cancel epoch=15 reason=explicit floor=True post=none
L191: 17:27:10.274 [prod] event=world_pointer_bridge TRACE session=17736294010349424527 ordinal=36 qpc=4724887456389 frequency=10000000 stage=7 seq=0 epoch=13 msg=0x1F x=0 y=0 buttons=0 localFloor=4 focus=0xD1D066E
L192: 17:27:10.274 [prod] event=world_pointer_bridge TRACE session=17736294010349424527 ordinal=37 qpc=4724887775132 frequency=10000000 stage=7 seq=0 epoch=13 msg=0x1F x=0 y=0 buttons=0 localFloor=4 focus=0xD1D066E
L193: 17:27:10.274 [prod] event=world_pointer_bridge TRACE session=17736294010349424527 ordinal=38 qpc=4724887906887 frequency=10000000 stage=7 seq=0 epoch=13 msg=0x1F x=0 y=0 buttons=0 localFloor=4 focus=0xD1D066E
L194: 17:27:10.372 [prod] event=world_pointer_bridge TRACE session=17736294010349424527 ordinal=39 qpc=4724888224328 frequency=10000000 stage=7 seq=0 epoch=13 msg=0x1F x=0 y=0 buttons=0 localFloor=4 focus=0xD1D066E
L195: 17:27:10.376 [prod] event=world_pointer_bridge TRACE session=17736294010349424527 ordinal=40 qpc=4724889242251 frequency=10000000 stage=7 seq=0 epoch=13 msg=0x1F x=0 y=0 buttons=0 localFloor=4 focus=0xD1D066E
L196: 17:27:10.377 [prod] event=world_pointer_bridge STOP session=17736294010349424527 returned=1 targetExited=0 unhooked=1 propertyOwned=1 consumedSeq=17 completedSeq=17 stale=4 invalid=0 cancelAck=7 drained=0
L197: 17:27:10.381 [prod] event=world_pointer_close session=17736294010349424527 confirmed=True
L198: 17:27:10.403 ASSERT PASS broker_stop_line :: STOP counters captured via LogManager
L199: 17:27:10.782 final minEpoch=13 consumedSeq=17 stale=4 stopped=0 unowned=1 dup=0 issued=13
L200: 17:27:10.782 RESULT failures=0 asserts=52
L201: 17:27:11.040 ASSERT PASS endpoint_trace_attached :: separate mapping opened in actual target
L202: 17:27:11.041 ASSERT PASS endpoint_trace_original_enter_return :: each Down entry has same-session/same-sequence return; not a business ACK
L203: 17:27:11.041 ASSERT PASS endpoint_trace_no_overwrite_in_sample :: bounded trace reports loss explicitly
L204: 17:27:11.055 owner_deactivate_fired fg=0x40BC4
L205: G1_RUN_EXIT=0
```

## evidence/causal-pair.json:L1–L9
```text
L1: {
L2:   "FlashHoverHost.dll": "b0555b6dbea6fb3704d8f41303c222a28837604cd153e30c8bfb66f46770de67",
L3:   "FlashHoverHost.exe": "15c4164f4dfd6970867fc17070a6dcee605f993d35f789addd7b51c861d61bef",
L4:   "FlashCompositorNative.dll": "af396626b2861256aa6dc3b702876280ed95e47f749a321d3c97adb4b5396976",
L5:   "FlashInputBridge.dll": "0aaee22e46126614c66323febd12b09fb4c320d3602a3ae1b6935bd37ce3acf3",
L6:   "FlashInputBroker.exe": "7e82f199a4adfd17e2f15a1bba0b5decb73be4e06f67b7faa441a8aae1fa0cf2",
L7:   "baseline_input_dll": "d368ae31571f1bb0a17a77d6370de67b70eb1dbef39f3149412cec34ee0e1984",
L8:   "probe_swf": "d7be1c6ca1685b13d8eb143c73c324f76352e3d194838e7be928e1abd7f3d6fd"
L9: }
```

## evidence/native-pair.json:L1–L20
```text
L1: [
L2:   {
L3:     "file": "FlashCompositorNative.dll",
L4:     "expected": "AF396626B2861256AA6DC3B702876280ED95E47F749A321D3C97ADB4B5396976",
L5:     "fixtureMatches": true,
L6:     "candidateMatches": true
L7:   },
L8:   {
L9:     "file": "FlashInputBridge.dll",
L10:     "expected": "0BD4E2095971D014D1F64326C92B51FC13966E435868E6420A90B463BE7D5718",
L11:     "fixtureMatches": true,
L12:     "candidateMatches": true
L13:   },
L14:   {
L15:     "file": "FlashInputBroker.exe",
L16:     "expected": "7E82F199A4ADFD17E2F15A1BBA0B5DECB73BE4E06F67B7FAA441A8AAE1FA0CF2",
L17:     "fixtureMatches": true,
L18:     "candidateMatches": true
L19:   }
L20: ]
```

## evidence/entry-observed.json:L1–L16
```text
L1: {
L2:   "observedUtc": "2026-09-23T09:40:36.9851621Z",
L3:   "candidate": "C:\\Program Files (x86)\\Steam\\steamapps\\common\\CRAZYFLASHER7StandAloneStarter\\CrazyFlashNight\\tmp\\flash-compositor\\game-v4-r6-final-20260923",
L4:   "process": {
L5:     "pid": 25288,
L6:     "path": "C:\\Program Files (x86)\\Steam\\steamapps\\common\\CRAZYFLASHER7StandAloneStarter\\CrazyFlashNight\\tmp\\flash-compositor\\game-v4-r6-final-20260923\\CRAZYFLASHER7MercenaryEmpire.Core.exe",
L7:     "startedAtUtc": "2026-09-23T09:38:33.0840471Z"
L8:   },
L9:   "session": "6b1193a0a118475cb392eff182bf1f1a",
L10:   "coreSha256": "3EEB4CEDAA72458FAF7E0F7F21B08A2B67A28DAD0E72F550E3190266F8AEB9F7",
L11:   "identityMatched": true,
L12:   "bootstrapReady": "17:38:48.845 [Bootstrap] JS→C#: {\"cmd\":\"ready\",\"type\":\"bootstrap\"}",
L13:   "inputTestCap": 0,
L14:   "humanAcceptance": "PENDING",
L15:   "knownOpenFailure": "held-button focus loss does not prove AVM1 cancellation"
L16: }
```
