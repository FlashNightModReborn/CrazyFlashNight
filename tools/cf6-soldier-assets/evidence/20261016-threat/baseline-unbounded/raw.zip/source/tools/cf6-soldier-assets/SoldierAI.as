﻿// CF6 身体接入标准长枪装备、射击和装填；攻击 token 只控制本单位动作所有权。
soldierClock=0;soldierReadyAt=6;soldierTargetName="";soldierAttackOwner=null;
soldierShotCount=0;soldierStabCount=0;soldierReloadCount=0;soldierInvalidMuzzleCount=0;
soldierWeaponError="";
soldierTuning={shootRange:460,knifeRange:95,laneRange:24,keepDistance:190,
    reactionFrames:6,maximumTargetHeight:85,burstShots:3,recoveryFrames:4};

soldierCancelAttack=function():Void {
    if(this.soldierAttackOwner!=null) this.soldierAttackOwner.active=false;
    this.soldierAttackOwner=null;this.动作A=false;
    _root.主角函数.清理射击任务(this);
};

// Cancel before the timeline unloads its old man; delayed shots cannot adopt a new pose.
状态改变=function(next:String):Void {
    if(this.状态==next)return;
    this.soldierCancelAttack();
    _root.敌人函数.状态改变.call(this,next);
};

soldierBeginAttack=function(body:MovieClip,action:String):Void {
    this.soldierCancelAttack();
    if(!(this.hp>0)){body.stop();return;}
    var token:Object={};body.soldierToken=token;
    this.soldierAttackOwner={token:token,action:action,active:true,lastHitFrame:0,
        target:this.攻击目标,weapon:this.长枪,version:this.version,age:0,shots:0,recovery:0,reload:false};
    if(action=="shoot") {
        if(!(this.长枪弹匣容量>0) || !(this.长枪属性.interval>0)
            || typeof _root.主角函数.初始化长枪射击函数!="function") {
            this.soldierWeaponError="长枪数据或标准射击入口缺失";
            trace("[CF6Soldier] "+this._name+" "+this.soldierWeaponError);
            this.soldierFinishAttack(body);return;
        }
        body.初始化长枪射击函数=_root.主角函数.初始化长枪射击函数;
        body.初始化长枪射击函数();
    }
};

soldierCanAct=function(body:MovieClip):Boolean {
    var owner:Object=this.soldierAttackOwner;
    return !_root.暂停 && this.hp>0 && !this.硬直中 && owner!=null && owner.active
        && body===this.man && body.soldierToken===owner.token && owner.version===this.version
        && (owner.action!="shoot" || owner.weapon===this.长枪)
        && this.状态==(owner.action=="knife"?"近战":"长枪攻击");
};

soldierFinishAttack=function(body:MovieClip):Void {
    var owner:Object=this.soldierAttackOwner;
    if(owner==null || body!==this.man || owner.token!==body.soldierToken)return;
    this.soldierCancelAttack();this.动画完毕();
};

soldierMuzzleMarker=function(body:MovieClip):MovieClip {
    var outer:MovieClip=body.枪,holder:MovieClip=outer.枪,gun:MovieClip=holder.装扮;
    var marker:MovieClip=gun.枪口位置;
    if(outer._parent!==body || holder._parent!==outer || gun._parent!==holder
        || marker._parent!==gun || gun!==this.长枪_引用)return null;
    return marker;
};

soldierMuzzle=function(body:MovieClip):Object {
    var marker:MovieClip=this.soldierMuzzleMarker(body);if(marker==null)return null;
    var p:Object={x:0,y:0};marker.localToGlobal(p);var globalY:Number=p.y;
    _root.gameworld.globalToLocal(p);if(isNaN(p.x) || isNaN(p.y))return null;
    p.globalY=globalY;return p;
};

// ShootCore chooses cadence and WeaponFireCore commits ammunition and bullet properties.
长枪射击=function(marker:MovieClip,props:Object):Boolean {
    var body:MovieClip=this.man,owner:Object=this.soldierAttackOwner;
    if(!this.soldierCanAct(body) || owner.action!="shoot" || owner.reload
        || owner.shots>=this.soldierTuning.burstShots)return false;
    if(marker!==this.soldierMuzzleMarker(body) || marker==null){this.soldierInvalidMuzzleCount++;return false;}
    var fired:Boolean=_root.主角函数.长枪射击.call(this,marker,props);
    if(fired){owner.shots++;this.soldierShotCount++;if(owner.shots>=this.soldierTuning.burstShots)this.动作A=false;}
    return fired;
};

soldierReloadStart=function(body:MovieClip):Void {
    if(!this.soldierCanAct(body)){body.stop();return;}
    this.动作A=false;this.soldierAttackOwner.reload=true;this.soldierReloadCount++;
    _root.主角函数.初始化换弹负担(body,15,35,18,49,[35,47]);
};

soldierReloadEnd=function(body:MovieClip):Void {
    if(!this.soldierCanAct(body)){body.stop();return;}
    body.结束换弹();this.soldierFinishAttack(body);
};

soldierDriveShooting=function(body:MovieClip):Void {
    var owner:Object=this.soldierAttackOwner;owner.age++;
    if(owner.reload){_root.主角函数.换弹帧率控制(body);return;}
    if(owner.shots>=this.soldierTuning.burstShots){
        if(++owner.recovery>=this.soldierTuning.recoveryFrames)this.soldierFinishAttack(body);
        return;
    }
    if(owner.age<3)return;
    if(this.soldierMuzzleMarker(body)==null){
        if(owner.age>30){this.soldierWeaponError="长枪外观或枪口引用缺失";
            trace("[CF6Soldier] "+this._name+" "+this.soldierWeaponError);this.soldierFinishAttack(body);}
        return;
    }
    this.动作A=true;body.开始射击();
};

soldierStab=function(body:MovieClip,point:MovieClip):Void {
    if(!this.soldierCanAct(body) || point.area==null) return;
    var owner:Object=this.soldierAttackOwner;
    if(owner.action!="knife" || owner.lastHitFrame==body._currentframe) return;
    owner.lastHitFrame=body._currentframe;
    var p:Object={x:point._x,y:point._y};body.localToGlobal(p);_root.gameworld.globalToLocal(p);
    this.soldierStabCount++;
    _root.子弹区域shoot传递({声音:"",霰弹值:1,子弹散射度:0,发射效果:"",
        子弹种类:"近战子弹",子弹威力:this.空手攻击力,子弹速度:0,
        Z轴攻击范围:24,击中地图效果:"",发射者:this._name,
        shootX:p.x,shootY:p.y,shootZ:this.Z轴坐标,击倒率:10,
        击中后子弹的效果:"空手攻击火花",水平击退速度:2,垂直击退速度:1,
        区域定位area:point.area});
};

soldierChooseAttack=function(dx:Number,dz:Number,height:Number):String {
    var tune:Object=this.soldierTuning;
    if(isNaN(dx) || isNaN(dz) || isNaN(height) || dx<0 || dz<0
        || dz>tune.laneRange || height>tune.maximumTargetHeight || this.soldierClock<this.soldierReadyAt) return "none";
    if(dx<=tune.knifeRange) return "knife";
    if(dx<=tune.shootRange) return "shoot";
    return "none";
};

soldierTick=function():Void {
    if(_root.暂停)return;
    this.soldierClock++;
    if(!isNaN(this.hp) && this.hp<=0){
        this.soldierCancelAttack();
        if(this.状态!="血腥死" && this.状态!="消失")this.状态改变("血腥死");
        return;
    }
    var owner:Object=this.soldierAttackOwner;
    if(owner!=null && !this.soldierCanAct(this.man)){
        this.soldierCancelAttack();
        if(this.状态=="长枪攻击" || this.状态=="近战")this.动画完毕();
        return;
    }
    if(!(this.hp>0) || this.倒地 || this.浮空 || this.硬直中)return;
    if(owner!=null){if(owner.action=="shoot")this.soldierDriveShooting(this.man);return;}
    if(_root.控制目标==this._name && _root.控制目标全自动==false)return;
    if(this.状态!="长枪站立" && this.状态!="长枪行走" && this.状态!="长枪跑")return;
    if((this.soldierClock&3)!=0)return;
    this.x轴攻击范围=0;this.y轴攻击范围=this.soldierTuning.laneRange;
    this.x轴保持距离=this.soldierTuning.keepDistance;
    if(this.unitAI.data!=null){
        this.unitAI.data.xrange=0;this.unitAI.data.zrange=this.y轴攻击范围;
        this.unitAI.data.xdistance=this.x轴保持距离;
    }
    var target:MovieClip=_root.gameworld[this.攻击目标];
    if(!(target.hp>0) || target==this || target.area==null)return;
    var dx:Number=target._x-this._x,dz:Number=target.Z轴坐标-this.Z轴坐标;
    var height:Number=target.Z轴坐标-target._y;
    if(target.浮空高度!=undefined && !isNaN(target.浮空高度) && target.浮空高度>0)height+=target.浮空高度;
    if(isNaN(dx) || isNaN(dz) || isNaN(height))return;
    if(this.soldierTargetName!=target._name){
        this.soldierTargetName=target._name;
        this.soldierReadyAt=this.soldierClock+this.soldierTuning.reactionFrames;
    }
    var action:String=this.soldierChooseAttack(Math.abs(dx),Math.abs(dz),height);
    if(action=="none"){
        this.上行=dz< -6;this.下行=dz>6;
        this.左行=dx< -this.soldierTuning.keepDistance;this.右行=dx>this.soldierTuning.keepDistance;
        if(Math.abs(dx)>460 && this.状态!="长枪跑")this.状态改变("长枪跑");
        return;
    }
    this.左行=this.右行=this.上行=this.下行=false;
    if(dx<0)this.方向改变("左");else if(dx>0)this.方向改变("右");
    this.状态改变(action=="knife"?"近战":"长枪攻击");
};
