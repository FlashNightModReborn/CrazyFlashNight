using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CF7Launcher.Guardian.WorldCompositor
{
    internal sealed partial class WorldCompositorController : IDisposable
    {
        private readonly Form _owner;
        private readonly Control _anchor;
        private readonly Func<IntPtr> _getFlash;
        private readonly Func<bool> _canPresent;
        private readonly Func<bool> _shouldPrepare;
        private readonly Action<string> _notify;
        private readonly Action<int> _setRenderHeight;
        private readonly Action _focusFlash;
        private readonly WorldLightingPreset _preset;
        private readonly Dictionary<string,NightVisionProfile> _nightVisionProfiles;
        private NightVisionProfile _appliedNightVision;
        private long _appliedNightVisionScene;
        private double[] _lastNightMatrix;
        private double _lastNightShadowLift = double.NaN;
        private string _lutOwner;
        private readonly WorldPresentationCatalog _presentationCatalog;
        private readonly BulletVisualCatalog _bulletCatalog;
        private readonly CombatFxCatalog _combatFxCatalog;
        private volatile bool _combatFxResourcesReady,_combatFxCapabilityAdvertised;
        private double _lastCombatFxCapAttemptMs;
        internal Func<bool,bool> CombatFxCapabilityChanged;
        internal event Action PresentationShown;
        internal Action PerformanceUnavailable;
        private readonly bool _bulletCandidateEnabled;
        private readonly Timer _timer = new Timer { Interval=33 };
        private NativeCompositorSession _native;
        private CompositionSceneHost _compositionScene;
        internal WorldRasterPresentation DamagePresentation { get; } = new WorldRasterPresentation();
        internal WorldRasterPresentation ResourcePresentation { get; }
        internal WorldRasterPresentation BottomPresentation { get; }
        internal WorldRasterPresentation BuffPresentation { get; }
        internal WorldRasterPresentation MainHudPresentation { get; }
        private readonly bool _opaqueHudEnabled;
        private bool _playerHudFaulted;
        private IWorldRasterScene _damageRasterScene,_resourceRasterScene,_bottomRasterScene,_buffRasterScene,_mainHudRasterScene;
        private IWorldHudInput _hudInput,_mainHudInput,_combinedHudInput;
        internal void SetHudInput(IWorldHudInput input)
        {
            if(ReferenceEquals(input,_hudInput))return;
            _hudInput=input;RebindHudInput();
        }
        internal void SetMainHudInput(IWorldHudInput input)
        {
            if(ReferenceEquals(input,_mainHudInput))return;
            _mainHudInput=input;RebindHudInput();
        }
        private void RebindHudInput()
        {
            _combinedHudInput=_mainHudInput==null?_hudInput:_hudInput==null?_mainHudInput:new WorldHudInputLayers(_mainHudInput,_hudInput);
            _surface?.SetHudInput(_combinedHudInput);
        }
        internal void RetireLegacyHudGesture() => _surface?.RetireLegacyHudGesture();
        private bool _compositionSceneCommitted;
        private WorldCompositionSurface _surface;
        private WorldOverlayOrder _overlayOrder;
        private readonly IEnumerable<OverlayBase> _overlays;
        private NativePointerBridge _pointerBridge;
        private IntPtr _flash;
        private Rectangle _crop;
        private string _lastGeometryRejection;
        private ulong _lastCaptureGeneration;
        private WorldLightingFrame _frame;
        private WorldLightingTransition _lighting = new WorldLightingTransition();
        private long _reportedPendingScene;
        private long _transitionGradeScene, _transitionPresentedScene, _transitionRequestedScene;
        private double _transitionGradeSubmittedAt;
        private sealed class TransitionPaintRequest {
            internal readonly long Scene;
            internal readonly double After;
            internal TransitionPaintRequest(long scene,double after) { Scene=scene; After=after; }
        }
        private TransitionPaintRequest _transitionPaintRequest;
        private void QueueTransitionPaint(long scene,double after) {
            _transitionPaintRequest=new TransitionPaintRequest(scene,after);
        }
        private void RecordTransitionGrade(long scene,double now) {
            _transitionGradeScene=scene; _transitionGradeSubmittedAt=now; _transitionPresentedScene=0;
            if(_transitionRequestedScene==scene)QueueTransitionPaint(scene,now);
        }
        private bool RecordTransitionPaint(TransitionPaintRequest request,double painted) {
            if(!ReferenceEquals(request,_transitionPaintRequest) || _frame?.Ready!=true || _frame.Scene!=request.Scene)
                return false;
            if(!double.IsFinite(painted) || painted<request.After)
                throw new InvalidOperationException("Transition repaint did not satisfy its current frame fence");
            _transitionPaintRequest=null;
            _requiredFrameMs=Math.Max(_requiredFrameMs,painted);
            return true;
        }
        internal void RequireFreshTransitionFrame(long scene) {
            if(_disposed || scene<=0) return;
            _requiredFrameMs=Math.Max(_requiredFrameMs,NowMs());
            _transitionRequestedScene=scene;
            _transitionGradeScene=0; _transitionPresentedScene=0;
            QueueTransitionPaint(scene,_requiredFrameMs);
            LogManager.Log("event=world_transition_frame_required scene="+scene+" frameFenceMs="
                +_requiredFrameMs.ToString("F1",CultureInfo.InvariantCulture));
        }
        internal bool IsTransitionScenePresented(long scene) => !_disposed && !_faulted && _active
            && _surface?.Visible == true && _transitionPresentedScene == scene
            && _frame?.Ready == true && _frame.Scene == scene && !_lighting.Pending && !_lighting.WaitingForCapture;
        // A report may now pause/hide an already captured scene. This is only the identity
        // recheck after that capture proof; it never grants an initial world reveal.
        internal bool IsCurrentTransitionScene(long scene) => !_disposed && !_faulted
            && _frame?.Ready == true && _frame.Scene == scene;
        private bool _disposed, _starting, _faulted, _active;
        private double _faultedRevokeDeadlineMs;
        private bool _inputRenewRequested,_inputClosed;
        private volatile bool _transitionInputHeld;
        internal void HoldTransitionInput(bool held) {
            if (_transitionInputHeld==held) return;
            _transitionInputHeld=held;
            if(held) _surface?.CancelPointer("scene_transition");
        }
        private Task<bool> _retiringInput;
        internal NativePointerBridge InputBridgeForDiagnostics => _pointerBridge;
        internal int InputRenewals { get; private set; }
        private readonly uint _inputEpochLimit;
        private bool _permissionChecked, _borderless;
        private double _waitingStateMs;
        private double _requiredFrameMs, _startedMs, _lastLogMs;
        private readonly bool _profileHudCosts=Environment.GetEnvironmentVariable("CF7_PLAYER_HUD_PROFILE")=="1";
        private bool _hudCostProfiling;
        private string _hudCostProfileId;
        private float[] _lastSettings;
        // LUT 路径（lut-set-v1）：_lutActive=原生当前在 LUT 分支；_lastLut/_lastLutLight 是变更检测
        // （变更才上传，不逐帧传）；会话重建（StopCapture/ResetSource）时随 _lastSettings 一并复位。
        private bool _lutActive;
        private byte[] _lastLut;
        private double _lastLutLight;
        private int _appliedWeatherType=-1, _appliedWeatherQuality=-1;
        private float _appliedWeatherIntensity=float.NaN;
        private uint _appliedWeatherSeed;
        private int _appliedWeatherStyleType=-1;
        private int _appliedAtmospherePreset=-1;
        private string _appliedAtmosphereName;
        private float[] _appliedAtmosphereParameters;
        private readonly object _weatherCameraLock=new object();
        private float _weatherCameraX, _weatherCameraY, _weatherCameraScale=1;
        private float _weatherCameraGroundMin=360, _weatherCameraGroundMax=520;
        private bool _weatherCameraDispatchAllowed;
        private float _appliedWeatherCameraX=float.NaN, _appliedWeatherCameraY=float.NaN;
        private float _appliedWeatherCameraScale=float.NaN, _appliedWeatherGroundMin=float.NaN, _appliedWeatherGroundMax=float.NaN;
        private bool _weatherCapabilityAdvertised;
        private double _lastWeatherCapAttemptMs;
        internal Func<bool,bool> WeatherCapabilityChanged;
        internal Func<bool,bool> BulletCapabilityChanged;
        internal Action BulletInvalidated;
        private volatile bool _bulletStylesReady, _bulletCapabilityAdvertised;
        private readonly VisualCapabilityRevocation _bulletRevocation = new();
        private double _lastBulletCapAttemptMs;
        private double _bulletCaptureNotReadyMs;
        private long _lastBulletFrameLogTicks;
        private int _targetHeight=1080, _appliedHeight=-1, _effectLevel;
        private RenderPresentationRequest _renderCompletion;
        private sealed class RenderPresentationRequest
        {
            internal readonly RenderSelection Selection;
            internal readonly Action<Size> Completed;
            internal double CaptureAfter=double.PositiveInfinity;
            internal RenderPresentationRequest(RenderSelection selection,Action<Size> completed)
            { Selection=selection;Completed=completed; }
        }
        internal Func<Size> ReadFlashSourceSize;
        private float _targetSharpness;
        private float _appliedSharpness=float.NaN;
        private bool _casEnabled=true,_motionFeedbackEnabled;
        private string _imageQuality="MEDIUM";
        private (bool Cas,bool Feedback,string Quality,int Stage)? _appliedImageOptions;
        internal void ConfigurePostprocessing(bool cas,bool feedback) {
            _casEnabled=cas;_motionFeedbackEnabled=feedback;
        }
        private void ApplyImageOptions() {
            var options=(Cas:_casEnabled,Feedback:_motionFeedbackEnabled,Quality:_imageQuality,Stage:WorldPostprocessPolicy.CasStage(_imageQuality));
            if(_native==null || _appliedImageOptions==options)return;
            _native.Postprocess(options.Cas,WorldPostprocessPolicy.CasStrength(options.Quality),options.Feedback,options.Stage);
            _appliedImageOptions=options;
            LogManager.Log("event=world_postprocess_configured cas="+_casEnabled
                +" feedback="+_motionFeedbackEnabled+" quality="+_imageQuality+" casStage="+options.Stage);
        }
        private bool _viewportHeld;
        private double _paintFenceMs;
        // A0 观测：「曾经 ready」与「当前推进」分离。_everReady 闩锁首次有效帧；
        // _frameAdvancing 按 250ms 有界窗口判定推进，用于区分停帧/暂停/阻塞，
        // 只观测记录，不触发自动重启或抢焦。
        private bool _everReady, _frameAdvancing, _progressKnown;
        private volatile bool _schedulingAllowed;
        // Loading stalls are not gameplay pressure. Capture must keep running to
        // prove the target scene, without changing quality/viewport behind its report.
        internal bool SchedulingAllowed => _schedulingAllowed && !_transitionInputHeld;
        internal bool RouteCapturedPointer(int x,int y,int message,uint mouseData) =>
            !_disposed && !_transitionInputHeld && _active && _surface!=null && _surface.RouteCapturedPointer(x,y,message,mouseData);
        internal void ApplyRenderSelection(RenderSelection selection,float sharpness,Action<Size> completed=null)
        {
            if (_disposed) return;
            _targetHeight=selection.Height;
            _effectLevel=selection.EffectLevel;
            _renderCompletion=completed==null ? null : new RenderPresentationRequest(selection,completed);
            _targetSharpness=0; // Production uses CAS; legacy diagnostic setter stays available.
            _imageQuality=selection.Quality;
            _schedulingAllowed=false;
        }
        private bool RecordRenderPaint(RenderPresentationRequest request,double painted)
        {
            if (_disposed || request==null || !ReferenceEquals(request,_renderCompletion)) return false;
            if (!double.IsFinite(painted) || painted<=0) throw new InvalidOperationException("Invalid render repaint fence");
            request.CaptureAfter=painted;
            return true;
        }
        private bool CompleteRenderSelection(RenderPresentationRequest request,double capturedAt,Size source)
        {
            if (_disposed || request==null || !ReferenceEquals(request,_renderCompletion)
                || !double.IsFinite(request.CaptureAfter) || !double.IsFinite(capturedAt)
                || capturedAt<request.CaptureAfter || request.Selection.Height!=_appliedHeight) return false;
            // Clear only this request before invoking external code: the callback may
            // synchronously choose another target, which must retain its own fence.
            _renderCompletion=null;
            request.Completed(source);
            return true;
        }
        // The F packet already drives hit numbers on the socket thread. Forward its
        // camera to the native visual state on that path as well: waiting for the
        // 33 ms UI timer adds a visible frame during running camera movement.
        internal void ObserveWeatherCamera(float x,float y,float scale)
        {
            if (!float.IsFinite(x) || !float.IsFinite(y) || !float.IsFinite(scale)
                || Math.Abs(x)>1000000 || Math.Abs(y)>1000000 || scale<=0 || scale>20) return;
            lock (_weatherCameraLock) {
                _weatherCameraX=x; _weatherCameraY=y; _weatherCameraScale=scale;
                if (_weatherCameraDispatchAllowed && _native!=null) PushWeatherCameraLocked();
            }
        }
        internal void ObserveBulletFrame(BulletVisualFrame frame,float cameraX,float cameraY,float cameraScale)
        {
            if (frame == null) return;
            Exception failure = null;
            lock (_weatherCameraLock)
            {
                if (!_bulletCapabilityAdvertised || !_bulletStylesReady || _native == null) return;
                try {
                    _native.BulletFrame(frame,cameraX,cameraY,cameraScale);
                    if (frame.NativeOwned && frame.InstanceCount > 0) {
                        long now=Stopwatch.GetTimestamp();
                        if (now-_lastBulletFrameLogTicks>=Stopwatch.Frequency*2) {
                            _lastBulletFrameLogTicks=now;
                            LogManager.Log("event=bullet_visual_native_frame epoch="+frame.Epoch
                                +" frame="+frame.Frame+" normal="+frame.NormalCount
                                +" chain="+frame.ChainCount+" overflow="+frame.Overflow);
                        }
                    }
                }
                catch (Exception error) {
                    failure = error;
                    LogManager.Log("event=bullet_visual_native_frame_failed " + error.Message);
                }
            }
            if (failure != null) ProjectileRenderFault("native_frame_failed", failure);
        }
        // Critical projectile-channel malformed/rejected/submission-failed packets
        // share the existing session render-failure path instead of revoking into
        // an AS2 fallback. Capability revocation survives only for real source
        // loss: socket disconnect, capture stop, and owner teardown.
        private void ProjectileRenderFault(string reason, Exception error)
        {
            EnterRenderFault("projectile_" + reason, error ?? new InvalidOperationException(reason));
        }
        internal void RejectBulletFrame() => ProjectileRenderFault("frame_rejected", null);
        /// <summary>
        /// AS2 视觉桥主动上报的源端致命故障（容量/配对协议错误）。字段已被
        /// FrameTask.HandleVisualFault 有界校验；消息天然绑定当前连接代。
        /// </summary>
        internal void As2VisualFault(string channel,string reason)
            => ProjectileRenderFault("as2_" + channel + "_" + reason,null);
        private void EnterRenderFault(string reason, Exception error)
        {
            // Socket callbacks arrive off the UI thread; the single failure
            // transition (hide, stop capture, dialog, close) stays owner-bound.
            if (_disposed) return;
            if (_owner.IsDisposed) return;
            if (_owner.InvokeRequired)
            {
                try { _owner.BeginInvoke(new Action(() => EnterRenderFault(reason, error))); }
                catch (Exception invokeError) {
                    LogManager.Log("event=world_compositor_fault_dispatch_failed " + invokeError.Message);
                }
                return;
            }
            if (_faulted) return;
            _faulted=true;
            PerformanceUnavailable?.Invoke();
            // The failure dialog runs a nested UI loop. Keep only bounded
            // ownership-revoke retries alive while it awaits closure.
            _faultedRevokeDeadlineMs=NowMs()+10000;
            _owner.Hide();
            StopCapture();
            if (!_bulletRevocation.Pending && !_rayRevocation.Pending) _timer.Stop();
            LogManager.Log("event=world_compositor_failed reason=" + reason + " " + error);
            // Rendering is a runtime requirement. Do not silently continue as a fully lit world.
            if (!_owner.IsDisposed) {
                MessageBox.Show(_owner,"世界画面渲染失败，本次游戏将关闭。请保留日志并使用配套构建重试。\n"
                    + error.Message,"画面渲染失败",MessageBoxButtons.OK,MessageBoxIcon.Error);
                _owner.Close();
            }
        }
        internal void BulletConnectionLost()
        {
            RevokeBulletCapability("socket_disconnected");
            _bulletRevocation.Reset();
        }
        internal void ClearBulletFrame()
        {
            lock (_weatherCameraLock)
            {
                try { _native?.ClearBulletFrame(); }
                catch (Exception error) { LogManager.Log("event=bullet_visual_clear_failed " + error.Message); }
            }
        }
        private void RevokeBulletCapability(string reason,bool worldUnavailable=false)
        {
            if(worldUnavailable) RevokeRayCapability(reason);
            bool advertised;
            lock (_weatherCameraLock)
            {
                advertised = _bulletCapabilityAdvertised;
                _bulletCapabilityAdvertised = false;
                try { _native?.ClearBulletFrame(); }
                catch (Exception error) { LogManager.Log("event=bullet_visual_clear_failed " + error.Message); }
            }
            if (!advertised) return;
            BulletInvalidated?.Invoke();
            _bulletRevocation.Request();
            RetryBulletRevocation();
            LogManager.Log("event=bullet_visual_cap_revoke reason=" + reason + " sent=" + !_bulletRevocation.Pending);
        }
        private void RetryBulletRevocation()
        {
            try { _bulletRevocation.TrySend(NowMs(), () => BulletCapabilityChanged?.Invoke(false) == true); }
            catch (Exception error) { LogManager.Log("event=bullet_visual_cap_revoke_retry_failed " + error.Message); }
        }
        internal static bool CanGrantProjectileCapability(bool captureReady, bool sceneReady,
            bool waitingForCapture, long scene, long capturedScene) =>
            captureReady && sceneReady && !waitingForCapture && scene == capturedScene;
        private void NoteBulletCaptureNotReady(string reason)
        {
            NoteRayCaptureNotReady(reason);
            // Temporary capture unavailability suspends presentation only. Live
            // AS2/Host state is retained and resumes on the next ready tick.
            if (!_bulletCapabilityAdvertised) { _bulletCaptureNotReadyMs=0; return; }
            double now=NowMs();
            if (_bulletCaptureNotReadyMs==0) {
                _bulletCaptureNotReadyMs=now;
                LogManager.Log("event=bullet_visual_capture_wait reason=" + reason);
            }
        }

        internal readonly struct LutLabGrabResult
        {
            internal LutLabGrabResult(int code,int width,int height) { Code=code; Width=width; Height=height; }
            internal readonly int Code, Width, Height;
        }
        internal double LightingGamma => _preset.Gamma;
        // dev-only LUT 实验室抓帧桥：返回最近捕获帧（未调色 BGRA）。_native 生命周期归 UI 线程，
        // 跨线程调用经 owner.Invoke 排队；合成器未运行/导出缺失/无有效帧时透传原生错误码。
        internal LutLabGrabResult GrabLatestFrameBgra(byte[] buffer)
        {
            if (_owner.IsDisposed) return new LutLabGrabResult(NativeCompositorSession.GrabNoFrame,0,0);
            if (_owner.InvokeRequired)
                return (LutLabGrabResult)_owner.Invoke(new Func<LutLabGrabResult>(() => GrabLatestFrameBgra(buffer)));
            var session=_native;
            if (_disposed || session==null) return new LutLabGrabResult(NativeCompositorSession.GrabNoFrame,0,0);
            // 缺陷 X（2026-09-24）：合成器未呈现（含面板遮挡挂起）或世界视口裁剪尚未建立时，
            // 原生侧 crop 为空会退化为整窗回读（含标题栏）。仅世界视口已建立才允许抓帧。
            if (!CanGrabWorldViewport(_active,_crop)) return new LutLabGrabResult(NativeCompositorSession.GrabNoWorldViewport,0,0);
            int width,height;
            return new LutLabGrabResult(session.GrabLatestFrame(buffer,out width,out height),width,height);
        }
        internal static bool CanGrabWorldViewport(bool active, System.Drawing.Rectangle crop)
        {
            return active && crop.Width >= 1 && crop.Height >= 1;
        }

        internal static NightVisionProfile ResolveNightVision(Dictionary<string,NightVisionProfile> profiles,string mode,bool requested,bool ready)
            => requested && ready && mode!=null && profiles.TryGetValue(mode,out var profile)?profile:NightVisionProfile.None;
        private static bool SameMatrix(double[] left,double[] right)
        {
            if (right==null || left.Length!=right.Length)return false;
            for(int i=0;i<left.Length;i++)if(Math.Abs(left[i]-right[i])>1e-6)return false;
            return true;
        }

        internal static bool NightLutChanged(double[] matrix,double shadowLift,double[] previousMatrix,double previousLift)
            => !double.IsFinite(previousLift) || Math.Abs(shadowLift-previousLift)>1e-6 || !SameMatrix(matrix,previousMatrix);

        internal WorldCompositorController(Form owner, Control anchor, Func<IntPtr> getFlash,
            Func<bool> canPresent, Action<string> notify, string projectRoot, Func<bool> shouldPrepare,
            Action<int> setRenderHeight,Action focusFlash,uint inputEpochLimit=WorldPointerMapper.EpochLimit,
            BulletVisualCatalog bulletCatalog=null,CombatFxCatalog combatFxCatalog=null,
            IEnumerable<OverlayBase> overlays=null,bool opaqueHudEnabled=false)
        {
            string tempRoot=Path.GetFullPath(Path.Combine(projectRoot,"tmp"))+Path.DirectorySeparatorChar;
            string testCap=Environment.GetEnvironmentVariable("CF7_INPUT_SESSION_TEST_CAP");
            if(inputEpochLimit==WorldPointerMapper.EpochLimit && AppContext.BaseDirectory.StartsWith(tempRoot,StringComparison.OrdinalIgnoreCase)
                && !string.IsNullOrWhiteSpace(testCap)) {
                if(!uint.TryParse(testCap,out inputEpochLimit) || inputEpochLimit<8 || inputEpochLimit>WorldPointerMapper.EpochLimit)
                    throw new ArgumentOutOfRangeException("CF7_INPUT_SESSION_TEST_CAP");
                LogManager.Log("event=world_pointer_test_cap value="+inputEpochLimit+" NOT_DEPLOYED=true");
            }
            _inputEpochLimit=inputEpochLimit;
            _owner=owner; _anchor=anchor; _getFlash=getFlash; _canPresent=canPresent; _notify=notify; _shouldPrepare=shouldPrepare;
            Rectangle CurrentOutputBounds() => _anchor.RectangleToScreen(_anchor.ClientRectangle);
            ResourcePresentation = new WorldRasterPresentation(CurrentOutputBounds);
            BottomPresentation = new WorldRasterPresentation(CurrentOutputBounds);
            BuffPresentation = new WorldRasterPresentation(CurrentOutputBounds);
            MainHudPresentation = new WorldRasterPresentation(CurrentOutputBounds);
            DamagePresentation.Faulted += error => EnterRenderFault("shared_raster", error);
            ResourcePresentation.Faulted += error => RejectPlayerHud("resource_raster", error);
            BottomPresentation.Faulted += error => RejectPlayerHud("bottom_raster", error);
            BuffPresentation.Faulted += error => RejectPlayerHud("buff_raster", error);
            MainHudPresentation.Faulted += error => RejectPlayerHud("main_hud_raster", error);
            _opaqueHudEnabled=opaqueHudEnabled;
            _setRenderHeight=setRenderHeight; _focusFlash=focusFlash;
            _bulletCatalog=bulletCatalog;
            _combatFxCatalog=combatFxCatalog;
            var sceneCatalog=SceneLightCatalog.Load(projectRoot);
            _sceneLights=new SceneLightEngine(sceneCatalog);
            _worldLights=new WorldLightComposer(combatFxCatalog?.MaximumLightResponse??0,sceneCatalog.SceneReserve);
            _worldLightSubmissions=new WorldLightSubmitBatch((draw,x,y,scale) => _native?.CombatFxFrame(draw,x,y,scale));
            _overlays=overlays ?? Array.Empty<OverlayBase>();
            _bulletCandidateEnabled=bulletCatalog!=null
                && Environment.GetEnvironmentVariable("CF7_BULLET_NATIVE_DISABLE")!="1";
            _preset=WorldLightingPreset.Load(Path.Combine(projectRoot,"launcher","data","world-lighting","preset.json"),
                message => LogManager.Log(message));
            string visionPath=Path.Combine(projectRoot,"data","environment","color_engine_preset.xml");
            _nightVisionProfiles=File.Exists(visionPath)?NightVisionProfile.Load(visionPath):new Dictionary<string,NightVisionProfile>(StringComparer.Ordinal);
            string visualPath=Path.Combine(projectRoot,
                WorldPresentationCatalog.RelativePath.Replace('/',Path.DirectorySeparatorChar));
            _presentationCatalog=WorldPresentationCatalog.Load(visualPath);
            LogManager.Log("event=world_presentation_catalog sha256="+_presentationCatalog.Sha256+" path="+visualPath);
            _timer.Tick+=OnTick;
            _owner.LocationChanged+=OnGeometryChanged; _owner.SizeChanged+=OnGeometryChanged;
            _owner.DpiChanged+=OnDpiChanged; _owner.FormClosed+=OnClosed; _owner.Deactivate+=OnOwnerDeactivated;
            _anchor.SizeChanged+=OnGeometryChanged; _anchor.LocationChanged+=OnGeometryChanged;
            _timer.Start();
        }
        internal void Adopt(WorldLightingFrame frame)
        {
            bool wasPending=_lighting.Pending;
            bool wasWaiting=_lighting.WaitingForCapture;
            long previousScene=_frame?.Scene ?? 0;
            if (_disposed || !_lighting.Adopt(frame,NowMs())) return;
            if (!frame.Ready || frame.Scene!=previousScene)
                _surface?.CancelPointer();
            if(frame.Scene!=previousScene)_native?.ResetFeedback();
            _frame=frame;
            QueueSceneLights(frame);
            if (!frame.Ready || frame.Scene!=previousScene) InvalidateWeather();
            if (_lighting.Pending && (!wasPending || frame.Scene!=previousScene))
                LogManager.Log("event=world_lighting_hold scene="+frame.Scene+" hasGrade="+_lighting.HasValidState);
            if (_lighting.WaitingForCapture && (!wasWaiting || frame.Scene!=previousScene))
                LogManager.Log("event=world_lighting_wait_frame scene="+frame.Scene+" seq="+frame.Sequence);
            if (frame.Ready && !_lighting.WaitingForCapture && (wasPending || frame.Scene!=previousScene || frame.Immediate))
                LogManager.Log("event=world_lighting_state seq="+frame.Sequence+" scene="+frame.Scene+" ready=true light="+frame.Light.ToString("F3",CultureInfo.InvariantCulture)+" mode="+frame.Mode+" sourceNeutral=true blendMs="+_lighting.BlendDurationMs.ToString("F0",CultureInfo.InvariantCulture));
        }
        internal void ResetSource()
        {
            ResetSceneLights();
            _lighting=new WorldLightingTransition(); _reportedPendingScene=0; _frame=null; _schedulingAllowed=false; StopCapture();
            _appliedHeight=-1; _renderCompletion=null;
        }
        private async void OnTick(object sender,EventArgs args)
        {
            if (_disposed) return;
            RetryBulletRevocation();
            RetryRayRevocation();
            if (_faulted) {
                if ((!_bulletRevocation.Pending && !_rayRevocation.Pending) || NowMs() >= _faultedRevokeDeadlineMs)
                    _timer.Stop();
                return;
            }
            if (_starting) return;
            try {
                if(_inputRenewRequested && !_inputClosed) {await RenewInputAsync();if(_disposed)return;}
                string module=Path.Combine(AppContext.BaseDirectory,NativeCompositorSession.ModuleName);
                if (!_permissionChecked) {
                    if (!_shouldPrepare()) return;
                    _starting=true;
                    if (!File.Exists(module)) throw new FileNotFoundException("缺少世界合成模块，请更新完整游戏运行组件",module);
                    int access=await Task.Run(()=>NativeCompositorSession.RequestBorderless(module));
                    if (_disposed) return;
                    _permissionChecked=true; _borderless=access==1;
                    LogManager.Log("event=world_compositor_borderless status="+access);
                    if (!_borderless) _notify?.Invoke("当前系统保留画面捕获边框");
                }
                if (_native==null) {
                    if(_retiringInput!=null) {
                        _starting=true;bool retired=await _retiringInput;_retiringInput=null;
                        if(_disposed)return;
                        if(!retired) {_inputClosed=true;_notify?.Invoke("输入恢复尚未确认，请保留日志后重新启动游戏");return;}
                    }
                    if(_inputClosed)return;
                    if (!_canPresent() || _getFlash()==IntPtr.Zero) return;
                    if (_frame?.Ready!=true) {
                        if (_waitingStateMs==0) _waitingStateMs=NowMs();
                        if (NowMs()-_waitingStateMs>30000) throw new TimeoutException("未收到有效的 AS2 场景光照状态");
                        return;
                    }
                    _waitingStateMs=0; _starting=true;
                    if (_disposed || !_canPresent()) return;
                    _flash=_getFlash(); _pointerBridge=await NativePointerBridge.Start(_flash,_owner.Handle);
                    if(_disposed || _flash!=_getFlash()) { _pointerBridge.Dispose(); return; }
                    _surface=new WorldCompositionSurface(_getFlash,_focusFlash,_pointerBridge,_inputEpochLimit) { Owner=_owner };
                    _surface.SetHudInput(_combinedHudInput);
                    _overlayOrder=new WorldOverlayOrder(_owner,_surface,_overlays,CanShow);
                    BindInput(_pointerBridge,_surface);
                    _surface.CreateControl();
                    _compositionScene=CompositionSceneHost.Create(_surface.Handle,module);
                    _compositionSceneCommitted=false;
                    IntPtr worldVisual=_compositionScene.AcquireVisual(0);
                    try { _native=new NativeCompositorSession(module,_owner.Handle,(uint)Environment.ProcessId,_surface.Handle,0,_borderless,worldVisual); _appliedImageOptions=null;ApplyImageOptions(); }
                    finally { Marshal.Release(worldVisual); }
                    StartHudCostProfile();
                    _damageRasterScene=_opaqueHudEnabled ? new OpaqueHudRasterScene(_native,0) : _compositionScene;
                    _resourceRasterScene=_opaqueHudEnabled && !_playerHudFaulted ? new OpaqueHudRasterScene(_native,1) : null;
                    _bottomRasterScene=_opaqueHudEnabled && !_playerHudFaulted ? new OpaqueHudRasterScene(_native,2) : null;
                    _buffRasterScene=_opaqueHudEnabled && !_playerHudFaulted ? new OpaqueHudRasterScene(_native,3) : null;
                    _mainHudRasterScene=_opaqueHudEnabled && !_playerHudFaulted ? new OpaqueHudRasterScene(_native,4) : null;
                    LogManager.Log("event=world_hud_backend opaque="+_opaqueHudEnabled+" layers=damage,bottom,resources,buffs");
                    _bulletStylesReady=false;
                    _combatFxResourcesReady=false;
                    if (_combatFxCatalog!=null) {
                        try { _native.CombatFxAtlas(_combatFxCatalog);_combatFxResourcesReady=true; }
                        catch(Exception error) { LogManager.Log("event=combat_fx_atlas_unavailable "+error.Message); }
                    }
                    if (_bulletCandidateEnabled) {
                        try { _native.BulletStyles(_bulletCatalog); _bulletStylesReady=true; }
                        catch (Exception error) {
                            LogManager.Log("event=bullet_visual_styles_unavailable " + error.Message);
                            EnterRenderFault("bullet_styles_unavailable", error);
                            return;
                        }
                    }
                    LogManager.Log("event=world_compositor_identity S=0x"+_owner.Handle.ToString("X")+" P=0x"+_surface.Handle.ToString("X")
                        +" F=0x"+_flash.ToString("X")+" hostPid="+Environment.ProcessId+" inputSession="+_pointerBridge.SessionIdentity);
                    _crop=Rectangle.Empty; _startedMs=NowMs(); _lastSettings=null; _active=true; _appliedSharpness=float.NaN;
                    _lastLut=null; _lutActive=false; _lutOwner=null; _lastNightMatrix=null; _lastNightShadowLift=double.NaN; _appliedNightVision=null;
                    _appliedWeatherType=-1;
                    _appliedWeatherStyleType=-1;
                    _appliedAtmospherePreset=-1;
                    _appliedAtmosphereName=null;
                    LogManager.Log("event=world_compositor_start flash=0x"+_flash.ToString("X")+" fpsLimit=30");
                }
                if (_getFlash()!=_flash || !IsWindow(_flash)) { ResetSource(); return; }
                // Scene changes clear native weather before any geometry/ready early return.
                if (_appliedWeatherType<0) ApplyWeather(false);
                if (_appliedAtmospherePreset<0) ApplyAtmosphere(false);
                if(!_pointerBridge.IsAlive && !_inputClosed && !_inputRenewRequested) {
                    _inputClosed=true;_surface.CancelPointer("bridge_closed");
                    LogManager.Log("event=world_pointer_closed_unconfirmed unexpected_exit");
                    _notify?.Invoke("输入连接已停止，请保留日志后重新启动游戏");
                }
                // Scene readiness changes the grade, not ownership of the visible surface.
                // Keep capturing with the held grade until the next scene is ready.
                bool show=_lighting.ShouldPresent(CanShow());
                if (show && _lighting.IsOverdue(NowMs()) && _reportedPendingScene!=_frame.Scene) {
                    _reportedPendingScene=_frame.Scene;
                    LogManager.Log("event=world_lighting_hold_long scene="+_frame.Scene);
                }
                if (show!=_active) {
                    _active=show; _native.Active(show); _requiredFrameMs=NowMs();
                    if (!show) _surface.Hide();
                }
                if (!_active) {
                    RefreshHudPresentations();
                    _schedulingAllowed=false;
                    if (_frame==null && NowMs()-_startedMs>10000) throw new TimeoutException("未收到配套 AS2 光照状态，请检查 asLoader 构建");
                    return;
                }
                _surface.FlushMove();
                if (!_transitionInputHeld && !_inputClosed && !_surface.InputRenewing && _targetHeight!=_appliedHeight && !_surface.IsDragging) {
                    _starting=true; _schedulingAllowed=false;
                    var resizingNative=_native; var resizingSource=_flash;
                    double resizeStarted=NowMs();
                    _native.HoldViewport(); _viewportHeld=true;
                    double heldAt=NowMs();
                    _setRenderHeight(_targetHeight); _appliedHeight=_targetHeight;
                    var resizeRequest=_renderCompletion;
                    bool budgetBeforePaint=resizeRequest!=null && _frame?.Ready==true
                        && !_lighting.WaitingForCapture && _lighting.ReadyScene==_frame.Scene;
                    if(budgetBeforePaint) {
                        ApplyImageOptions();
                        _native.Sharpness(_targetSharpness); _appliedSharpness=_targetSharpness;
                        ApplyWeatherCamera(true); ApplyWeather(true);
                    }
                    double resizedAt=NowMs();
                    double painted=await _pointerBridge.RepaintAsync(heldAt);
                    if (_disposed || _native!=resizingNative || _getFlash()!=resizingSource) return;
                    _paintFenceMs=painted;
                    _requiredFrameMs=Math.Max(_requiredFrameMs,painted);
                    if(budgetBeforePaint) RecordRenderPaint(resizeRequest,painted);
                    LogManager.Log("event=world_render_resize sourceHeight="+_appliedHeight.ToString(CultureInfo.InvariantCulture)
                        +" paintFenceMs="+painted.ToString("F1",CultureInfo.InvariantCulture)
                        +" waitGpuMs="+(heldAt-resizeStarted).ToString("F1",CultureInfo.InvariantCulture)
                        +" resizeMs="+(resizedAt-heldAt).ToString("F1",CultureInfo.InvariantCulture)
                        +" repaintMs="+(NowMs()-resizedAt).ToString("F1",CultureInfo.InvariantCulture)
                        +" handoffMs="+(NowMs()-resizeStarted).ToString("F1",CultureInfo.InvariantCulture));
                    if (!CanShow()) { _native.Active(false); _active=false; _surface.Hide(); RefreshHudPresentations(); return; }
                }
                // A covered empty scene can be completely static. Request one real Flash
                // paint for each freshness fence instead of waiting for unrelated animation.
                var transitionPaint=_transitionPaintRequest;
                if(transitionPaint!=null && _frame?.Ready==true && _frame.Scene==transitionPaint.Scene
                    && !_inputClosed && !_surface.InputRenewing) {
                    _starting=true;
                    var paintingNative=_native; var paintingSource=_flash; var paintingBridge=_pointerBridge;
                    double painted=await paintingBridge.RepaintAsync(transitionPaint.After);
                    if(_disposed || _native!=paintingNative || _getFlash()!=paintingSource || _pointerBridge!=paintingBridge) return;
                    if(RecordTransitionPaint(transitionPaint,painted))
                        LogManager.Log("event=world_transition_repaint scene="+transitionPaint.Scene+" paintFenceMs="
                            +painted.ToString("F1",CultureInfo.InvariantCulture));
                    // The repaint acknowledgment is not a WGC capture receipt. Read a later
                    // frame before granting scene presentation or changing the curtain.
                    return;
                }
                NativeCompositorSession.Stats stats;
                using (CF7Launcher.Diagnostic.InputLatencyProbe.Measure("world_read")) stats=_native.Read();
                if (stats.State==2 || stats.State==3) throw new InvalidOperationException(stats.Message+" HRESULT=0x"+stats.Error.ToString("X8"));
                if (!Synchronize()) { NoteBulletCaptureNotReady("geometry_unknown"); return; } // an unknown extent must not mask native failure
                bool ready=stats.Received>0 && stats.Width==_crop.Width && stats.Height==_crop.Height && stats.LastFrameQpcMs>=_requiredFrameMs;
                if (ready) _bulletCaptureNotReadyMs=0;
                else NoteBulletCaptureNotReady("capture_not_ready");
                // A0 观测：推进证据用有界窗口而非逐 tick 比较——30FPS 下逐 tick 比
                // LastFrameQpcMs 会因两时钟错位交替 flap。age<250ms 视为推进中；
                // 静态/暂停场景源不推进是合法的，不按固定帧龄判死，只分离事实：
                // everReady（曾经出帧）、advancing（推进窗口内）、sceneReady（AS2 场景状态）。
                bool advancing=stats.LastFrameQpcMs>0 && NowMs()-stats.LastFrameQpcMs<250;
                if (ready) _everReady=true;
                if (!_progressKnown || advancing!=_frameAdvancing)
                {
                    _progressKnown=true; _frameAdvancing=advancing;
                    LogManager.Log("event=world_compositor_progress state="+(advancing?"advancing":"stalled")
                        +" everReady="+_everReady+" sceneReady="+(_frame?.Ready==true)
                        +" captureQpcMs="+stats.LastFrameQpcMs.ToString("F1",CultureInfo.InvariantCulture));
                }
                // Observe healthy FPS during a gesture; only the actual resize waits
                // for release. Frequent clicks must not reset the recovery timer.
                _schedulingAllowed=!_inputClosed && !_surface.InputRenewing && ready && _frame?.Ready==true && _targetHeight==_appliedHeight && _renderCompletion==null;
                if (ready)ApplyImageOptions();
                if (ready && _appliedSharpness!=_targetSharpness) { _native.Sharpness(_targetSharpness); _appliedSharpness=_targetSharpness; }
                // Read() reports a captured frame after its Present submission. This is a
                // timestamp freshness fence, not proof of the pixels' semantic scene identity.
                if (ready && _lighting.ConfirmCapturedFrame(stats.LastFrameQpcMs,NowMs()))
                    LogManager.Log("event=world_lighting_frame_handoff scene="+_lighting.ReadyScene+" captureQpcMs="+stats.LastFrameQpcMs.ToString("F1",CultureInfo.InvariantCulture));
                lock(_weatherCameraLock) {
                    if(ApplySceneLightsLocked() && _native!=null)
                        _worldLightSubmissions.Submit(_worldLights.Compose(_weatherCameraX,_weatherCameraY,_weatherCameraScale),_weatherCameraX,_weatherCameraY,_weatherCameraScale,false);
                }
                double cameraNow=NowMs();
                var night=ResolveNightVision(_nightVisionProfiles,_lighting.CurrentMode,_lighting.NightVisionRequested,
                    _frame?.Ready==true && !_lighting.Pending && !_lighting.WaitingForCapture && _lighting.ReadyScene==_frame.Scene);
                long visionScene=_frame?.Scene??0;
                var matrix=_lighting.Sample(cameraNow);
                var settings=_preset.ShaderSettings(matrix);
                byte[] upload=null;
                bool useLut=night.Enabled || _preset.UsesLut(_lighting.CurrentMode);
                string owner=night.Enabled?"night":useLut?"ambient":null;
                double lutLight=useLut && !night.Enabled?WorldLutSet.ClampLight(_lighting.SampleLight(cameraNow)):0;
                double shadowLift=night.Enabled && _lighting.SampleLight(cameraNow)!=7?night.ShadowLift:0;
                if(night.Enabled) {
                    if(_lutOwner!=owner || NightLutChanged(matrix,shadowLift,_lastNightMatrix,_lastNightShadowLift))
                        upload=WorldLutBaker.BakeMatrix(matrix,_preset.Gamma,shadowLift);
                } else if(useLut) {
                    if(_lutOwner!=owner || _lastLut==null || Math.Abs(lutLight-_lastLutLight)>1e-6)
                        upload=_preset.LutSet.BlendLevel(lutLight);
                }
                bool profileChanged=!ReferenceEquals(night,_appliedNightVision) || _appliedNightVisionScene!=visionScene;
                bool cameraChanged=profileChanged || upload!=null || useLut!=_lutActive || _lastSettings==null;
                for(int i=0;!cameraChanged && i<settings.Length;i++)
                    if(Math.Abs(settings[i]-_lastSettings[i])>1e-6f)cameraChanged=true;
                if(cameraChanged) {
                    _native.NightVision(night,visionScene,settings,useLut,upload);
                    _appliedNightVision=night;_appliedNightVisionScene=visionScene;_lastSettings=settings;
                    _lutOwner=owner;_lutActive=useLut;
                    if(night.Enabled){_lastNightMatrix=matrix;_lastNightShadowLift=shadowLift;}
                    else if(useLut){if(upload!=null)_lastLut=upload;_lastLutLight=lutLight;}
                    if(profileChanged)LogManager.Log("event=night_vision_profile mode="+night.Name+" title="+night.Title+" active="+night.Enabled+" scene="+visionScene);
                }
                // Read can still report the pre-paint capture while Synchronize
                // releases our held viewport. Keep the submitted target during
                // that wait; clearing weather here would invalidate the fence.
                // Scene readiness inside both setters continues to gate ownership.
                bool waitingForBudgetCapture=_renderCompletion!=null && double.IsFinite(_renderCompletion.CaptureAfter);
                ApplyWeatherCamera(ready || waitingForBudgetCapture);
                ApplyWeather(ready || waitingForBudgetCapture);
                if (ready && _frame?.Ready==true && !_lighting.WaitingForCapture && _lighting.ReadyScene==_frame.Scene
                    && !_transitionInputHeld && !_inputClosed && !_surface.InputRenewing
                    && !_surface.IsDragging && _targetHeight==_appliedHeight && _renderCompletion!=null) {
                    var request=_renderCompletion;
                    if (!double.IsFinite(request.CaptureAfter)) {
                        // Height may be unchanged while quality/effects change. A
                        // native-only Present can reuse the old Flash texture, so
                        // every complete target needs its own post-setter repaint.
                        _starting=true;
                        var paintingNative=_native; var paintingSource=_flash;
                        _native.HoldViewport(); _viewportHeld=true;
                        double painted=await _pointerBridge.RepaintAsync(NowMs());
                        if (_disposed || _native!=paintingNative || _getFlash()!=paintingSource) return;
                        _paintFenceMs=painted;
                        _requiredFrameMs=Math.Max(_requiredFrameMs,painted);
                        // An ApplyRenderSelection/ResetSource during the await may
                        // supersede the target. Its callback cannot inherit this paint.
                        RecordRenderPaint(request,painted);
                        return;
                    }
                    CompleteRenderSelection(request,stats.LastFrameQpcMs,
                        ReadFlashSourceSize?.Invoke() ?? _crop.Size);
                }
                ApplyAtmosphere(ready);
                // The grade is submitted after Read's Present. Require a subsequent fresh
                // capture before granting U12 reveal; this is still not a physical pixel receipt.
                if (ready && !_lighting.Pending && !_lighting.WaitingForCapture) {
                    if (_transitionGradeScene != _lighting.ReadyScene) {
                        RecordTransitionGrade(_lighting.ReadyScene,NowMs());
                    } else if (stats.LastFrameQpcMs >= _transitionGradeSubmittedAt)
                        _transitionPresentedScene = _transitionGradeScene;
                } else _transitionPresentedScene = 0;
                bool projectileReady = CanGrantProjectileCapability(ready, _frame?.Ready == true,
                    _lighting.WaitingForCapture, _frame?.Scene ?? 0, _lighting.ReadyScene);
                PublishRayCapability(projectileReady);
                if (ready && !_surface.Visible) { _surface.Show(); PlaceBelowHud(); PresentationShown?.Invoke(); _surface.RefreshPointer(); }
                RefreshHudPresentations();
                if (!_compositionSceneCommitted && stats.Received>0) {
                    _compositionScene.Commit();
                    _compositionSceneCommitted=true;
                }
                if (ready && !_weatherCapabilityAdvertised && NowMs()-_lastWeatherCapAttemptMs>=500) {
                    _lastWeatherCapAttemptMs=NowMs();
                    try { _weatherCapabilityAdvertised=WeatherCapabilityChanged?.Invoke(true)==true; }
                    catch (Exception error) { LogManager.Log("event=world_weather_cap_failed "+error.Message); }
                }
                if (projectileReady && !_bulletRevocation.Pending && _bulletStylesReady && _native.BulletResourcesReady && !_bulletCapabilityAdvertised
                    && NowMs()-_lastBulletCapAttemptMs>=500 && BulletCapabilityChanged!=null) {
                    _lastBulletCapAttemptMs=NowMs();
                    lock (_weatherCameraLock) _bulletCapabilityAdvertised=true;
                    bool sent=false;
                    try { sent=BulletCapabilityChanged(true); }
                    catch (Exception error) { LogManager.Log("event=bullet_visual_cap_failed " + error.Message); }
                    if (!sent) RevokeBulletCapability("cap_send_failed");
                    else LogManager.Log("event=bullet_visual_cap_native");
                }
                if(ready && _combatFxResourcesReady && !_combatFxCapabilityAdvertised
                    && _native.CombatFxReady && NowMs()-_lastCombatFxCapAttemptMs>=500 && CombatFxCapabilityChanged!=null) {
                    _lastCombatFxCapAttemptMs=NowMs();
                    lock(_weatherCameraLock) _combatFxCapabilityAdvertised=true;
                    bool sent=false;
                    try { sent=CombatFxCapabilityChanged(true); }
                    catch(Exception error) { LogManager.Log("event=combat_fx_cap_failed "+error.Message); }
                    if(!sent) RevokeCombatFx("cap_send_failed");
                    else LogManager.Log("event=combat_fx_cap_native");
                }
                if (!ready && NowMs()-Math.Max(_startedMs,_requiredFrameMs)>10000) throw new TimeoutException("世界捕获没有恢复有效画面");
                if (NowMs()-_lastLogMs>1000) {
                    _lastLogMs=NowMs();
                    LogHudCosts(stats);
                    var timing=CF7Launcher.Diagnostic.FocusTrace.Enabled ? _native.ReadTiming() : null;
                    if(timing.HasValue) {
                        var sample=timing.Value;
                        CF7Launcher.Diagnostic.FocusTrace.Record("world.presentation_timing",new {
                            scene=_frame?.Scene,ready,advancing,sourceFrameAgeMs=stats.LastFrameQpcMs>0 ? NowMs()-stats.LastFrameQpcMs : -1,
                            presented=sample.Presented,count=sample.Count,intervalCount=sample.IntervalCount,freshCount=sample.FreshCount,
                            lastPresentAgeMs=sample.LastPresentQpcMs>0 ? NowMs()-sample.LastPresentQpcMs : -1,
                            intervalP50Ms=sample.IntervalP50Ms,intervalP95Ms=sample.IntervalP95Ms,intervalP99Ms=sample.IntervalP99Ms,
                            intervalMaxMs=sample.IntervalMaxMs,submitP95Ms=sample.SubmitP95Ms,presentP95Ms=sample.PresentP95Ms,
                            freshAgeP95Ms=sample.FreshAgeP95Ms,physicalScanoutVerified=false,
                            rasterUploads=DamagePresentation.Uploads,rasterUploadedBytes=DamagePresentation.UploadedBytes });
                    }
                    var postprocess=_native.ReadPostprocess();var casStage=_native.ReadCasStage();
                    LogManager.Log(string.Format(CultureInfo.InvariantCulture,
                        "event=world_compositor_frame received={0} presented={1} size={2}x{3} ageMs={4:F1} submitMs={5:F3} presentMs={6:F3} cpuReadbacks={7} adapter={8} light={9:F3} sourceHeight={10} output={11}x{12} everReady={13} advancing={14} nativeState={15} captureGeneration={16} nativeStage={17} casApplied={18} casStage={19} casSharpness={20:F3} casScale={21:F3}",
                        stats.Received,stats.Presented,stats.Width,stats.Height,stats.LastFrameQpcMs==0 ? -1 : NowMs()-stats.LastFrameQpcMs,stats.SubmitMs,stats.PresentMs,stats.CpuReadbacks,stats.Adapter,_lighting.LastReadyLight,_appliedHeight,_surface.ClientSize.Width,_surface.ClientSize.Height,_everReady,_frameAdvancing,stats.State,_native.CaptureGeneration,stats.Message,
                        postprocess.CasEnabled,casStage.AppliedStage,postprocess.AppliedSharpness,postprocess.InputScale));
                }
            } catch (Exception error) {
                EnterRenderFault("tick", error);
            } finally { _starting=false; }
        }
        private void StartHudCostProfile()
        {
            _hudCostProfiling=false;_hudCostProfileId=null;
            if(!_profileHudCosts)return;
            try {
                if(_native?.HudCostSamplingAvailable!=true)return;
                _native.SetHudCostSampling(true);
                _hudCostProfileId="hwc:"+Guid.NewGuid().ToString("N");_hudCostProfiling=true;
            } catch(Exception error) {LogManager.Log("[WorldHudCost] sampling unavailable: "+error.Message);}
        }
        private void LogHudCosts(NativeCompositorSession.Stats stats)
        {
            if(!_hudCostProfiling)return;
            try {
                LogManager.Log("[WorldHudCost] "+Newtonsoft.Json.JsonConvert.SerializeObject(new {
                    id=_hudCostProfileId,source="native",scene=_frame?.Scene,
                    received=stats.Received,presented=stats.Presented,
                    raster=_native.ReadHudRaster(),work=_native.ReadWork(),cost=_native.ReadHudCost(),
                    scope="Cumulative diagnostic CPU copy spans and asynchronous GPU world/HUD intervals; excludes WGC, Present, DWM and physical scanout"
                }));
            } catch(Exception error) {
                _hudCostProfiling=false;
                try {_native?.SetHudCostSampling(false);} catch { }
                LogManager.Log("[WorldHudCost] sampling stopped: "+error.Message);
            }
        }
        internal void BindInput(NativePointerBridge bridge,WorldCompositionSurface surface)
        {
            _pointerBridge=bridge;_surface=surface;_flash=_getFlash();
            _surface.RenewalRequested+=()=>_inputRenewRequested=true;
        }
        private async Task RenewInputAsync()
        {
            if(_inputRenewRequested && !_inputClosed) {
                    _starting=true;_inputRenewRequested=false;
                    var old=_pointerBridge;var surface=_surface;var source=_flash;
                    bool closed=await old.CloseAsync(surface.GracefulRenewal);
                    if(_disposed || surface!=_surface || source!=_getFlash())return;
                    if(!closed) {
                        _inputClosed=true;_notify?.Invoke("输入恢复尚未确认，请保留日志后重新启动游戏");
                    } else {
                        try {
                            var next=await NativePointerBridge.Start(source,_owner.Handle);
                            if(_disposed || surface!=_surface || source!=_getFlash()) {next.Dispose();return;}
                            _pointerBridge=next;surface.Rebind(next);InputRenewals++;
                            LogManager.Log("event=world_pointer_renewed session="+next.SessionIdentity+" count="+InputRenewals);
                        } catch(Exception error) {
                            _inputClosed=true;LogManager.Log("event=world_pointer_closed_unconfirmed bind="+error.Message);
                            _notify?.Invoke("输入恢复尚未确认，请保留日志后重新启动游戏");
                        }
                    }
                }
        }
        private bool CanShow() => !_owner.IsDisposed && _owner.Visible && _owner.WindowState!=FormWindowState.Minimized && _anchor.Visible && _canPresent();
        private bool Synchronize()
        {
            using var latency = CF7Launcher.Diagnostic.InputLatencyProbe.Measure("world_geometry");
            Rectangle screen=_anchor.RectangleToScreen(_anchor.ClientRectangle);
            if (DwmGetWindowAttribute(_owner.Handle,9,out Rect frame,Marshal.SizeOf<Rect>())!=0) throw new InvalidOperationException("Cannot resolve capture bounds");
            if(!GetWindowRect(_owner.Handle,out Rect window))return false;
            Size content=_native.ReadCaptureSize();
            if(_lastCaptureGeneration!=_native.CaptureGeneration) {
                _lastCaptureGeneration=_native.CaptureGeneration;
                LogManager.Log("event=world_compositor_capture_generation value="+_lastCaptureGeneration+" WGC="+content+" window="+window.Rectangle);
            }
            if(!TryResolveCaptureFrame(frame.Rectangle,window.Rectangle,content,out Rectangle capture))
                return RejectGeometry("capture_bounds_pending content="+content+" window="+window.Rectangle,screen,Rectangle.Empty,frame.Rectangle);
            if (screen.Width<1 || screen.Height<1 || !capture.Contains(screen)) return RejectGeometry("output_outside_capture",screen,Rectangle.Empty,capture);
            if (!GetClientRect(_flash,out Rect client)) return false;
            var sourceOrigin=new Point(0,0);
            if (!ClientToScreen(_flash,ref sourceOrigin)) return false;
            var source=new Rectangle(sourceOrigin,new Size(client.Right,client.Bottom));
            // S is captured and P is independently presented. Cross-DPI child
            // rounding can put F one pixel beyond P while still inside S. P is
            // not the capture boundary: refusing here left an old crop active
            // throughout restore/maximize until a later DRS resize happened.
            // DWM and the Flash child can round their bottom edges one pixel
            // apart after a window move. Capture only the measured intersection;
            // keep rejecting larger misses instead of inventing an origin.
            if (!TryCalculateCrop(source,capture,out Rectangle crop)) return RejectGeometry("source_outside_capture",screen,source,capture);
            if(_lastGeometryRejection!=null) {
                LogManager.Log("event=world_compositor_geometry_resumed FClient="+source+" captureFrame="+capture+" P="+screen);
                _lastGeometryRejection=null;
            }
            if (crop!=_crop || _surface.Bounds!=screen || _viewportHeld) {
                // Keep the previous composed image over the reduced-resolution F.
                // A geometry transition must not expose F while awaiting a fresh frame.
                _requiredFrameMs=_viewportHeld ? Math.Max(_requiredFrameMs,_paintFenceMs) : NowMs();
                _native.Viewport(crop,_requiredFrameMs); _viewportHeld=false;
                _crop=crop; _surface.Bounds=screen; _surface.RefreshPointer();
                LogManager.Log("event=world_compositor_geometry FClient="+source+" captureFrame="+capture+" dwmFrame="+frame.Rectangle+" windowFrame="+window.Rectangle+" WGC="+content+" crop="+crop+" P="+_surface.Bounds+" frameFenceMs="+_requiredFrameMs.ToString("F1",CultureInfo.InvariantCulture));
            }
            return true;
        }
        private void InvalidateWeather()
        {
            _appliedWeatherType=-1;
            _appliedWeatherStyleType=-1;
            _appliedAtmospherePreset=-1;
            _appliedAtmosphereName=null;
            lock (_weatherCameraLock) {
                _weatherCameraDispatchAllowed=false;
                _appliedWeatherCameraX=_appliedWeatherCameraY=_appliedWeatherCameraScale=float.NaN;
            }
        }
        private void ApplyAtmosphere(bool captureReady)
        {
            if (_native==null) return;
            WorldLightingFrame frame=_frame;
            bool show=captureReady && frame?.Ready==true && frame.Atmosphere.Name!="none"
                && _lighting.ReadyScene==frame.Scene && !_lighting.WaitingForCapture;
            string name=show ? frame.Atmosphere.Name : "none";
            int preset=name=="none" ? 0 : name=="custom" ? 11 : _presentationCatalog.Atmosphere(name).Family;
            float[] parameters=show ? frame.Atmosphere.NativeParameters : AtmosphereFrame.None.NativeParameters;
            if (show && preset!=11 && name!=_appliedAtmosphereName) {
                AtmosphereLook look=_presentationCatalog.Atmosphere(name);
                _native.AtmosphereStyle(look.Family,look.Tuning);
            }
            bool changed=preset!=_appliedAtmospherePreset || _appliedAtmosphereParameters==null;
            for (int i=0;!changed && i<parameters.Length;i++)
                changed=parameters[i]!=_appliedAtmosphereParameters[i];
            if (changed) _native.Atmosphere(preset,parameters);
            _appliedAtmospherePreset=preset;
            _appliedAtmosphereParameters=parameters;
            if (!changed && name==_appliedAtmosphereName) return;
            _appliedAtmosphereName=name;
            LogManager.Log("event=world_atmosphere_apply scene="+(frame?.Scene ?? 0)+" preset="+preset
                +" captureReady="+captureReady);
        }
        private void ApplyWeather(bool captureReady)
        {
            if (_native==null) return;
            WorldLightingFrame frame=_frame;
            bool show=captureReady && frame!=null && frame.Ready && frame.WeatherNative
                && _lighting.ReadyScene==frame.Scene && !_lighting.WaitingForCapture;
            int type=show ? frame.WeatherType : 0;
            float intensity=show ? frame.WeatherIntensity : 0;
            // The same Host target owns both Flash and the native weather budget.
            int quality=show ? NativeVisualBudget.FromEffectLevel(_effectLevel).WeatherQuality : 3;
            uint seed=show ? unchecked((uint)frame.Scene) : 0;
            if (show && type!=0 && type!=_appliedWeatherStyleType) {
                WeatherLook look=_presentationCatalog.Weather(type);
                _native.WeatherStyle(look.Type,look.Count,look.Tuning);
                _appliedWeatherStyleType=type;
            }
            if (type==_appliedWeatherType && intensity==_appliedWeatherIntensity
                && quality==_appliedWeatherQuality && seed==_appliedWeatherSeed) return;
            _native.Weather(type,intensity,quality,seed);
            _appliedWeatherType=type; _appliedWeatherIntensity=intensity;
            _appliedWeatherQuality=quality; _appliedWeatherSeed=seed;
            LogManager.Log("event=world_weather_apply scene="+(frame?.Scene ?? 0)+" type="+type
                +" intensity="+intensity.ToString("F2",CultureInfo.InvariantCulture)
                +" quality="+quality+" captureReady="+captureReady
                +" waitingForCapture="+_lighting.WaitingForCapture);
        }
        private void ApplyWeatherCamera(bool captureReady)
        {
            WorldLightingFrame frame=_frame;
            bool allow=_native!=null && captureReady && frame?.Ready==true
                && (frame.WeatherNative || frame.Atmosphere.Name!="none")
                && _lighting.ReadyScene==frame.Scene && !_lighting.WaitingForCapture;
            lock (_weatherCameraLock) {
                _weatherCameraDispatchAllowed=allow;
                if (!allow) return;
                _weatherCameraGroundMin=frame.WeatherGroundMin;
                _weatherCameraGroundMax=frame.WeatherGroundMax;
                PushWeatherCameraLocked();
            }
        }
        // Caller holds _weatherCameraLock. StopCapture takes the same lock before
        // freeing the native session, so the socket callback cannot use a dead handle.
        private void PushWeatherCameraLocked()
        {
            if (_weatherCameraX==_appliedWeatherCameraX && _weatherCameraY==_appliedWeatherCameraY
                && _weatherCameraScale==_appliedWeatherCameraScale
                && _weatherCameraGroundMin==_appliedWeatherGroundMin
                && _weatherCameraGroundMax==_appliedWeatherGroundMax) return;
            _native.WeatherCamera(_weatherCameraX,_weatherCameraY,_weatherCameraScale,
                _weatherCameraGroundMin,_weatherCameraGroundMax);
            _appliedWeatherCameraX=_weatherCameraX; _appliedWeatherCameraY=_weatherCameraY;
            _appliedWeatherCameraScale=_weatherCameraScale;
            _appliedWeatherGroundMin=_weatherCameraGroundMin;
            _appliedWeatherGroundMax=_weatherCameraGroundMax;
        }
        private bool RejectGeometry(string reason,Rectangle output,Rectangle source,Rectangle capture)
        {
            _schedulingAllowed=false;
            string detail="reason="+reason+" FClient="+source+" captureFrame="+capture+" P="+output+" retainedCrop="+_crop;
            if(detail!=_lastGeometryRejection) {
                _lastGeometryRejection=detail;
                LogManager.Log("event=world_compositor_geometry_wait "+detail);
            }
            return false;
        }
        internal static Rectangle CalculateCrop(Rectangle game,Rectangle capturedFrame)
        {
            if (!TryCalculateCrop(game,capturedFrame,out Rectangle crop)) throw new ArgumentException("Game viewport outside capture bounds");
            return crop;
        }
        internal static bool TryCalculateCrop(Rectangle game,Rectangle capturedFrame,out Rectangle crop)
        {
            crop=Rectangle.Empty;
            if (game.Width<1 || game.Height<1 || capturedFrame.Width<1 || capturedFrame.Height<1) return false;
            Rectangle visible=Rectangle.Intersect(game,capturedFrame);
            if (visible.Width<1 || visible.Height<1
                || visible.Left-game.Left>2 || visible.Top-game.Top>2
                || game.Right-visible.Right>2 || game.Bottom-visible.Bottom>2) return false;
            crop=new Rectangle(visible.X-capturedFrame.X,visible.Y-capturedFrame.Y,visible.Width,visible.Height);
            return true;
        }
        private void PlaceBelowHud()
        {
            _overlayOrder?.RestoreNow("world_show");
        }
        internal void RefreshHudPresentations()
        {
            // A viewport handoff retains P and its last composed image. Waiting
            // for a fresh source frame is not loss of the HUD's output endpoint:
            // withdrawing it here briefly re-created three legacy HUD windows.
            // Initial capture, hidden output, session retirement and actual
            // faults still gate ownership; scheduling continues to require ready.
            bool available=!_disposed && !_faulted && _active && _everReady
                && _surface!=null && !_surface.IsDisposed && _surface.Visible;
            Rectangle bounds=available
                ? new Rectangle(_surface.PointToScreen(Point.Empty),_surface.ClientSize)
                : Rectangle.Empty;
            DamagePresentation.Adopt(_damageRasterScene,bounds,available);
            ResourcePresentation.Adopt(_resourceRasterScene,bounds,available);
            BottomPresentation.Adopt(_bottomRasterScene,bounds,available);
            BuffPresentation.Adopt(_buffRasterScene,bounds,available);
            MainHudPresentation.Adopt(_mainHudRasterScene,bounds,available);
        }
        private void OnGeometryChanged(object sender,EventArgs e)
        {
            _schedulingAllowed=false;
            if (_surface==null || _surface.IsDisposed) return;
            if (!CanShow()) { _surface.Hide(); RefreshHudPresentations(); return; }
            Rectangle screen=_anchor.RectangleToScreen(_anchor.ClientRectangle);
            if (screen.Width<1 || screen.Height<1 || _surface.Bounds==screen) return;
            // Windows' modal move loop can delay the render timer. Move P in the
            // geometry callback itself, preserving its last full-size image and
            // HWND. Hiding it here exposed the 67% DRS child and black remainder.
            _surface.CancelPointer("geometry_changed");
            _surface.Bounds=screen;
            // HUD coordinates are output pixels. Follow P immediately even if
            // WGC is still reporting the previous source extent during the move.
            RefreshHudPresentations();
            LogManager.Log("event=world_compositor_follow P="+screen+" visible="+_surface.Visible);
        }
        internal static bool TryResolveCaptureFrame(Rectangle extended,Rectangle window,Size content,out Rectangle frame)
        {
            frame=Rectangle.Empty;
            if(content.Width<=0 || content.Height<=0)return false;
            if(content==extended.Size){frame=extended;return true;}
            if(content==window.Size){frame=window;return true;}
            return false; // transition/unknown geometry: do not invent an origin
        }
        private void OnDpiChanged(object sender,DpiChangedEventArgs e) => OnGeometryChanged(sender,e);
        private void OnClosed(object sender,FormClosedEventArgs e) => Dispose();
        // 宿主失活同样撤销在途指针输入：Host 抬共享代次下界，是投影端 WM_KILLFOCUS
        // 本地下界之外的第二道保险。
        private void OnOwnerDeactivated(object sender,EventArgs e) => _surface?.CancelPointer("owner_deactivate");
        private static double NowMs() => Stopwatch.GetTimestamp()*1000.0/Stopwatch.Frequency;
        internal void ObserveCombatFx(CombatFxDrawFrame frame,float x,float y,float scale)
        {
            bool failed=false;
            lock(_weatherCameraLock) {
                if(!_combatFxCapabilityAdvertised || _native==null) return;
                try {
                    _worldLights.SetCombatFx(frame);
                    SubmitWorldLightsLocked(x,y,scale);
                }
                catch(Exception error) { failed=true;LogManager.Log("event=combat_fx_native_failed "+error.Message); }
            }
            if(failed) RejectCombatFx();
        }
        internal void ClearCombatFx()
        {
            lock(_weatherCameraLock) {
                _worldLights.ClearCombatFx();
                try { SubmitWorldLightsLocked(_lightCameraX,_lightCameraY,_lightCameraScale,immediate:true); }
                catch(Exception error) { LogManager.Log("event=combat_fx_clear_failed "+error.Message); }
            }
        }
        internal void RejectCombatFx() { _combatFxResourcesReady=false;RevokeCombatFx("invalid_or_failed_frame"); }
        internal void CombatFxConnectionLost() => RevokeCombatFx("socket_disconnected");
        private void RevokeCombatFx(string reason)
        {
            bool advertised;
            lock(_weatherCameraLock) { advertised=_combatFxCapabilityAdvertised;_combatFxCapabilityAdvertised=false; }
            ClearCombatFx();
            if(!advertised) return;
            bool sent=false;
            try { sent=CombatFxCapabilityChanged?.Invoke(false)==true; }
            catch(Exception error) { LogManager.Log("event=combat_fx_cap_revoke_failed "+error.Message); }
            LogManager.Log("event=combat_fx_cap_revoke reason="+reason+" sent="+sent);
        }
        private void RejectPlayerHud(string reason,Exception error)
        {
            if(_disposed || _playerHudFaulted)return;
            if(_owner.InvokeRequired) { _owner.BeginInvoke(new Action(()=>RejectPlayerHud(reason,error)));return; }
            _playerHudFaulted=true;
            // Clear every native member before re-enabling legacy windows. A HUD
            // upload fault does not reset its command owner or unknown-write lock.
            try { if(_native!=null)for(int layer=1;layer<=4;layer++)_native.SetHudRaster(layer,IntPtr.Zero,0,0,0,0,0); }
            catch(Exception clearError) { EnterRenderFault("player_hud_retirement_failed",clearError);return; }
            _resourceRasterScene=null;_bottomRasterScene=null;_buffRasterScene=null;_mainHudRasterScene=null;
            ResourcePresentation.Adopt(null,Rectangle.Empty,false);
            BottomPresentation.Adopt(null,Rectangle.Empty,false);
            BuffPresentation.Adopt(null,Rectangle.Empty,false);
            MainHudPresentation.Adopt(null,Rectangle.Empty,false);
            LogManager.Log("event=player_hud_legacy_fallback reason="+reason+" error="+error.GetType().Name);
        }
        private void StopCapture()
        {
            _sentSceneLightVersion=-1;
            // Same-socket source loss must return visual ownership to Flash.
            RevokeBulletCapability("capture_stopped",true);
            RevokeCombatFx("capture_stopped");
            _combatFxResourcesReady=false;_lastCombatFxCapAttemptMs=0;
            _bulletStylesReady=false;
            _lastBulletCapAttemptMs=0;
            _lastBulletFrameLogTicks=0;
            _surface?.Hide();
            _hudCostProfiling=false;_hudCostProfileId=null;
            DamagePresentation.Adopt(null, Rectangle.Empty, false);
            ResourcePresentation.Adopt(null, Rectangle.Empty, false);
            BottomPresentation.Adopt(null, Rectangle.Empty, false);
            BuffPresentation.Adopt(null, Rectangle.Empty, false);
            MainHudPresentation.Adopt(null, Rectangle.Empty, false);
            _damageRasterScene=null;_resourceRasterScene=null;_bottomRasterScene=null;_buffRasterScene=null;_mainHudRasterScene=null;
            if (_weatherCapabilityAdvertised) {
                _weatherCapabilityAdvertised=false;
                try { WeatherCapabilityChanged?.Invoke(false); }
                catch (Exception error) { LogManager.Log("event=world_weather_cap_revoke_failed "+error.Message); }
            }
            _lastWeatherCapAttemptMs=0;
            _lastGeometryRejection=null;
            _lastCaptureGeneration=0;
            _appliedWeatherType=-1; _appliedWeatherIntensity=float.NaN;
            _appliedWeatherQuality=-1; _appliedWeatherSeed=0;
            _appliedWeatherStyleType=-1;
            _appliedAtmospherePreset=-1; _appliedAtmosphereParameters=null;
            _appliedAtmosphereName=null;
            lock (_weatherCameraLock) {
                _weatherCameraDispatchAllowed=false;
                _appliedWeatherCameraX=_appliedWeatherCameraY=_appliedWeatherCameraScale=float.NaN;
                _appliedWeatherGroundMin=_appliedWeatherGroundMax=float.NaN;
                _weatherCameraX=0; _weatherCameraY=0; _weatherCameraScale=1;
                _weatherCameraGroundMin=360; _weatherCameraGroundMax=520;
            }
            _inputRenewRequested=false;_inputClosed=false;
            _viewportHeld=false; _paintFenceMs=0;
            _everReady=false; _frameAdvancing=false; _progressKnown=false;
            _transitionGradeScene=0; _transitionPresentedScene=0; _transitionGradeSubmittedAt=0;
            _transitionPaintRequest=null; _transitionRequestedScene=0;
            _surface?.Hide();
            try { lock (_weatherCameraLock) { _native?.Dispose(); _native=null; } }
            finally {
                _native=null;
                try { _compositionScene?.Dispose(); }
                finally {
                    _compositionScene=null; _compositionSceneCommitted=false; _overlayOrder?.Dispose(); _overlayOrder=null; _surface?.CancelPointer(); _surface?.Dispose(); _surface=null;
                    if(_pointerBridge!=null)_retiringInput=_pointerBridge.CloseAsync(); _pointerBridge=null; _flash=IntPtr.Zero;
                }
            }
        }
        public void Dispose()
        {
            // Owner teardown ends the game/socket lifetime. Attempt one final
            // synchronous revoke; do not create a detached retry worker.
            if (_disposed) return; _disposed=true; _timer.Stop(); StopCapture(); _timer.Dispose();
            DamagePresentation.Dispose();
            ResourcePresentation.Dispose();
            BottomPresentation.Dispose();
            BuffPresentation.Dispose();
            MainHudPresentation.Dispose();
            _owner.LocationChanged-=OnGeometryChanged; _owner.SizeChanged-=OnGeometryChanged;
            _owner.DpiChanged-=OnDpiChanged; _owner.FormClosed-=OnClosed; _owner.Deactivate-=OnOwnerDeactivated;
            _anchor.SizeChanged-=OnGeometryChanged; _anchor.LocationChanged-=OnGeometryChanged;
        }
        [StructLayout(LayoutKind.Sequential)] private struct Rect { public int Left,Top,Right,Bottom; public Rectangle Rectangle=>Rectangle.FromLTRB(Left,Top,Right,Bottom); }
        [DllImport("dwmapi.dll")] private static extern int DwmGetWindowAttribute(IntPtr hwnd,int attribute,out Rect value,int size);
        [DllImport("user32.dll")] private static extern IntPtr GetWindow(IntPtr hwnd,uint command);
        [DllImport("user32.dll")] [return:MarshalAs(UnmanagedType.Bool)] private static extern bool IsWindow(IntPtr hwnd);
        [DllImport("user32.dll")] [return:MarshalAs(UnmanagedType.Bool)] private static extern bool SetWindowPos(IntPtr hwnd,IntPtr after,int x,int y,int w,int h,uint flags);
        [DllImport("user32.dll")] private static extern bool GetClientRect(IntPtr hwnd,out Rect rect);
        [DllImport("user32.dll")] private static extern bool ClientToScreen(IntPtr hwnd,ref Point point);
        [DllImport("user32.dll")] private static extern bool GetWindowRect(IntPtr hwnd,out Rect rect);
    }
}
