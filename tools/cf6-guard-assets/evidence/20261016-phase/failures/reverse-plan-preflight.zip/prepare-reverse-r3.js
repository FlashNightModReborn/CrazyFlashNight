const fs=require('fs'),path=require('path'),crypto=require('crypto');
const {normalizeManifest}=require('../../tools/arena-calibration/lib/arena-calibration-core');
const ROOT=path.resolve(__dirname,'../..'),run=__dirname;
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const previous=read(path.join(run,'dual-worker-r2/experiment-plan.json'));
const identity=read(path.join(run,'dual-worker-r2/input-identity.json'));
const worker=previous.workers[1];
for(const b of identity.sourceBindings) {
 if(hash(path.join(ROOT,b.path))!==b.sha256 || hash(path.join(worker.projectRoot,b.path))!==b.sha256)throw Error('Input drift: '+b.path);
}
const output=path.join(run,'reverse-r3');fs.mkdirSync(output);
const old=read(path.join(run,'dual-worker-r2/worker-2-manifest.json'));
const cases=old.cases.filter(c=>c.authorityContext.transform).map((c,i)=>({...c,
 caseId:'reverse-r3-'+c.authorityContext.candidateSide+'-'+c.blueRoster[0].level,
 timeoutFrames:6000,authorityContext:{...c.authorityContext,revision:'unchanged-three-piercing-reverse-shutdown-recheck'},
 plannerReason:'Repeat only the reverse-faction group after the prior Worker shutdown identity sample was incomplete. Preserve the old failure; do not change runtime, resources or combat behavior.'}));
const manifest=normalizeManifest({batchId:'guard-phase-r3-reverse-20261016',buildCommit:old.buildCommit,
 planner:{name:'cf6-guard-reverse-shutdown-recheck',version:1},repeat:1,timeoutFrames:6000,cases});
const manifestPath=path.join(output,'worker-2-manifest.json');fs.writeFileSync(manifestPath,JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
const plan={...previous,experimentId:'guard-phase-r3-reverse-20261016',workers:[worker],groups:[{
 ...previous.groups[0],groupId:'reverse-recheck',mode:'sequential',condition:'reverse-shutdown-recheck',
 jobs:[{jobId:'guard-reverse-recheck',workerId:worker.workerId,manifestPath,batchTimeoutMs:900000}]}]};
fs.writeFileSync(path.join(output,'experiment-plan.json'),JSON.stringify(plan,null,2)+'\n',{flag:'wx'});
fs.writeFileSync(path.join(output,'input-identity.json'),JSON.stringify({...identity,expectedRows:3,enemyRows:3,friendlyRows:0,
 runtimeIdentities:[identity.runtimeIdentities[1]],roles:['Guard red, friendly soldier with triple HP; separate from one-life baseline'],
 previousUnqualifiedExperiment:'guard-phase-r2-20261016',reason:'Prior reverse Worker had a shutdown process identity observation error; no old receipt is rewritten.'},null,2)+'\n',{flag:'wx'});
console.log(path.join(output,'experiment-plan.json'));
