﻿
// 当 XML 加载完成时触发的函数
// _root.关卡数据缓存 = [];

_root.配置数据为数组 = function(输入){
    // 检查输入是否已经是数组
    if (输入 instanceof Array){
        return 输入;
    }else if (输入 != undefined && 输入 != null){
        // 如果输入不是数组但不为空，则将其作为数组的单个元素返回
        return [输入];
    }else{
        // 对于未定义或空的输入，返回空数组
        return [];
    }
};


_root.解析并设置奖励品配置 = function(奖励品配置:Array)
{// 清空或初始化奖励数组
	var 奖励品 = [];
	for (var i:Number = 0; i < 奖励品配置.length; i++)
	{
		var 奖励:Object = 奖励品配置[i];
		var 奖励名称:String = 奖励.Name;
		var 出现概率:Number = 奖励.AcquisitionProbability;
		var 最大数量:Number = 奖励.QuantityMax;// 将奖励添加到数组中
		奖励品.push([奖励名称, 出现概率, 最大数量]);
	}// 检查奖励品数组是否为空，如果不为空，则返回数组
	if (奖励品.length == 1 and 奖励品[0][0] == undefined)
	{
		return null;
	}
	return 奖励品;
};

_root.解析rogue敌人集合 = function(Unions){
	var Unions = _root.配置数据为数组(Unions.Union);
	var rogue敌人集合表 = [];
	if(!Unions) return null;
	for (var i:Number = 0; i < Unions.length; i++){
		if(Unions[i].Types == undefined){
			实例配置.push(null);
			continue;
		}
		var 敌人集合 = {
			权重: Number(Unions[i].Weight), 
			唯一性: Unions[i].Unique ? true : false, 
			类型表: _root.配置数据为数组(Unions[i].Types.Type)
		};
		rogue敌人集合表.push(敌人集合);
	}
	return rogue敌人集合表;
}


// 解析并设置对话配置
_root.解析并设置对话配置 = function(关卡数据:Array)
{
	var 对话配置 = [];
	for (var i:Number = 0; i < 关卡数据.length; i++)
	{
		var 对话条数 = 0;
		var 对话数据 = [];
		var 对话列表 = _root.配置数据为数组(关卡数据[i].Dialogue.SubDialogue);
		var 单次对话 = _root.解析单次对话(对话列表);
		if(单次对话){
			对话条数 += 1;
		}
		对话数据.push(单次对话);
		var 波次列表 = _root.配置数据为数组(关卡数据[i].Wave.SubWave)
		for(var j:Number = 0; j < 波次列表.length; j++){
			对话列表 = _root.配置数据为数组(波次列表[j].Dialogue.SubDialogue);
			单次对话 = _root.解析单次对话(对话列表);
			if(单次对话){
				对话条数 += 1;
			}
			对话数据.push(单次对话);
		}
		if(对话条数 == 0){
			对话配置.push(null);
		}else{
			对话配置.push(对话数据);
		}
	}
	return 对话配置;
};
_root.解析单次对话 = function(对话列表:Array){
	var len = 对话列表.length;
	var 输出对话 = new Array(len);
	for(var i:Number = 0; i < len; i++){
		var 对话 = 对话列表[i];
		if (!对话){
			return null;
		}
		var 对话对象 = _root.解析敌人属性(对话);
		输出对话[i] = {name:对话.Name, title:对话.Title, char:对话.Char, text:对话.Text, target:对话对象, imageurl:对话.ImageUrl};
	}
	return 输出对话;
}

_root.载入关卡数据 = function(stageType, url, onLoaded, onLoadError,
		stageStartToken, allowCalibrationHost){
	var loader;
	var settled:Boolean = false;
	var failOnce:Function = function(reason:String):Void {
		if (settled) return;
		settled = true;
		if (stageStartToken != undefined && stageStartToken != "") {
			try {
				var preparedManager:org.flashNight.arki.scene.StageManager =
					org.flashNight.arki.scene.StageManager.instance;
				if (preparedManager != null) {
					preparedManager.abortPreparedStage(String(stageStartToken));
				}
			} catch (preparedAbortError) {
				trace("[StageXMLLoaderRoot] prepared manager abort failed: "
					+ preparedAbortError);
			}
			try {
				org.flashNight.arki.scene.StageRunSession.cancelStageStart(
					String(stageStartToken));
			} catch (reservationCancelError) {
				trace("[StageXMLLoaderRoot] reservation cancel failed: "
					+ reservationCancelError);
			}
		}
		try {
			_root.发布调试消息(reason + " " + stageType + "  " + url);
		} catch (debugMessageError) {
			trace("[StageXMLLoaderRoot] debug projection failed: " + debugMessageError);
		}
		try {
			if (typeof onLoadError == "function") onLoadError();
			else if (typeof onError == "function") onError();
		} catch (failureCallbackError) {
			trace("[StageXMLLoaderRoot] failure callback threw: " + failureCallbackError);
		}
	};
	try {
		loader = new org.flashNight.gesh.xml.LoadXml.BaseStageXMLLoader(url);
		loader.load(function(data:Object):Void {
			if (settled) return;
			if (stageStartToken != undefined && stageStartToken != ""
					&& !org.flashNight.arki.scene.StageRunSession.isStageStartReservationValid(
						String(stageStartToken))) {
				failOnce("ignore stale stage xml");
				return;
			}

			// 先完成全部纯解析与 StageManager/TimePool 验证。在此之前不允许
			// 覆盖当前关卡奖励或掉落索引，避免 invalid TimePool 污染旧场景。
			var 奖励品配置:Array;
			var 解析后奖励:Array;
			var 掉落关卡名:String = "";
			try {
				奖励品配置 = _root.配置数据为数组(
					data != null && data.Rewards != null ? data.Rewards.Reward : undefined);
				解析后奖励 = 奖励品配置[0] != null
					? _root.解析并设置奖励品配置(奖励品配置) : [];
				var urlParts:Array = String(url).split("/");
				var fileName:String = urlParts[urlParts.length - 1];
				掉落关卡名 = fileName.substr(0, fileName.lastIndexOf("."));
			} catch (奖励解析错误) {
				failOnce("invalid stage rewards");
				return;
			}

			if(stageType == "无限过图"){
				var stageManager:org.flashNight.arki.scene.StageManager;
				var managerInitialized:Boolean = false;
				try {
					stageManager = org.flashNight.arki.scene.StageManager.getInstance();
					if (stageManager == null) throw new Error("StageManager unavailable");
					var timePoolData = data.TimePools == null
						? null : data.TimePools.TimePool;
					managerInitialized = stageManager.initialize(
						data.SubStage, timePoolData, stageStartToken,
						allowCalibrationHost === true, 解析后奖励,
						掉落关卡名, 奖励品配置);
				} catch (managerInitializeError) {
					trace("[StageXMLLoaderRoot] manager initialize threw: "
						+ managerInitializeError);
					failOnce("stage manager initialization failed");
					return;
				}
				if (!managerInitialized) {
					try {
						_root.发布调试消息("invalid stage time pools: "
							+ stageManager.getTimePoolValidationError());
					} catch (invalidDebugError) {
						trace("[StageXMLLoaderRoot] invalid-config debug projection failed: "
							+ invalidDebugError);
					}
					failOnce("invalid stage time pools");
					return;
				}
			}

			// 无限过图的 StageManager 仍只处于 exact preload：奖励/掉落随 manager
			// 保留到首个 gameplay init，final gate/fade 失败时 abort 直接丢弃。
			// 无 StageManager 的旧 stage type 维持同步提交契约。
			if (stageType != "无限过图") {
				try {
					_root.关卡可获得奖励品 = 解析后奖励;
					if (掉落关卡名 != "" && 奖励品配置.length > 0
							&& 奖励品配置[0] != null) {
						org.flashNight.arki.item.obtain.ItemObtainIndex.getInstance()
							.updateStageDrops(掉落关卡名, 奖励品配置);
					}
				} catch (缓存提交错误) {
					failOnce("stage cache commit failed");
					return;
				}
			}

			settled = true;
			try {
				_root.发布调试消息("load xml " + stageType + "  " + url);
			} catch (successDebugError) {
				trace("[StageXMLLoaderRoot] success debug projection failed: "
					+ successDebugError);
			}
			try {
				if (typeof onLoaded == "function") onLoaded(data);
			} catch (successCallbackError) {
				// manager 与 exact reservation 已成功准备；callback transport/投影失败
				// 不得反向取消已提交 preload，也不得让底层重复终止。
				trace("[StageXMLLoaderRoot] success callback threw: "
					+ successCallbackError);
			}
		}, function():Void {
			failOnce("fail to load xml");
		});
	} catch (启动载入错误) {
		failOnce("stage loader threw");
	}
};

_root.配置外交地图关卡信息 = function(对象, StageInfo){
	_root.配置基础关卡信息(对象,StageInfo);
	对象.root场景进入位置名 = StageInfo.Address;
	对象.淡出动画淡出跳转帧 = StageInfo.RootFadeTransitionFrame;
	对象.onPress = function(){
		if (!org.flashNight.arki.scene.StageRunSession.canNavigateAwayFromStage()) return false;
		_root.场景进入位置名 = 对象.root场景进入位置名;
		_root.淡出动画.淡出跳转帧(对象.淡出动画淡出跳转帧);
		return true;
	};
};

_root.配置基础关卡信息 = function(对象, StageInfo){
	对象.关卡路径 = StageInfo.url;
	对象.当前关卡名 = StageInfo.Name;
	对象.淡出跳转帧 = StageInfo.FadeTransitionFrame;
	对象.关卡开放条件 = StageInfo.UnlockCondition;
	对象.详细 = StageInfo.Description;
	对象.材料详细 = StageInfo.MaterialDetail;
	对象.起点帧 = StageInfo.StartFrame ? StageInfo.StartFrame : null;
	对象.终点帧 = StageInfo.EndFrame ? StageInfo.EndFrame : null;
	对象.限制词条 = StageInfo.Limitation ? _root.配置数据为数组(StageInfo.Limitation) : null;
	对象.限制难度等级 = StageInfo.LimitLevel ? StageInfo.LimitLevel : null;
};




_root.配置关卡属性 = function(StageName:String):Void {
	var 关卡引用:Object = this;
	var StageInfo:Object = _root.StageInfoDict[StageName];
	this.关卡类型 = StageInfo.Type;
	switch (this.关卡类型){
		case "无限过图" :
		case "初期关卡" :
			_root.配置基础关卡信息(关卡引用,StageInfo);
			break;
		case "外交地图" :
			if(!_root.isStageUnlocked(StageName)){
				this._visible = false;
			}else{
				_root.配置外交地图关卡信息(关卡引用,StageInfo);//外交地图数据配置
			}
			break;
	}/// 配置缓存数据
	// _root.配置关卡缓存数据(关卡引用,xml文件地址);
	//硬代码删除未xml化副本的起始帧变量
	delete this.NPC任务_任务_起始帧;
};// 使用函数

_root.加载随机名称库 = function(xml文件地址:String):Void 
{
	var 名称库XML:XML = new XML();
	名称库XML.ignoreWhite = true;
	名称库XML.onLoad = function(加载成功:Boolean)
	{
		if (加载成功)
		{
			var 名称节点数组:Array = this.firstChild.childNodes;
			var len = 名称节点数组.length;
			var 随机名称库 = new Array(len);
			for (var i:Number = 0; i < len; i++)
			{
				if (名称节点数组[i].nodeName == "Name")
				{
					随机名称库[i] = 名称节点数组[i].firstChild.nodeValue;
				}
			}
			_root.随机名称库 = 随机名称库;
			//trace("随机名称库加载成功: " + _root.随机名称库);
			//_root.服务器.发布服务器消息("随机名称库加载成功");
		}
		else
		{
			//_root.服务器.发布服务器消息("无法加载 XML 文件: " + xml文件地址);
		}
	};// 加载 XML 文件
	名称库XML.load(xml文件地址);
};

_root.加载并配置战队信息 = function(xml文件地址:String):Void 
{
	var 战队信息XML:XML = new XML();
	战队信息XML.ignoreWhite = true;
	战队信息XML.onLoad = function(加载成功:Boolean)
	{
		if (加载成功)
		{
			_root.战队信息数组 = [];
			var teamNodes:Array = this.firstChild.childNodes;
			for (var i:Number = 0; i < teamNodes.length; i++)
			{
				var team:Object = {};
				var childNodes:Array = teamNodes[i].childNodes;
				for (var j:Number = 0; j < childNodes.length; j++)
				{
					var nodeName:String = childNodes[j].nodeName;
					var nodeValue:String = childNodes[j].firstChild.nodeValue;
					switch (nodeName)
					{
						case "Title" :
							team.战队抬头 = nodeValue;
							break;
						case "Name" :
							team.战队名 = nodeValue;
							break;
						case "Weight" :
							team.权重 = parseInt(nodeValue);
							break;
						case "Necklace" :
							team.战队项链 = nodeValue;
							break;
					}
				}
				_root.战队信息数组.push(team);
			}//trace("战队信息加载成功: " + _root.战队信息数组);
		}
		else
		{//trace("无法加载 XML 文件: " + xml文件地址);
		}
	};// 加载 XML 文件
	战队信息XML.load(xml文件地址);
};

_root.加载并配置佣兵随机对话 = function(xml文件地址:String):Void 
{
	var 随机对话XML:XML = new XML();
	随机对话XML.ignoreWhite = true;
	随机对话XML.onLoad = function(加载成功:Boolean)
	{
		if (加载成功)
		{
			var dialogueNodes:Array = this.firstChild.childNodes;
			var len = dialogueNodes.length;
			_root.佣兵随机对话 = new Array(len);
			for (var i:Number = 0; i < len; i++)
			{
				var dialogue:Object = {};
				var childNodes:Array = dialogueNodes[i].childNodes;
				for (var j:Number = 0; j < childNodes.length; j++)
				{
					var nodeName:String = childNodes[j].nodeName;
					var nodeValue:String = childNodes[j].firstChild.nodeValue;
					dialogue[nodeName] = nodeValue;// 映射标签名和其对应的内容

				}
				_root.佣兵随机对话[i] = dialogue;
			}
			// ── Phase 2: 按 Personality 分池 ──
			_root.佣兵对话池 = {};
			for (var k:Number = 0; k < len; k++) {
				var d:Object = _root.佣兵随机对话[k];
				var pKey:String = d.Personality;
				if (_root.佣兵对话池[pKey] == null) {
					_root.佣兵对话池[pKey] = [];
				}
				_root.佣兵对话池[pKey].push(d);
			}
		}
		else
		{//trace("无法加载 XML 文件: " + xml文件地址);
		}
	};// 加载 XML 文件
	随机对话XML.load(xml文件地址);
};

// [Phase 3 DEPRECATED] Legacy 非人形佣兵对话加载。数据由 Launcher enemy_dialogues 查询提供。
_root.加载并配置非人形佣兵随机对话 = function(xml文件地址:String):Void {
	trace("[DEPRECATED] 加载并配置非人形佣兵随机对话 called — no-op");
};

_root.加载并配置NPC对话 = function(xml文件地址:String):Void 
{
	var 对话XML:XML = new XML();
	对话XML.ignoreWhite = true;
	对话XML.onLoad = function(加载成功:Boolean){
		if (加载成功){
			var NPC对话 = {};
			var NPC对话数据 = _root.解析XML节点(this.firstChild);
			var dialogueNodes:Array = NPC对话数据.Dialogues;
			for (var i:Number = 0; i < dialogueNodes.length; i++){
				var NPC名称 = dialogueNodes[i].Name;
				NPC对话[NPC名称] = [];
				var NPC_Dialogue = _root.配置数据为数组(dialogueNodes[i].Dialogue);
				for (var j:Number = 0; j < NPC_Dialogue.length; j++){
					var 对话obj = {};
					var 对话列表 = _root.配置数据为数组(NPC_Dialogue[j].SubDialogue);
					对话obj.TaskRequirement = !isNaN(TaskRequirement) ? Number(NPC_Dialogue[j].TaskRequirement) : 0;
					对话obj.Dialogue = _root.解析单次对话(对话列表);
					NPC对话[NPC名称].push(对话obj);
				}
			}
			_root.NPC对话 = NPC对话;
		}else{
			//_root.服务器.发布服务器消息("无法加载 XML 文件: " + xml文件地址);
		}
	};
	对话XML.load(xml文件地址);
};

_root.读取NPC对话 = function(NPC名称:String){
	// 保护：对话数据未加载时返回 null
	if (_root.NPC对话 == null || _root.NPC对话 == undefined) {
		return null;
	}
	var 总对话 = _root.NPC对话[NPC名称];

	// _root.发布消息("读取NPC对话: " + NPC名称 + " 对话数量: " + (总对话 ? 总对话.length : 0));
	if(!总对话 || !总对话.length){
		return null;
	}
	var 输出对话 = [];
	for (var i:Number = 0; i < 总对话.length; i++){
		if(总对话[i].TaskRequirement > _root.主线任务进度){
			continue;
		}
		输出对话.push(总对话[i].Dialogue);
	}

	// _root.发布消息("过滤后NPC对话数量: " + 输出对话.length);
	return 输出对话;
};

_root.读取并组装NPC对话 = function(NPC名称:String){
	var 总对话 = _root.读取NPC对话(NPC名称);
	// 保护：对话为空时返回空数组
	if (总对话 == null || 总对话 == undefined) {
		return [];
	}
	var 输出对话 = new Array(总对话.length);
	for(var i:Number = 0; i < 总对话.length; i++){
		输出对话[i] = _root.组装单次对话(总对话[i]);
	}

	// _root.发布消息(NPC名称, "组装后NPC对话数量: " + 输出对话.length);
	return 输出对话;
}

//=============================================================================
// [Phase 3 DEPRECATED] NPC对话生命周期管理 API — 已移除
// NPC对话现在通过 Launcher npc_dialogue 查询按需获取，存储在 MC 上，随 MC 销毁。
// 以下函数保留为无操作存根，防止残留调用导致运行时错误。
//=============================================================================

_root.NPC对话_状态 = "unloaded";
_root.NPC对话_回调队列 = [];
_root.NPC对话_待绑定列表 = [];
_root.NPC对话_加载令牌 = 0;
_root.NPC对话_ensureLoaded = function(onOk:Function, onErr:Function):Void {
	trace("[DEPRECATED] NPC对话_ensureLoaded called — no-op");
};
_root.NPC对话_执行回调队列 = function(success:Boolean):Void {};
_root.NPC对话_unload = function(reason:String):Void {};
_root.NPC对话_isLoaded = function():Boolean { return false; };
_root.NPC对话_注册待绑定 = function(npc:MovieClip, npcName:String):Void {};
_root.NPC对话_补齐待绑定 = function():Void {};
_root.NPC对话_countKeys = function(obj:Object):Number { return 0; };

//=============================================================================
// [Phase 3 DEPRECATED] 佣兵配置数据生命周期管理 API — 已移除
// 佣兵配置数据现在通过 Launcher merc_bundle 查询按需获取，生成完成后由 cleanup 释放。
// 以下函数保留为无操作存根。
//=============================================================================

_root.佣兵配置_状态 = "unloaded";
_root.佣兵配置_回调队列 = [];
_root.佣兵配置_加载令牌 = 0;
_root.佣兵配置_加载计数 = 0;
_root.佣兵配置_ensureLoaded = function(onOk:Function, onErr:Function):Void {
	trace("[DEPRECATED] 佣兵配置_ensureLoaded called — no-op");
};
_root.佣兵配置_执行回调队列 = function(success:Boolean):Void {};
_root.佣兵配置_unload = function(reason:String):Void {};
_root.佣兵配置_isLoaded = function():Boolean { return false; };
_root.佣兵配置_isDataValid = function():Boolean { return false; };
_root.佣兵配置_加载战队信息 = function():Void {};
_root.佣兵配置_加载随机名称库 = function():Void {};
_root.佣兵配置_加载随机对话 = function():Void {};

_root.加载并配置发型库 = function(xml文件地址:String):Void 
{
	var 发型:XML = new XML();
	发型.ignoreWhite = true;
	发型.onLoad = function(加载成功:Boolean){
		if (加载成功){
			var hairstyle = _root.解析XML节点(this.firstChild)
			var hairNodes:Array = hairstyle.Hair;
			var len = hairNodes.length;
			var 发型库 = new Array(len);
			var 发型名称库 = new Array(len);
			var 发型价格 = new Array(len);
			for(var i:Number = 0; i < len; i++){
				发型库[i] = hairNodes[i].Identifier ? hairNodes[i].Identifier : "";
				发型名称库[i] = hairNodes[i].Name ? hairNodes[i].Name : "";
				发型价格[i] = isNaN(hairNodes[i].Price) ? 0 : Number(hairNodes[i].Price);
			}
			_root.发型库 = 发型库;
			_root.发型名称库 = 发型名称库;
			_root.发型价格 = 发型价格;
		}else{
			//_root.服务器.发布服务器消息("无法加载 XML 文件: " + xml文件地址);
		}
	};
	发型.load(xml文件地址);
};

_root.配置关卡环境数据 = function(data:Object):Void {
	var envConfig:EnvironmentConfig = WeatherSystem.getInstance().getEnvConfig();
	var 关卡环境设置 = {};
	var environmentNodes:Array = data.Environment;
	// 默认配置
	var 默认配置 = envConfig.getDefaultEnvConfig();
	关卡环境设置.Default = 默认配置;//把默认配置也存入环境设置
	for (var i:Number = 0; i < environmentNodes.length; i++){
		var 环境信息:Object = {};
		var child_Nodes:Array = environmentNodes[i];
		if(!child_Nodes.BackgroundURL) continue;

		关卡环境设置[child_Nodes.BackgroundURL] = EnvironmentConfig.parseEnvironmentInfo(child_Nodes, 默认配置);
	}
	envConfig.setStageEnvSettings(关卡环境设置);
};

_root.配置场景环境数据 = function(data:Object):Void {
	var envConfig:EnvironmentConfig = WeatherSystem.getInstance().getEnvConfig();
	var 场景环境设置 = {};
	var environmentNodes:Array = data.Environment;
	// 默认配置
	var 默认配置 = envConfig.getDefaultEnvConfig();
	场景环境设置.Default = 默认配置;//把默认配置也存入环境设置
	for (var i:Number = 0; i < environmentNodes.length; i++){
		var 环境信息:Object = {};
		var child_Nodes:Array = environmentNodes[i];
		if(!child_Nodes.BackgroundURL) continue;

		场景环境设置[child_Nodes.BackgroundURL] = EnvironmentConfig.parseEnvironmentInfo(child_Nodes, 默认配置);
	}
	envConfig.setSceneEnvSettings(场景环境设置);
};


// _root.解析背景元素 已迁移至 EnvironmentConfig.parseBackgroundElements


_root.色彩引擎 = {};
_root.色彩引擎.加载并配置色彩预设 = function(xml文件地址:String):Void 
{
    var colorEngineXML:XML = new XML();
    colorEngineXML.ignoreWhite = true; // 忽略空白字符

    colorEngineXML.onLoad = function(success:Boolean)
	{
		if (success) 
		{
            _root.色彩引擎.光照等级映射表 = {};
            _root.色彩引擎.视觉增强映射表 = {};
            var presetSets:Array = _root.解析XML节点(this.firstChild);
			var presetsData:Object = presetSets.PresetSet;

			for(var i = 0; i < presetsData.length; ++i)
			{
				var presets:Object = presetsData[i];
				var name:String = presets.name;
                if (presets.VisionEffects != undefined) {
                    _root.色彩引擎.视觉增强映射表[name] = presets.VisionEffects;
                }
				var presetLevels = presets.Preset;
				var tempPreset:Object = {};
				for(var j:Number = 0; j < presetLevels.length; ++j)
				{
					var preset:Object = presetLevels[j];
					//_root.服务器.发布服务器消息("单位获取成功: " + _root.常用工具函数.对象转JSON(preset, true));
					var presetLevel:Number = Number(preset.level); // 将级别转为数字，用作数组索引
					tempPreset[presetLevel] = {
					亮度: preset.Brightness != undefined ? Number(preset.Brightness) : 0,
					对比度: preset.Contrast != undefined ? Number(preset.Contrast) : 0,
					饱和度: preset.Saturation != undefined ? Number(preset.Saturation) : 0,
					色相: preset.Hue != undefined ? Number(preset.Hue) : 0,
					红色乘数: preset.redMultiplier != undefined ? Number(preset.redMultiplier) : 1,
					绿色乘数: preset.greenMultiplier != undefined ? Number(preset.greenMultiplier) : 1,
					蓝色乘数: preset.blueMultiplier != undefined ? Number(preset.blueMultiplier) : 1,
					透明乘数: preset.alphaMultiplier != undefined ? Number(preset.alphaMultiplier) : 1,
					红色偏移: preset.redOffset != undefined ? Number(preset.redOffset) : 0,
					绿色偏移: preset.greenOffset != undefined ? Number(preset.greenOffset) : 0,
					蓝色偏移: preset.blueOffset != undefined ? Number(preset.blueOffset) : 0,
					透明偏移: preset.alphaOffset != undefined ? Number(preset.alphaOffset) : 0
				};
				}
				_root.色彩引擎.光照等级映射表[name] = tempPreset;
				
			}
            _root.服务器.发布服务器消息("色彩预设表已成功加载并配置。");
        } 
		else 
		{
            _root.服务器.发布服务器消息("无法加载XML文件: " + xml文件地址);
        }
    };
	
    colorEngineXML.load(xml文件地址);
};

_root.加载并配置宠物信息 = function(xml文件地址:String):Void 
{
	var 宠物XML:XML = new XML();
	宠物XML.ignoreWhite = true;
	宠物XML.onLoad = function(加载成功:Boolean){
		if (加载成功){
			var 宠物数据 = _root.解析XML节点(this.firstChild);
			_root.宠物库 = 宠物数据.Pet;
			// 商城分类网格（<PetStore>）不再在 AS2 解析/常驻：已下沉 C# PetTask.adopt_list（web 直连读 pets.xml）。
			// 见 docs/战宠pets.xml-AS2去常驻化-bundle迁移方案-2026-06-02.md（Phase 1）。
			// 注：_root.宠物库（<Pet>）仍保留——战斗出战/刷怪/升级 + snapshot.petLib 需要；Phase 2 再下沉。

		}else{
			//_root.服务器.发布服务器消息("无法加载 XML 文件: " + xml文件地址);
		}
	};
	宠物XML.load(xml文件地址);
};



_root.加载过场背景与文本 = function(xml文件地址:String):Void 
{
	var 背景XML:XML = new XML();
	背景XML.ignoreWhite = true;
	背景XML.onLoad = function(加载成功:Boolean){
		if (加载成功){
			var 加载背景列表 = new Object();
			var loading = _root.解析XML节点(this.firstChild);
			加载背景列表.基地背景 = loading.BaseImage.Image;
			加载背景列表.关卡背景 = loading.StageImage.Image;
			加载背景列表.本次背景 = null;
			_root.加载背景列表 = 加载背景列表;
			_root.提示文本列表 = loading.LoadingText.Group;
		}else{
			//_root.服务器.发布服务器消息("无法加载 XML 文件: " + xml文件地址);
		}
	};
	背景XML.load(xml文件地址);
};


// 解析 XML 节点
_root.处理带HTML标签的文本 = function(节点:XMLNode):String 
{// 这里假设传入的节点是包含HTML标签的文本节点的父节点
	// 检查节点是否有子节点
	if (!节点.hasChildNodes()){
		return "";
	}
	// 获取节点的内部XML字符串                                                                                                         
	var 节点内部XML:String = 节点.toString();// 移除节点标签，只保留内部的文本内容
	var 开始标签结束位置:Number = 节点内部XML.indexOf(">");
	var 结束标签开始位置:Number = 节点内部XML.lastIndexOf("<");
	var 内部文本:String = 节点内部XML.substring(开始标签结束位置 + 1, 结束标签开始位置);
	return 内部文本;
};
_root.解析XML节点 = function(节点:XMLNode):Object 
{// 如果节点是文本节点，直接返回其值
	if (节点.nodeType == 3)
	{
		return _root.转换数据类型(节点.nodeValue);
	}
	// 对象用于存储节点数据                                                                                                      
	var 解析结果:Object = {};// 遍历所有子节点
	for (var i = 0; i < 节点.childNodes.length; i++)
	{
		var 子节点:XMLNode = 节点.childNodes[i];
		var 节点名:String = 子节点.nodeName;
		// 检查是否有子节点                                                                                                      
		if (子节点.hasChildNodes())
		{
			var 子节点值:Object;
			if (子节点.childNodes.length == 1 && 子节点.firstChild.nodeType == 3)
			{
				子节点值 = _root.转换数据类型(子节点.firstChild.nodeValue);
			}
			else
			{// 递归解析子节点
				子节点值 = _root.解析XML节点(子节点);
			}// 检查是否已经存在同名节点
			if (解析结果[节点名] !== undefined)
			{// 如果已经有同名节点，则转换为数组
				if (!(解析结果[节点名] instanceof Array))
				{
					解析结果[节点名] = [解析结果[节点名]];
				}
				解析结果[节点名].push(子节点值);
			}
			else
			{
				解析结果[节点名] = 子节点值;
			}
		}
	}
	return 解析结果;
};// 将字符串转换为适当的数据类型
_root.转换数据类型 = function(value:String):Object 
{
	if (!isNaN(Number(value))){
		return Number(value);
	} else if (value.toLowerCase() == "true"){
		return true;
	} else if (value.toLowerCase() == "false"){
		return false;
	}
	return value;
};//_root.配置关卡属性("test.xml");
