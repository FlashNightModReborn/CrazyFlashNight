﻿/**
 * 物品图标注释主入口函数
 * @param name:String 物品名称
 * @param value:Object 物品数值对象，包含level、tier等属性
 * @param ownerClip:MovieClip 可选，真实 owner/图标剪辑；有效时原生注释携带 _root 系 anchorRect
 */
_root.物品图标注释 = function(name, value, baseItem, ownerClip) {
    var 强化等级:Number = (value.level > 0) ? value.level : 1;

    // 始终使用基础数据来生成简介内容（以正确显示属性增益）
    var itemData:Object = ItemUtil.getItemData(name);
    if(typeof baseItem !== "object") baseItem = null;

    // 1) 基础段描述（不含简介头与装备属性）
    var 描述文本:String = TooltipComposer.generateItemDescriptionText(itemData, baseItem);

    // 2) 简介面板文本（简介头 + 装备段）
    var 简介文本:String = TooltipComposer.generateIntroPanelContent(baseItem, itemData, value);

    // _root.服务器.发布服务器消息("描述文本:" + StringUtils.htmlToPlainTextFast(描述文本));
    // _root.服务器.发布服务器消息("简介文本:" + StringUtils.htmlToPlainTextFast(简介文本));

    // 3) 获取用于图标显示的数据（如果 baseItem 存在且是装备物品，使用 getData() 以应用涂装覆盖）
    var iconData:Object = null;
    if(baseItem && baseItem.getData != undefined && ItemUtil.isEquipment(name)){
        iconData = baseItem.getData();
    }

    // 4) 原生注释出口：document 经 native_interaction 下发；通道不可用时回退旧 Flash 渲染
    var doc:Object = NativeTooltipDocument.buildItem(name, itemData, iconData, 简介文本, 描述文本);
    if (NativeTooltipBridge.show(doc, ownerClip) == null) {
        TooltipComposer.renderItemTooltipSmart(name, value, 描述文本, 简介文本, null, iconData);
    }
};


/**
 * 技能栏技能图标注释（智能分栏版）
 * @param 对应数组号:Number 技能在主角技能表中的数组索引
 *
 * 布局策略：
 * - 简介面板：技能名、类型、状态、冷却、消耗、等级等基础信息
 * - 描述文本：技能的详细描述（Description），独立显示
 * - 根据内容长度自动选择单栏或双栏布局
 */
_root.技能栏技能图标注释 = function(对应数组号) {
    var parts:Object = SkillTooltipComposer.describeLoadout(对应数组号);
    if (NativeTooltipBridge.show(parts.document) == null) {
        SkillTooltipComposer.renderSkillTooltipSmart(parts.name, parts.intro, parts.description);
    }
};

/**
 * 学习界面技能图标注释（智能分栏版）
 * @param 对应数组号:Number 技能在技能表中的数组索引
 *
 * 布局策略：
 * - 简介面板：技能名、类型、等级限制、技能点需求、冷却、消耗等基础信息
 * - 描述文本：技能的详细描述（Description），独立显示
 * - 根据内容长度自动选择单栏或双栏布局
 */
_root.学习界面技能图标注释 = function(对应数组号) {
    var 技能信息 = _root.技能表[对应数组号];
    var 技能名 = 技能信息.Name;

    // 简介面板文本（基础信息）
    var 简介文本 = "<B>" + 技能名 + "</B>";
    简介文本 += "<BR>" + 技能信息.Type;
    简介文本 += "<BR>最高等级：" + 技能信息.MaxLevel;
    简介文本 += "<BR>解锁需要技能点数：" + 技能信息.UnlockSP;
    if (技能信息.MaxLevel > 1)
        简介文本 += "<BR>升级需要技能点数：" + 技能信息.UpgradeSP;
    简介文本 += "<BR>冷却秒数：" + Math.floor(技能信息.CD / 100) / 10;
    简介文本 += "<BR>MP消耗：" + 技能信息.MP;
    简介文本 += "<BR>等级限制：" + 技能信息.UnlockLevel;

    // 描述文本（独立出来，用于智能分栏）
    var 描述文本 = 技能信息.Description ? String(技能信息.Description) : "";

    // 原生注释出口：document 经 native_interaction 下发；通道不可用时回退旧 Flash 渲染
    var 学习文档:Object = NativeTooltipDocument.buildSkill(技能名, 简介文本, 描述文本);
    if (NativeTooltipBridge.show(学习文档) == null) {
        SkillTooltipComposer.renderSkillTooltipSmart(技能名, 简介文本, 描述文本);
    }
};


/**
 * 注释显示函数 (兼容接口，优先经 native_interaction 下发；通道不可用时转发到 TooltipLayout.showTooltip)
 * @param 宽度:Number 注释框宽度（旧布局参考值，原生路径不以此为布局依据）
 * @param 内容:String 注释内容HTML文本
 * @param 框体:String 框体类型（可选，默认为主框体）
 */
_root.注释 = function(宽度, 内容, 框体) {
    var doc:Object = NativeTooltipDocument.buildBody(
        (内容 == undefined || 内容 == null) ? "" : String(内容),
        NativeTooltipDocument.PROFILE_SIMPLE);
    if (NativeTooltipBridge.show(doc) == null) {
        TooltipLayout.showTooltip(宽度, 内容, 框体);
    }
};

/**
 * Web 面板物品注释 HTML 构造（无渲染版本，对应 _root.物品图标注释 的纯数据双胞胎）
 *
 * - 与 物品图标注释 共用同一条 TooltipComposer 调用链，仅区别在不调 renderItemTooltipSmart，
 *   返回 desc/intro 字符串供 Web/JSON 通道下发。
 * - wire 出口统一由消费方 sendResponse 的 LiteJSON.stringifySafe 做标准转义；
 *   这里保留 TooltipComposer 原始 htmlText（含双引号属性），不再做引号替换。
 * - 各 panel 的 *_WebView.as 只需做：参数解析 → 调用本函数 → 按自身 task 名包成 response → sendResponse。
 *
 * @param name:String 物品名（缺省时返回 null）
 * @return Object | null  形如 { descHTML, introHTML, displayname, itemData, document }；item 找不到返回 null
 */
_root.Web物品注释HTML = function(name:String):Object {
    if (name == undefined || name == null || name == "") return null;
    var itemData:Object = ItemUtil.getItemData(name);
    if (itemData == undefined) return null;

    // value 对象：Web 入口当前没有强化等级 / 涂装上下文，统一以 level=1 走基础数据
    var value:Object = { level: 1 };
    var descHTML:String = TooltipComposer.generateItemDescriptionText(itemData, null);
    var introHTML:String = TooltipComposer.generateIntroPanelContent(null, itemData, value);

    return {
        descHTML: descHTML,
        introHTML: introHTML,
        displayname: String(itemData.displayname || name),
        itemData: itemData,
        // COMMON v1 语义文档（纯数据字段，消费方需先经白名单协调再接入 wire）
        document: NativeTooltipDocument.buildItem(name, itemData, null, introHTML, descHTML)
    };
};

/**
 * 注释结束函数 (兼容接口，先按身份下发 native hide，再清旧 Flash 注释兜底)
 */
_root.注释结束 = function() {
    NativeTooltipBridge.hideCurrent();
    TooltipLayout.hideTooltip();
};


