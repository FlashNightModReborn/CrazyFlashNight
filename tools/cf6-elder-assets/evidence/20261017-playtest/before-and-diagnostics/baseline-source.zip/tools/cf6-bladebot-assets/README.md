# CF6 大刀机器人装配与波光束联动

大刀机器人使用独立原生库 `Codex大刀机器人素材`，兵种 **465**，链接 `敌人-CF6大刀机器人`。阶段 **8**、档次系数 **9** 固定；本轮按用户新要求接回原 906 光束，形成重劈击退后接波属性激光的联动。属性归入 `data/enemy_properties/CF6重制敌人.xml`。改动暂缓提交，等待用户验收。

## 真源与加载

- 原交接包：`05-source.zip`，SHA-256 `a689834247d252b500d0ecfdbd6ed75f1744b0e0a4f7f5ddd234eae40db7cb72`；原包及[来源清单](../../flashswf/arts/new/Codex素材源稿/CF6大刀机器人-R2/archive-origin.json)保持不变。包内脚本和旧混淆 AS2 不执行。
- 唯一编辑源：[Codex大刀机器人素材.xfl](../../flashswf/arts/new/Codex大刀机器人素材/Codex大刀机器人素材.xfl) 及完整工程，由本目录生成器装配、真实 CS6 发布。
- `things-new.fla` 第 4 帧挂载自身 RSL 锚点；共享 SWF 的实际 ImportAssets 指向独立库。增加库内光束没有改变该锚点身份。
- [balance.py](balance.py) 只改本单位，使用工作簿对应的 [computeMonsterRow](../cf7-balance-tool/packages/core/src/formulas/monsters.ts)；[balance-inputs.json](balance-inputs.json) 保存公式输入和整数面板。台账只将用户指定的阶段、档次登记为固定量。

速度、攻速、倍率、段数和霸体系数遵守[怪物标识规则](../cf7-balance-tool/docs/monster-flag-rulebook.md)。三种攻击的前摇均值为 47/3 帧、后摇均值为 50/3 帧；后摇权重 0.2，综合节奏 19，攻速系数 4。物理重劈、物理横扫及波光束的类型加权倍率均值为 1.8，有效段数均值为 2。受击恢复 8/7 帧，击飞、倒地均委托既有物理；霸体系数仍为 2.5。临时攻击保护不改写普通受击分类。

## 动作与联动

| 动作 | 来源与接线 |
|---|---|
| 站立、行走 | 原 901/902 时间轴；行走兼作跑步外观 |
| 重劈 | 原 910，37 帧；第 20/22 帧各一次 ×2.4 物理判定；第 9–18 帧通过真实移动接口压进，每次至多 8 像素，接近目标 185 像素时停止 |
| 横扫 | 原 912，49 帧；第 19/22/25/28/31/34 帧各一次 ×1 物理判定，前后各三次 |
| 波光束 | 原 906，31 帧；保留 903/905 原生特效，第 11 帧一次 ×1 魔法／波判定，选择射程 250–600，冷却 90 帧 |
| 受击 | 原 913 的两个分支，分别在第 8/19 帧回到正常状态 |
| 击飞、倒地、被投 | 原受击姿势衔接 CF7 浮空、落地和恢复生命周期 |
| 死亡 | 原 924 的完整 58 帧、916–923 八组机械碎片，最终结算一次 |

重劈使用水平击退速度 24、垂直速度 0。收招后保留 45 帧的同目标联动窗口；目标仍存活、实例身份一致、进入射程、纵深合适且光束冷却结束时，优先接光束。目标没有实际被推远时不强制改坐标；同名新实例也不能继承旧联动。

重劈第 1–30 帧、横扫第 1–40 帧、光束第 1–11 帧持有临时刚体与抗击退，正常承受伤害；收招、中断、死亡后恢复此前状态。仇恨仍由通用 AI 提供，私有控制负责距离、纵深、招式和动作 token。暂停或外部硬直会阻止新命中，旧剪辑不能继续出手。高度超过 80、但不超过 150 像素的目标，仅在 190 像素内选择横扫。

重劈与横扫的区域高度分别为 180/200 像素，光束区域跟随原特效横向跨度。它们通过 `攻击点.area` 和正式 `子弹区域shoot传递` 结算，子弹速度为零；没有直接扣目标 HP、百分比伤害或强制进入联动射程。命中率输入 30，仍进入正式闪避结算。

## 原生矢量与接地

`vector.py` 保留原注册矩阵、渐变、刀孔和死亡碎片图集；外层统一减去站姿脚底偏移 `44.03251647949219`，死亡首姿额外 0.85 像素偏移按相同分件对齐消除。独立 `bladebotShadow` 跟随世界 Z，处理镜像、旋转、缩放及阴影开关，不写入历史 `unit.shadow` 或 `gameworld.shadow`。

当前库为 **49,625 字节、73 个 Shape、20 个 Sprite、0 位图**，XFL 有 113 个原生元件。32 个绘制点覆盖新增光束全部 31 帧及镜像关键帧。最终[图片与来源](evidence/20261017-wave/native/image-provenance.json)保留八个原动作画面及两张完整光束取景；首次光束截图裁到后腿、补拍时测试文字仍显示的中间结果均单独保留。Agent 逐图复核不代替动画手感和游戏内验收。

## 公共击退修正

实际命中夹具暴露了共用敌人模板回调中的作用域错误：`this.speed -= 减速度` 读取不到单位自身摩擦力，会得到 NaN。修正为 `this.speed -= this.减速度`，其他代码和文件编码保持原样；同时经真实 CS6 重新发布 asLoader。

原函数逐字抽取的独立夹具先得到 2 passed / 5 failed，修复后 7 passed / 0 failed，覆盖左右移动、独立摩擦力、暂停式硬直、抗击退和有限停止。大刀专项为 **409 passed / 0 failed**，28 组真实时间轴动作、15 状态 × 2 方向，并包含三组正式伤害／冲击／被击移动的集成夹具：两侧目标从距离 185 被推到 308 后各接一次有效光束；抗击退目标保持 185，不触发联动。这是隔离夹具中的实际生产函数验证，实际对战结果另列。

共用修正后，大头机器人另跑 18 场全部获胜，翼虎专项 389 passed / 0 failed。旧 asLoader、失败尝试、原始编译和恢复回执保留在新证据包中；不把旧测试结果自动升级为新资源结果。

## 构建与验证

从仓库根执行，PowerShell 先 `chcp.com 65001`：

```powershell
python -X utf8 -B tools/cf6-bladebot-assets/balance.py --write
python -X utf8 -B tools/cf6-bladebot-assets/build.py --import-approved
python -X utf8 -B tools/cf6-bladebot-assets/build.py --check
python -X utf8 -B tools/cf6-bladebot-assets/test_vector.py
scripts/compile_test.ps1 -Target 'flashswf/arts/new/Codex大刀机器人素材/Codex大刀机器人素材.xfl' -PublishOnly -VerifySwf 'flashswf/arts/new/Codex大刀机器人素材.swf'
scripts/run-cf6-bladebot-asset-tests.ps1
scripts/run-cf6-bladebot-beam-render-tests.ps1
scripts/run-cf6-bladebot-asset-tests.ps1 -Capture
scripts/run-cf6-bladebot-beam-render-tests.ps1 -Capture
python -X utf8 -B tools/cf6-bladebot-assets/decode-native-capture.py <完整截图trace> <新目录>
python -X utf8 -B tools/cf6-bladebot-assets/decode-native-capture.py <两张光束trace> <新目录> --beam-only
scripts/compile_test.ps1 -StopTestPlayers
node tools/derive-arena-unit-catalog.js --check
python -X utf8 -B tools/cf6-bladebot-assets/verify.py --runtime-root <冻结资源目录>
```

只有共享锚点改变才另发布 things-new；本轮 asLoader 发布源于上述共用函数修正。生成器保护工程身份，不提供强制覆盖开关。专项要求本轮 Compiler 0/0、唯一完整 runId 和零 32K 重试。连续大图导出之后先通过标准控制入口停止已结束的测试播放器，再开始下一轮编译。

## 当前对战证据

[arena-wave-plan.js](arena-wave-plan.js) 要求显式的两套隔离资源、同身份候选 runtime 和只读种子，冻结源文件绑定。新[完整矩阵](evidence/20261017-wave/summary.json)共 **24 场**：30/60/99 级，每个对手交换红蓝，每侧重复两次，出生距离 650，最长 5400 帧；全部自然结束，存档、种子、资源和进程清理检查通过。只调整大刀机器人，没有修改对手。

| 对手 | 等级 | 大刀胜场／场数 | 结算范围 |
|---|---:|---:|---|
| 黑铁会改造人（现名诺亚试验体α，347） | 30 | 4/4 | 大刀余血 37.2%–44.9% |
| 黑铁会改造人 | 60 | 4/4 | 大刀余血 37.6%–41.5% |
| 黑铁会改造人 | 99 | 4/4 | 大刀余血 9.2%–11.2% |
| 方舟爪豪（286） | 30 | 0/4 | 对手净损失生命 19.5%–21.6% |
| 方舟爪豪 | 60 | 0/4 | 对手净损失生命 21.2%–28.3% |
| 方舟爪豪 | 99 | 0/4 | 对手净损失生命 20.0%–26.2% |

此前四场 60 级试跑单独保存，没有混入 24 场矩阵。99 级黑铁会对局为 4121–4366 帧，胜利余量较小；没有将超时改写为胜利。净生命损失由最终剩余生命计算，不是累计伤害。

[旧纯近战证据](evidence/20261016/combat-summary.json)及旧前台运行、捕获失败和全部探索记录保持原样。本轮面板、伤害属性与共用击退实现均有变化，旧结果只作历史参考。当前结论属于有限候选对战样本；未进行正式 runtime 发布，标准入口、最终外观和打击感等待人类验收。
