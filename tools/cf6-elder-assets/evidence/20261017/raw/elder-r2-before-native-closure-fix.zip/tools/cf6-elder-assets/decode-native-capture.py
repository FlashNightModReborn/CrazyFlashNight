"""Decode the focused Flash test's lossless RGBA row stream into native capture PNGs."""
from pathlib import Path
import argparse
import re
from PIL import Image


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('trace', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--partial', action='store_true', help='Decode only completed frames for an in-progress preview; never a complete-set check')
    args = parser.parse_args()
    captures, completed = {}, set()
    for line in args.trace.read_text(encoding='utf-8-sig').splitlines():
        match = re.fullmatch(r'\[ELDER_IMAGE_BEGIN\] ([a-z0-9-]+) (\d+) (\d+)', line)
        if match:
            name, width, height = match.groups()
            if name in captures:
                raise ValueError('Repeated image: ' + name)
            captures[name] = {'width': int(width), 'height': int(height), 'rows': {}}
            continue
        match = re.fullmatch(r'\[ELDER_IMAGE_ROW\] ([a-z0-9-]+) (\d+) (.*)', line)
        if match:
            name, y, encoded = match.groups()
            item, row = captures[name], []
            if int(y) in item['rows'] or name in completed:
                raise ValueError('Repeated or late image row')
            for token in encoded.split(','):
                value, count = token.split(':')
                if not re.fullmatch('[0-9a-f]{8}', value) or not 0 < int(count) <= item['width']:
                    raise ValueError('Invalid RGBA run')
                color = int(value, 16)
                row.extend([(color >> 16 & 255, color >> 8 & 255, color & 255, color >> 24 & 255)] * int(count))
            if len(row) != item['width']:
                raise ValueError('Wrong image row width')
            item['rows'][int(y)] = row
        match = re.fullmatch(r'\[ELDER_IMAGE_END\] ([a-z0-9-]+)', line)
        if match:
            name = match[1]
            if name in completed:
                raise ValueError('Repeated image end')
            completed.add(name)
    expected = {'human-stand-1','burst-13','stab-7','human-fall-31','robot-stand-1','beam-29','kicks-9','slam-37','robot-death-32','robot-death-111','phase-1','phase-18','phase-49','phase-55','phase-80','phase-93','burst-left-13','beam-left-29','phase-left-55'}
    if args.partial:
        captures = {k:v for k,v in captures.items() if k in completed}
        expected = completed
    if completed != expected or set(captures) != expected:
        raise ValueError('Expected the complete selected fixed-scale Elder capture set: ' + str(completed))
    args.output.mkdir(parents=True, exist_ok=True)
    for name, item in captures.items():
        if set(item['rows']) != set(range(item['height'])):
            raise ValueError('Incomplete image: ' + name)
        image = Image.new('RGBA', (item['width'], item['height']))
        image.putdata([pixel for y in range(item['height']) for pixel in item['rows'][y]])
        target = args.output / (name + '.png')
        if target.exists():
            raise ValueError('Preserve the existing capture: ' + str(target))
        image.save(target)
    print('Decoded native Flash captures: ' + ', '.join(sorted(completed)))


if __name__ == '__main__':
    main()
