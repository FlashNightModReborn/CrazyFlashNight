# CF6 普通特种兵装配

**文档角色**：源稿归属、确定性装配、装备入口与验证说明。

兵种 **466**，显示名 **CF6特种兵**，链接 `敌人-CF6特种兵`。制作组指定阶段 **7**、档次 **5**。重启游戏后可在斗兽场搜索显示名；本次装配普通版根 559，盾兵 580、撞车 629 留待后续。

## 身体来源

- R3 基线 `02A-baseline-source.zip`，SHA-256 `5c4b124b2592fb37adde7de398a377a65d38a8021f89fce3d9d5c776a728f47e`。
- R4 局部包 `02B-latest-local-source.zip`，SHA-256 `7c1f8fcff8070917794ae0fb7eed60e53744b732325083240099f9ca053dba27`。
- 比较 152 个 SVG 后确认 R4 仅修改盾牌与碎盾的 CT 字样，普通版所有画稿保持 R3 字节。
- [冻结输入清单](../../flashswf/arts/new/Codex素材源稿/CF6特种兵-R3/archive-origin.json)保留 69 个输入，包含 58 个实际使用的身体、动作变形、死亡和血液矢量图形。原 ZIP 未改变，包内脚本和旧 CF6 ActionScript 未执行。
- 唯一编辑工程为 [`Codex特种兵素材.xfl`](../../flashswf/arts/new/Codex特种兵素材/Codex特种兵素材.xfl) 所在目录，由本工具确定性装配，经真实 CS6 发布为旁边的同名 SWF；`things-new.fla` 第 4 帧保留独立共享库锚点。

本库 190 个原生元件，发布产物 83,026 字节、108 个形状、22 个 Sprite、0 位图。身体和武器挂点保持 CF6 图层、矩阵与颜色变换；实际枪械沿用玩家武器自己的共享资源。

## 军校生武器与外部配置

固定的 CF6 身体接入 `hasDressup=true`、`enableShoot=true`，使用标准装备初始化、射击事件、枪口、弹匣和装填。默认直接读取现役军校生的 `大学军校学员随机兵器表`，不另建随机表：

| 物品内部名 | 显示名 |
|---|---|
| `M4A1改` | M16战术版 |
| `AK74战术版` | AK74战术版 |
| `M4A1战术版` | M4A1战术版 |
| `DD MK18战术版` | DD MK18战术版 |

[`units.json`](../../data/units/units.json) 中兵种 466 的 `data.primary` 是外部长枪入口。默认 `null` 表示使用上述随机池；填写现有武器名则优先使用指定装备。例如：

```json
"data": {
  "primary": "AK47#4",
  "secondary": null,
  "secondary2": null,
  "melee": null
}
```

这里沿用 `BaseItem` 的装备字符串语法，示例表示四级强化 AK47。关卡生成或斗兽测试也可通过既有 `Parameters.长枪` 传入同一配置。重新运行数值生成器会保留现有 `data`，不会把外部装备改回默认值。

首批主动使用长枪主射击和原生匕首；未接入其他武器槽的攻击动作，也未验证特殊武器的专属战技。其他装备数据可沿标准初始化产生属性，但身体仍为 CF6 固定造型。友方非玩家人形沿用标准装备初始化中的生命 ×3 规则，因此红蓝交换不代表实际生命相同。NPC 装填走自身弹匣状态，不读取或扣除玩家背包。

## 动作与权威

| 动作 | 接入方式 |
|---|---|
| 站立、行走 | 原 498 / 500，共 16 / 21 帧；行走兼作奔跑外观 |
| 长枪点射 | 每次三发，由 `ShootCore` 按实际枪械间隔调度；实际开火切到 CF6 第 3 帧后坐姿势 |
| 装填 | 标准 `ReloadManager`，35 帧基础过程，读取武器装填负担；目前借用持枪准备姿势，尚无专门的手部换弹动画 |
| 匕首刺击 | 原 517，34 帧；第 14 帧一次 101×135 像素近战判定，威力为自身空手攻击力 |
| 受击 | 原 518 的 a0/a1，第 8/19 帧恢复 |
| 击飞、倒地 | 原 520 的 1–40 帧用于浮空，41–116 帧用于落地起身；委托 CF7 物理生命周期 |
| 被投 | 原 519，末帧等待外部投掷状态切换 |
| 死亡 | 原 558 的三条完整分支 1–58、59–104、105–139，分别结束时结算一次 |

八条原身体序列共 378 帧。死亡首姿按同一髋部分件对齐站姿，所有动作使用统一接地平移。独立 `soldierShadow` 覆盖所有可见状态，以世界 Z 接地，处理旋转、镜像、浮空和阴影开关。

近身 95 像素内选择匕首，同一纵深 460 像素内选择点射；保持距离 190，换目标有 6 帧反应。单位没有攻击霸体。动作 token 同时绑定当前身体、装备对象和初始化版本；切换状态前调用标准射击清理，受击、暂停、死亡和过期引用不能继续出手。

原占位手枪与 CF6 的地面枪口 helper 已退出生产。实际枪口是 `man.枪.枪.装扮.枪口位置`，登记为标准 `长枪_引用`；射速、弹种、穿刺、威力、散射、音效和容量均来自实际装备。逻辑库只新增一个薄入口 `_root.主角函数.清理射击任务`，转交既有 `ShootCore.cleanup`，不复制射击实现。

## 数值口径

[`balance.py`](balance.py)调用工作簿对应 [`computeMonsterRow`](../cf7-balance-tool/packages/core/src/formulas/monsters.ts)，只改本单位。阶段 7、档次 5 为人工固定声明；其余依据保存在 [`balance-inputs.json`](balance-inputs.json)。

依据现行[状态硬门](../cf7-balance-tool/docs/monster-flag-rulebook.md)，装备长枪状态不参与空手/近战系数测量。本单位只量匕首：前摇 13、后摇 20，带 0.2 后摇权重为 17，对应攻速 4；物理倍率 1、段数 1。速度均值 60 对应速度系数 2；短受击、可击飞、基础韧性 5 对应霸体系数 2。

公式面板：生命 **7514–21777**、空手攻击 **268–753**、基础防御 **253–705**、经验 **776–4433**。这不是长枪伤害表；实际生成还受等级、阵营与装备初始化影响。

## 原生验证与已修复问题

早期矢量转换漏算了 `clipPath` 内路径的平移，导致外框有尺寸但四肢像素缺失。旧版通过的 333 项行为检查没有覆盖该问题，原失败源码、二进制与截图均保留。本库转换器现在保持原 SVG 字节，检查 103 个遮罩与画稿的交集、精确变换坐标和真实双腿像素。

固定手枪原型的 335 项原生检查与 11 场对战属于此前版本，不能作为当前装备链通过的证据。接入装备后发现，分别 `loadMovie` 的素材库及嵌套共享库消费者都不能向根测试代码暴露同一链接范围；失败样本保留。当前测试复用仓库已有的顶层共享库宿主模式，直接导入真实身体和枪械资源。

当前装备链已完成 **517 passed / 0 failed**，共 **52 条实际时间轴过程**，Compiler `0/0`、32K retry `0`。覆盖四种默认枪、外部 AK47#4 及强化等级、真实枪口、三次耗弹、打空后标准装填、已开枪后的受击取消、装填中受击不提交弹药、过期装备/版本拒绝。16 张固定取景图已逐张检查，枪械挂点统一为原尺度的 0.8，接近军校生的持枪尺度；画面包含四种默认枪、外部枪、匕首、倒地、三种死亡和浮空镜像。本轮原始记录、失败样本、图片、源码与二进制绑定见[证据清单](evidence/20261016/summary.json)。

## 生成与验证

仓库根目录执行，PowerShell 先 `chcp.com 65001`：

```powershell
python -X utf8 -B tools/cf6-soldier-assets/balance.py --write
python -X utf8 -B tools/cf6-soldier-assets/build.py --import-approved
python -X utf8 -B tools/cf6-soldier-assets/build.py --check
python -X utf8 -B tools/cf6-soldier-assets/test_vector.py
powershell -File scripts/compile_test.ps1 -Target 'flashswf/arts/new/Codex特种兵素材/Codex特种兵素材.xfl' -PublishOnly -VerifySwf 'flashswf/arts/new/Codex特种兵素材.swf' -TimeoutSeconds 180
# 仅改变逻辑库入口时需要；本轮新增了标准射击清理桥接。
powershell -File scripts/compile_test.ps1 -Target publish -TimeoutSeconds 600
powershell -File scripts/run-cf6-soldier-asset-tests.ps1 -Capture -TimeoutSeconds 600
python -X utf8 -B tools/cf6-soldier-assets/decode-native-capture.py <本轮trace> <新图片目录>
powershell -File scripts/compile_test.ps1 -StopTestPlayers -TimeoutSeconds 60
node tools/derive-arena-unit-catalog.js --check
python -X utf8 -B tools/cf6-soldier-assets/verify.py --runtime-root <冻结资源目录>
```

新共享锚点首次接入时须单独编译 `things-new.fla`；本轮由固定枪改为标准装备时锚点未变。测试入口自动生成 [`Cf6SoldierNativeHost`](../../scripts/Cf6SoldierNativeHost/DOMDocument.xml)，使用实际 RSL 与受保护的 TestLoader scratch；测试 SWF 不进入生产交付。

生成器校验完整工程身份，旧元件退役前按上一份 manifest 保全原字节。`.as` 保持 UTF-8 BOM；不改主游戏 XFL，不手工改 SWF。

[`arena-plan.js`](arena-plan.js)生成六场有界隔离窗口对战：默认配置换边、外部 AK47#4 换边、指定枪械 2v2 换边。每场 3600 帧，650 像素出生距离，零自动重试。复用[普通窗口包装入口](../cf6-bladebot-assets/run-foreground.ps1)，由 [`foreground-evidence.js`](foreground-evidence.js)核对候选身份、资源与真实玩家存档保护。

实际装备版批次完成 6 场，运行错误为 0：

| 用例 | 特种兵在蓝方 | 特种兵在红方 |
|---|---|---|
| 30 级默认武器，对军校生 | 1539 帧胜，余血 64.1% | 1375 帧败 |
| 60 级外部 AK47#4，对军校生 | 3600 帧时限，特种兵余血 15.7%、对手 56.5% | 1406 帧败 |
| 60 级指定枪械 2v2 | 1083 帧胜，余血 52.8% / 56.5% | 486 帧败 |

共 **5 场自然结束、1 场达到时限**。时限场双方均有实际损血，保留原结果，没有自动重试或改记为胜负。由于不是六场全部自然结束，批次的严格 `qualified` 为 `false`；资源、候选身份、玩家存档保护和进程退出检查分别通过。普通启动仅更新其自有版本元数据文件，原差异保留在记录内。蓝方人形生命 ×3 已计入实际出生数据，上表只用于接入观察，不构成同面板强弱排名。

编译、专项测试、候选运行与标准入口体验分别记录。本任务不执行正式 runtime 发布；最终动画与玩法体验仍由制作组验收。
