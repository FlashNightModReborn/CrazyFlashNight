"""Build unit-private debris prefabs from the owned vector rig, with no new linkage exports."""

def fragment_layer(native, result, parts, rows, name, start, total):
    usable = [row for _, row in sorted(rows.items(), key=lambda item: int(item[0])) if row['id'] in parts]
    elements = []
    for i, row in enumerate(usable, 1):
        m = list(row['matrix'])
        fragment = name+'/分件'+str(i)
        result[fragment] = native.symbol(fragment, [native.layer('原始分件', [native.frame(elements=[
            native.instance(parts[row['id']], matrix=(m[0],m[1],m[2],m[3],0,0))])])], symbol_type='movie clip')
        elements.append(native.instance(fragment, matrix=(1,0,0,1,m[4],m[5]), symbol_type='movie clip', name='碎片'+str(i)))
    result[name] = native.symbol(name, [native.layer('预制碎片', [native.frame(elements=elements, script='stop();')])], symbol_type='movie clip')
    return native.make_sparse_layer('物理碎片', total, {start: {'duration': total-start, 'elements': [native.instance(
        name, symbol_type='movie clip', name='尸体碎片',
        script='onClipEvent(load){_parent._parent.cf6StartCorpseFragments(this,'+str(len(usable))+');}')]}})
