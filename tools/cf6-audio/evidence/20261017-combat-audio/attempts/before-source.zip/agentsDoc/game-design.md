# 游戏设计参考

---

## 1. 数值平衡

- **核心公式最高权威**：`0.说明文件与教程/武器-技能数值-价格-合成表填写的参考公式（修改后请勿上传git）.xlsx`
- **武器 balance 落盘与复现契约**：`tools/cf7-balance-tool/docs/agent-balance-record-design.md`
- **武器平衡业务判据与条款 ID**：`tools/cf7-balance-tool/docs/weapon-balance-rulebook.md`
- **防具 balance 业务判据与条款 ID**：`tools/cf7-balance-tool/docs/armor-balance-rulebook.md`
- **数值平衡覆盖契约（全装备药剂标定目标态）**：`tools/cf7-balance-tool/docs/balance-coverage-contract.md`
- **材料统计**：`0.说明文件与教程/材料的单位、关卡统计.xlsx`
- **机制属性记录**：`0.说明文件与教程/武器装备与敌人的机制属性伤害类型魔抗的实装记录.txt`
- **标签与属性**：`0.说明文件与教程/Label与魔法种类与装备属性加成的类型汇总.txt`
- **数据文件**：`data/items/`、`data/units/`
- **CF6 原生单位与连续阶段（2026-10-17，待人工验收）**：人工指定的阶段／档次与实际动作观测分别固定，成长和攻防分配仍由同一工作簿公式生成面板。老头组合的定位按完整人形→机器人两阶段、同级对手及双方换位的净生命损失检查；维护者期望约 50%–80% 血量交换，并选择先验收招式、体验后再调强度。此前 agent 自定的 25% 工作判据仅作历史记录。保留低输出、险胜与失败样本，兽王吸血回补不当作未造成伤害。具体分配理由和候选证据集中在[老头装配](../tools/cf6-elder-assets/README.md)，大刀的重击击退→波光束联动见[大刀装配](../tools/cf6-bladebot-assets/README.md)，大头的对战定位见[大头装配](../tools/cf6-headbot-assets/README.md)。有限候选对战不替代玩家操作与正式入口验收。
- **CF1 Andy 工装裤（2026-10-13）**：维护者选定 D 漫画橄榄外观，作为《修理大学》新开局的独立下装；所有运行属性和售价原样继承白色中山装裤子，不调整强度或经济规则。原白裤保留，既有书内存档不迁移装备；原生分件、图标与验证入口见 [Andy 工装裤接入](../tools/andy-trousers-assets/README.md)。
- **体育老师首领归类（2026-10-11）**：在 `data/enemy_properties/大学.xml` 的体育老师抗性表补入首领 20，落实首领伤害分类；不改变其成长或基础面板。Lee、翅虎的首领破击以目标抗性表是否有对应键决定附伤，缺项导致此前斗兽低估它们对体育老师的输出。修正前后样本分开统计；当前前治安官完整两阶段的目标及证据口径见[单位说明](../tools/former-sheriff-assets/README.md#两阶段斗兽比较)。
- **武器散射度口径**：`data/items/weapon-diffusion-guidelines.md`

- **黑仔敌人（2026-10-07，已认可当前动作并授权发布，实战强度待复验）**：沿剑道社十项标识调整成长2、档次6，其余设计输入保持，按工作簿派生公式回填新单位整数面板（HP2962–14335、空攻48–279、防御197–967），不改公式。韧性系数6，魔抗沿原配给。固定NPC外观，普攻接正式短柄，迅斩调整准备与挥棒身体制动并提供削韧/击退，凶斩沿正常出手与内力伤害。额外内力为 `max(0,等级-15)*15`，20级+75、30级+225、60级+675；保持20级配给、提高后段斜率的依据是旧曲线完整武器池60级血差从30级+47.4%回落到+38.7%。取消 MP 消耗前的90场历史真实XML复验：20级21/36胜、平均剩余血差+5.1%；30级14/18胜、平均剩余血差+41.7%；60级16/18胜、平均剩余血差+46.8%；99级15/18胜、平均剩余血差+33.5%。30级起可施放霸体，维持90个未暂停帧刚体、15秒冷却；迅斩、凶斩和霸体均不检查或消耗 MP，取消资源限制后尚未重跑斗兽，安全距离或贴身低韧性时考虑，不附减伤/无敌。同等级斗兽只校正蓝方原生HP×3/黑仔MP÷10资源偏差，非技能面板参数与普通XML相同，保留原生AI、武器和真实命中结算；1/10级额外内力0的历史36场单列，小样本不代表对玩家构筑已平衡。动作、生命周期与验证口径见[原生素材专项](../scripts/test-runners/student-repair/README.md)，最新迅斩补齐空手前引、出棒时收肘回拉与制动回护；本轮按维护者明确授权走发布列车，发布状态见正式回执，不能以历史有限 MP 斗兽代证当前强度。

## 2. 机制体系

- **下水道探索肉鸽（方向初稿已审阅通过，尚未施工）**：[《下水道探索报告》肉鸽方向性初稿](../docs/下水道探索报告-肉鸽方向性初稿-2026-10-09.md)（固定 25 级随机构筑、四阶段流程、双向持久共仓与资源成本；数值与待定事项仍未冻结）。

- **战斗机制**：伤害类型与魔抗体系、Buff/Debuff 计算、子弹与攻击判定（详见 [game-systems.md](game-systems.md)）
- **书中副本成长与补给**：[书架与角色档案切换](../docs/bookshelf-player-context.md#首轮内容与调参)（《修理大学》按每图经验预算支持短局换装，每波集中配给减少拾取点，技能按局内用途筛选。配给提供购装、改装与毕业装备强化之间的金币取舍；第二/四图的自选包从战斗组抽两套、成长与生存组抽一套后选一。拳套有商店与掉落兜底，项链、月系及高级下挂提供构筑方向，导弹只附少量电池。具体选品、兼容和配额以该文及配置为准；局内成长隔离于原角色，外部 SP 奖励单独调节）。
- **套装系统**：[套装系统设计与剑圣一期验收](../docs/套装系统-设计与剑圣一期验收-2026-07-14.md)（抗性表项声明 + 定制行为双路由；抗性字段存在会开启对应定向特攻破击，剑圣五件套为第一阶段验收产物）
- **钛合金61式套装玩法**：[钛合金61式装甲套装玩法设计 ADR](../docs/钛合金61式装甲套装-玩法设计-ADR-2026-07-27.md)（五件防具门控；MP驱动护盾/维生/双枪补弹；P90发射发电；M134/P90/血剑/钛合金QJZ171机制亲和；太空基地低重力设定与-17kg火控恢复；高级夜视与应急自动注射边界）；[原型建模](../docs/钛合金61式套装-原型建模-2026-09-08.md)记录剑圣50+实测档位、牙狼对照、合法槽位及玻璃大炮的能源/生存约束。
- **武器异质化讨论备忘**：[冲锋枪错位竞争与双枪插件设计备忘](../docs/冲锋枪错位竞争与双枪插件-设计备忘-2026-07-13.md)（换弹负担、冲击曲线、`hitBehavior`、破韧增伤 MetaBuff、普通手枪行为型补弱；两波均已施工，运行态标定待做）
- **盗贼黑市盲盒鉴定**：[玩法规格与审计基线](../docs/盗贼黑市盲盒鉴定-玩法规格与审计基线-2026-08-19.md)（六货包三组二选一、交易点/K 点流动价值闭环、解密 0–10 级信息权限、page draft/page object 双阶段、纸娃娃污泥配对、独立小游戏视觉硬门与跨栈验收；影子版已将 492/492 非颈部防具接入现役 `EquipmentInspector` 局部 fit/draw 取景，只渲染装备占用的多组件肢体，并以切组封存层阻断未覆泥原图闪现；污泥已按“休眠军用纳米机器人”设定升级为静态团簇、蜂群接缝与冷金属微粒材质；当前仍为 `AUDIT_REVISED / SHADOW_MINIGAME_V1 / OBJECT_SURFACE_V2 / BROWSER_VISUAL_REVIEW_PENDING / PRODUCTION_NOT_IMPLEMENTED`）；项目内首版入口与边界见[黑市全目录影子版](../launcher/web/modules/minigames/blackmarket/README.md)，One-shot 产出回收和真实游戏接入见[交接文档](../docs/盗贼黑市盲盒鉴定-产出回收与游戏接入交接-2026-08-19.md)
- **军阀战棋关卡化与大地图**：[vNext ADR](../docs/军阀战棋关卡化-N阵营编制与大地图演进-ADR-2026-08-31.md) 冻结 Warlord SubStage、N 战略阵营/二方交战、CommandElement/编制/TaskGroup、指挥所/VictoryGroup、规则与表现分离，以及“零英文、零战棋基础”的玩家语义。
  - Demo 1 的单 Warlord GameStage、动态九节点地图、Organization sidecar、2～4 人临时编队、五阵型和目标节点近 `180` / 中 `360` / 远 `650` 已贯通；维护者已确认编组、Formation、距离功能和主体玩法有效。距离与攻宽、阵型正交，设计目标仍是让突击兵/弹药兵在狙击兵之外获得实战位置。
  - Slice 4 已有 N 阵营机器实现：固定对称关系、阵营 block turn、三个 VictoryGroup、指挥所失败/投降清理，以及玩家主角与三名 Boss 共四名指挥官。映射固定为吴豫 / Itinerant / 111、袁望 / Surveyor / 113、阎凝儿 / Gazer / 112；吴豫与阎凝儿结盟，袁望政治独立但在本局与其余三方全部 hostile。同盟过境与玩家/AI 命令共用同一 validator。
  - Slice 6 的 `demo2-thick-x-80` 采用四角基地、中央高价值产地的 80 节点“厚 ×”：四方各 14 节点本土纵深，经 16 个争夺臂节点进入中央 8 节点工业环。候选同时具备中文检索/告警、六节点虚拟导航、三级 LOD、路线/实例批处理和有预算的局部 AI 枚举；战区工具默认收起并从节点导航栏展开，`Esc` 收起后回焦；底部 8 张普通兵牌可从 `120px` 折为 `32px`，向沙盘返还 `88px`。Host exact catalog 固化四方关系并逐一复验 80 节点的三档交战距离。Demo 1/2 的独立 GameStage XML 目前只由测试菜单白名单选关页暴露，默认生产目录保持不变，正式入口属于 Slice 7。
  - Slice 5 产品桥已完成 exact inner lease、每战 fresh world、world/dispatcher/camera/污染 teardown，以及真实玩家主角的隔离生成、攻守控制、阵亡转镜头和状态恢复机器闭环。初始、r2、r3 三个候选均因真人阻断固定为 `FAILED / SUPERSEDED / NOT_DEPLOYED`；当前 r4 已修复 canonical digest、AI 未开战收束、存档权威纸娃娃、player-avatar 专用棋子与 receipt、exact terminal/close/fresh resume，并把过渡世界清理从外层启动前移到已提交的 Action battle handoff。r4 已从精确 Core 路径启动，准确状态为 `SLICE_4_MACHINE_VERIFIED / SLICE_5_PRODUCT_BRIDGE_MACHINE_VERIFIED / SLICE_6_REPAIR_MACHINE_VERIFIED / READY_FOR_HUMAN_SLICE_6_ACCEPTANCE / candidate_executed / NOT_DEPLOYED`；Demo 2 连续 WebView2/AS2 多战、玩家存档无漂移、目标设备性能和 Slice 6 真人玩法仍待验收，正式 runtime 与 deployment 未改变。
- **好感度系统**：`0.说明文件与教程/好感度系统思路方案.xlsx`

## 3. 世界观与叙事

- **超级材料与工程遗产**：[统合时期的超级材料学](../docs/worldbuilding/21-统合时期的超级材料学.md)（材料性能与工艺、昂贵特装到普及、末世制造瓶颈；钛基材料和61系为首个完整案例，后续同类材料沿此入口补建）。

- **对话数据**：`data/dialogues/`
- **支线规划**：`0.说明文件与教程/支线规划表.xlsx`
- **Wings 桌宠 / Agent 一期方向**：[CF7 Agent Runtime 与 Wings Network 一期范围冻结 ADR](../docs/CF7-Agent-Runtime与Wings-Network一期-范围冻结-ADR-2026-07-30.md)（F7 C1 source freeze `dd84230a1d262c6478591cae2d11051b7a8aa7b1` 与其 `candidate_built / NOT_DEPLOYED` 凭据超时结论保留为历史证据。F8 implementation source `53caabc90941826ddacf626f536b0f473adbf049` 的 isolated candidate 先经纯 Agent Runtime MCP 达到 `e2e_verified / NOT_DEPLOYED`；release source `6f3d50a52413c747b05b74be88d6ee46650f4597` 随后取得本地 X509 + GitHub OIDC/Sigstore 双故障域共识、完成 v2 promotion，并由无 candidate id 的正式入口复验同一单屏 Launcher、玩家 HUD 与经授权打开的帮助 Web 面板纵切，达到 `standard_entry_verified`。production structured opener 的关闭 allow-list 另含地图、任务、队伍和点唱机，但本轮没有把其余四个面板写成人工目视通过。Flash 游戏画面本身只暴露可见性与窗口元数据，不向 Agent 提供像素、激活或原生输入；运行未使用 Codex Computer Use、browser/Chrome、legacy privileged HTTP 或 `input.*`。该结论不表示 Agent 可以代打、控制战斗、读取 Flash 画面、跨物理双屏操作，也不表示 Hair/Wings 完整产品或维护者人工目视签收已经完成。Wings 仍是复用项目中立底座的受限叙事客户端，自由文本永远零执行；桌宠口吻/视觉与最终 Boss 机制尚未冻结，既有剧情真相仍以 worldbuilding 权威路由为准）

## 4. 关卡与环境

- `data/stages/`、`data/environment/`、`0.说明文件与教程/无限过图背景配置教程.pdf`
- **三维选关空间设计**：[创作与交接经验](../docs/三维选关场景创作与交接经验.md)（黑铁会总部案例：剧情批次与空间交通、设施职能与台地、双层仪式空间、攻击审阅裁决、默认镜头及标签辨识；具体采用布局仍归 R7 工单）。

## 5. 新内容添加

- `0.说明文件与教程/添加新物品和单位的详细基础教程宝宝可用.docx`
- `0.说明文件与教程/1.改动说明（含作弊码）.txt`

---

游戏设计决策和平衡调整应在此文档中记录理由。归档流程见 [self-optimization.md](self-optimization.md)。

