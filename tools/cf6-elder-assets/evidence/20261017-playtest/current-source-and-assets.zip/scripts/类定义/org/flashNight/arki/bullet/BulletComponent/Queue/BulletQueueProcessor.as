﻿/**
 * ============================================================================
 * 高性能子弹队列处理器（企业级优化版本）
 * ============================================================================
 *
 * 【系统概述】
 * 本类是游戏子弹碰撞检测系统的核心处理器，实现了高度优化的批量碰撞检测算法。
 * 通过双指针扫描线与有序缓存，将**碰撞阶段**的遍历从 O(B×T) 降至**摊还 O(B+T)**；
 * **整体帧成本**≈ 排序 `O(B log B)`（近有序时摊还近 `O(B)`） + 扫描 `O(B+T)`。
 *
 * 【核心算法特性】
 * - 双指针扫描线算法：O(B+T) 摊还复杂度的碰撞窗口计算
 * - 空窗口快判：O(1) 时间判断子弹是否有潜在目标，避免无效循环
 * - 右边界截断：当目标左边界超过子弹右边界时立即终止内层循环
 * - 循环展开优化：在跳过区间采用4步推进，**最多**可减少约75%的条件判断；实际效果取决于场景分布
 * - 静态上下文复用：零分配策略，避免GC压力
 * - 内联处理：消除高频函数调用开销，最小化栈帧切换成本
 *
 * 【性能优化技术】
 * 1. 内存优化：静态上下文复用；**核心扫描零临时分配**（除非触发联弹多边形**懒创建**或表现系统分配）
 * 2. 算法优化：双指针扫描线，空窗口快判，右边界截断
 * 3. 微优化：变量声明提升、属性缓存、位运算预计算；**热点路径尽量内联**，保留必要的业务/碰撞调用
 * 4. 渲染优化：延迟多边形碰撞器创建和更新；**首次命中该类弹体时会发生一次分配与更新**
 *
 * 【适用场景】
 * - 大规模子弹碰撞检测
 * - 实时游戏帧率要求
 * - AS2虚拟机优化环境
 *
 * 【变更历史】
 * v3.1: 优化变量声明组织，提升至函数级作用域避免循环内重复声明
 * v3.0: 实现双指针扫描线算法，添加空窗口快判优化
 * v2.0: 引入静态上下文复用，消除GC压力
 * v1.0: 基础队列处理实现，内联executeLogic优化
 *
 * @version 3.1
 * ============================================================================
 */

import org.flashNight.arki.bullet.BulletComponent.Queue.*;
import org.flashNight.arki.bullet.BulletComponent.Chain.*;
import org.flashNight.arki.component.Collider.*;
import org.flashNight.arki.bullet.BulletComponent.Collider.*;
import org.flashNight.arki.bullet.BulletComponent.Config.TeslaRayConfig;
import org.flashNight.arki.component.Damage.*;
import org.flashNight.arki.component.*;
import org.flashNight.arki.component.Effect.*;
import org.flashNight.arki.unit.UnitComponent.Targetcache.*;
import org.flashNight.arki.render.*;
import org.flashNight.sara.util.*;
import org.flashNight.neur.Event.*;
import org.flashNight.arki.component.StatHandler.*;
import org.flashNight.naki.DataStructures.Dictionary;

/**
 * 高性能子弹队列处理器类
 *
 * 使用双指针扫描线算法和多项微优化技术，实现了高效的批量子弹碰撞检测。
 * **静态工具类**；**内部维护全局状态（activeQueues/fakeUnits）**；API为静态方法。
 *
 * 【线程/时序约束】
 * - 假定在**帧末统一调用 processQueue()**，确保所有子弹完成发射更新后再进行碰撞检测
 * - 子弹通过add()方法在帧中任意时刻加入队列，在帧末批量处理
 * - 静态上下文复用基于单线程帧末同步处理的假设，不支持并发调用
 * - 外部模块应对齐调用时机，避免在碰撞检测过程中修改队列状态
 */
class org.flashNight.arki.bullet.BulletComponent.Queue.BulletQueueProcessor {

    // ========================================================================
    // 静态数据存储
    // ========================================================================

    /**
     * 友伤队列键名常量
     * 友伤子弹（STATE_FRIENDLY_FIRE）需要检测全体单位，使用 acquireAllCache 获取缓存。
     * 此键名仅用于 activeQueues/fakeUnits/queueUIDs 的索引，
     * 与 TargetCacheUpdater._ALL_FACTION 无关联。
     */
    private static var FRIENDLY_FIRE_KEY:String = "all";

    /**
     * 按阵营分类的活动队列映射表
     * 键: 阵营名称字符串（与FactionManager.getAllFactions()返回值一致，以及 FRIENDLY_FIRE_KEY）
     * 值: BulletQueue实例
     * 注意：键名大小写需与FactionManager注册时保持一致
     */
    public static var activeQueues:Object;

    /**
     * 按阵营分类的假单位映射表
     * 用于查询目标缓存时提供阵营上下文信息
     * 键: 阵营名称字符串 (与activeQueues保持一致)
     * 值: 该阵营的代理单位对象
     */
    public static var fakeUnits:Object;

    /**
     * 按阵营分类的预计算UID映射表（性能优化）
     * 用于避免每帧重复调用 Dictionary.getStaticUID() 和位运算
     * 键: 阵营名称字符串 (与activeQueues保持一致)
     * 值: 该阵营的 12位UID (Dictionary.getStaticUID(fakeUnit) & 0x0FFF)
     * 注意：在 initialize() 时计算一次，processQueue() 中直接使用
     */
    public static var queueUIDs:Object;

    /**
     * 射线子弹独立处理队列
     * 射线子弹是单帧检测，不进入常规 BulletQueue，
     * 在 processAllQueues() 中优先于主循环独立处理，
     * 避免每发常规子弹都为射线子弹承担分支检测开销。
     */
    private static var _rayBullets:Array = [];

    /**
     * 射线存活集双缓冲。
     * processRayBullets 帧末同步处理，处理期间追加到 _rayBullets 的新射线按旧语义丢弃；
     * 交换缓冲后清空旧数组即可避免每帧分配 survivors。
     */
    private static var _raySurvivors:Array = [];

    /** 喷火视觉提交序号：同一喷口的新束可接管旧束视觉，旧束仅保留命中结算。 */
    private static var _flameVfxSerialCounter:Number = 0;

    /**
     * 射线持久化总开关（deferral=B）。
     * true（默认）：pierce/chain/combo 走每帧贪心持久路 processPersistentRay；
     * false：全部回退旧批量路（单帧结算）—— 生产回退 + no-death 等价测试用来 A/B 同场景。
     */
    public static var _rayPersistent:Boolean = true;

    /**
     * no-death 等价测试探针（仅 RayPipelineEquivalenceTest 用；生产恒 null）。
     * 非 null 时 settleHit 录 (hitTarget, dmgMult) 并短路返回 —— 纯比对 selection，
     * 不跑 calculateDamage/事件/死亡（batch settleRayHit 与 greedy injectHit 均汇聚 settleHit）。
     */
    public static var _raySettleProbe:Function = null;

    /**
     * 射线命中结果复用对象（零分配）
     * 用于 processRayBullets 中传递给事件系统的 CollisionResult，
     * 每次命中前更新 overlapCenter 和 overlapRatio 即可。
     * 由于事件处理是同步的，复用安全。
     */
    private static var _rayHitResult:CollisionResult = CollisionResult.Create(
        true, new Vector(0, 0), 1
    );

    /**
     * 射线命中上下文复用对象（零分配）
     * 打包 processRayBullets 中每发子弹不变的参数（bullet, shooter,
     * finalResult, flags, meleeMask, Dodge, Damage, FX），
     * 使 settleRayHit 签名从 13 参数降到 6 参数。
     * 每发子弹入口处初始化一次，同步处理保证复用安全。
     */
    private static var _rayHitCtx:Object = {};

    /**
     * 主循环 settleHit 的 per-bullet 不变量容器（对齐 _rayHitCtx；子弹命中-伤害双管线拆分 §4.0 (a)）。
     * 每发子弹入口填充一次（bullet/shooter/Damage/flags/meleeMask），同步消费保证复用安全。
     */
    private static var _hitCtx:Object = {};

    /**
     * injectHit 专用 per-call 不变量容器（独立于 _hitCtx，防止装备/技能层在主循环 settleHit
     * 进行中调用 injectHit 时相互覆盖 ctx 字段）。同步消费保证复用安全。
     */
    private static var _injectCtx:Object = {};

    /** 稀有旧弹允许影响本次 DamageCalculator 的纯参数白名单（冷路径）。 */
    private static var _preHitTransformKeys:Array = [
        "伤害类型", "魔法伤害属性", "子弹威力", "固伤",
        "百分比伤害", "霰弹值", "击溃", "斩杀"
    ];

    // ========================================================================
    // 子弹终止控制标志位（位运算优化）
    // 说明：REASON_* 位用于统计/诊断；实际终止分支仅依据 MODE_* 位（见收尾处理）
    // ========================================================================

    /** 终止原因：命中单位 */
    private static var KF_REASON_UNIT_HIT:Number     = 1 << 0;  // 0x1

    /** 终止原因：达到穿透上限 */
    private static var KF_REASON_PIERCE_LIMIT:Number = 1 << 1;  // 0x2

    /** 终止模式：播放消失动画 */
    private static var KF_MODE_VANISH:Number         = 1 << 8;  // 0x100

    /** 终止模式：直接移除 */
    private static var KF_MODE_REMOVE:Number         = 1 << 9;  // 0x200

    /**
     * 预计算的组合常量：穿透上限 + 直接移除
     * 避免运行时重复位运算计算
     */
    private static var KF_PIERCE_LIMIT_REMOVE:Number = (1 << 1) | (1 << 9);  // 0x202

    // ========================================================================
    // 射弹预警常量（Phase 2+ 尾循环）
    // ========================================================================

    /** X方向探测窗扩展距离（~20帧 × 15px/帧） */
    private static var WARN_PAD_X:Number = 300;

    /** ETA上限帧数（超过不预警） */
    private static var ETA_MAX_FRAMES:Number = 25;

    /** Y走廊容差（擦弹压迫感） */
    private static var WARN_PAD_Y:Number = 15;

    // ========================================================================
    // 消弹状态缓存（逐帧复用）
    // ========================================================================
    /**
     * 消弹结果 Token（逐帧复用）
     *
     * 编码结构：token = (queueStamp << 2) | mode
     *   - queueStamp = (frameId << 12) | (queueUID & 0x0FFF)
     *   - mode: 0=NONE, 1=VANISH, 2=REMOVE, 3=BOUNCE
     *
     * 不变量与安全性：
     *   - 每个token绑定特定帧ID和队列UID，跨帧/跨队列自动失效
     *   - mode 占 token 的低 2 位；其余位为 queueStamp
     *   - 在 (token>>>2) 得到的 stamp 中：高位为 frameId，**低 12 位为 queueUID
     *   - 验证时必须同时检查frameId和queueUID，确保token来自当前队列当前帧
     *
     * 写入示例：
     *   queueStamp = (frameId << 12) | (queueUID & 0x0FFF);
     *   cancelToken[i] = (queueStamp << 2) | mode;
     *
     * 读取示例：
     *   token = cancelToken[bulletIndex] | 0;  // undefined -> 0
     *   stamp = token >>> 2;
     *   valid = ((stamp >>> 12) == frameId) && ((stamp & 0x0FFF) == queueUID);
     *   tokenMode = valid ? (token & 3) : 0;
     */
    private static var _cancelToken:Array = [];
    // 仅当 mode==3(BOUNCE) 时使用，存发射者名
    private static var _cancelBounceShooter:Array = [];
    // 不再维护额外的帧ID；统一使用全局帧计数

    // ========================================================================
    // 系统初始化方法
    // ========================================================================

    /**
     * 初始化子弹队列处理器
     *
     * 创建所有阵营的子弹队列和对应的假单位对象，为后续的碰撞检测做准备。
     * 此方法应在游戏启动时调用一次。
     *
     * 重要约束：
     * - 所有自定义阵营必须在调用此方法之前通过FactionManager.registerFaction()注册
     * - 在初始化完成后再注册新阵营会导致add()方法访问不存在的队列并抛出错误
     *
     * @return {Boolean} 初始化是否成功，始终返回true
     *
     * 初始化内容：
     * 1. 为每个已知阵营创建独立的BulletQueue实例
     * 2. 为每个阵营创建假单位对象，用于目标缓存查询
     * 3. 创建特殊的友伤队列（FRIENDLY_FIRE_KEY），处理友伤子弹
     */
    public static function initialize():Boolean {
        // 初始化映射表
        activeQueues = {};
        fakeUnits = {};
        queueUIDs = {};  // 新增：初始化UID缓存表

        // 获取所有已注册的阵营列表
        var fractions:Array = FactionManager.getAllFactions();
        var i:Number;
        var key:String;
        var fakeUnit:Object;  // 临时变量，用于预计算UID
        
        for (i = 0; i < fractions.length; i++) {
            key = fractions[i];

            // 为每个阵营创建独立的子弹队列
            activeQueues[key] = new BulletQueue();

            // 创建该阵营的假单位，用于目标缓存查询时的上下文信息
            fakeUnit = FactionManager.createFactionUnit(key, "queue");
            fakeUnits[key] = fakeUnit;

            // 新增：预计算并缓存12位UID，避免每帧重复调用getStaticUID
            queueUIDs[key] = Dictionary.getStaticUID(fakeUnit) & 0x0FFF;
        }

        // 创建特殊的友伤队列，处理设置了友军伤害标志的子弹
        // 使用已注册的 HOSTILE_NEUTRAL 阵营创建 fake unit（语义：对所有人敌对）
        // 注意：acquireAllCache 走 "全体" 路径，完全忽略 fakeUnit 的阵营，
        // 此处选择 HOSTILE_NEUTRAL 仅为确保使用已注册阵营，避免隐式行为依赖
        activeQueues[FRIENDLY_FIRE_KEY] = new BulletQueue();
        fakeUnit = FactionManager.createFactionUnit(FactionManager.FACTION_HOSTILE_NEUTRAL, "queue_friendlyfire");
        fakeUnits[FRIENDLY_FIRE_KEY] = fakeUnit;
        queueUIDs[FRIENDLY_FIRE_KEY] = Dictionary.getStaticUID(fakeUnit) & 0x0FFF;

        return true;
    }

    // ========================================================================
    // 系统重置方法
    // ========================================================================

    /**
     * 重置子弹队列处理器
     *
     * 用于场景切换时清理队列，避免内存泄漏。
     * 调用所有活动队列的clear方法清空子弹。
     *
     * @return {Boolean} 重置是否成功
     */
    public static function reset():Boolean {
        // 遍历所有活动队列并清空
        var key:String;
        var queue:BulletQueue;
        for (key in activeQueues) {
            queue = activeQueues[key];
            queue.clear();
        }
        // 清空射线子弹独立队列：deferral=B 持久射线可能跨帧存活，过场须 removeMovieClip
        // 回收各自的 RayCollider（防泄漏），再清空。批量射线本就当帧销毁、此处通常为空。
        for (var ri:Number = 0; ri < _rayBullets.length; ri++) {
            _rayBullets[ri].removeMovieClip();
        }
        _rayBullets.length = 0;
        _raySurvivors.length = 0;
        _flameVfxSerialCounter = 0;
        // 重置射弹预警门控计数（场景切换时单位已销毁）
        BulletThreatScanProcessor.reset();
        return true;
    }

    // ========================================================================
    // 子弹添加方法
    // ========================================================================

    /**
     * 将子弹添加到对应阵营的队列中
     *
     * 根据子弹的友军伤害设置和发射者阵营，自动将子弹路由到正确的队列。
     * 此方法通常在子弹创建时调用。
     *
     * @param {Object} bullet 要添加的子弹对象
     *
     * 路由规则：
     * - 若 STATE_FRIENDLY_FIRE 标志位为1，添加到友伤队列（FRIENDLY_FIRE_KEY，可伤害所有单位）
     * - 否则根据发射者的阵营，添加到对应阵营的队列
     *
     * 性能说明：
     * - 使用位运算检测友军伤害标志，避免布尔属性查找开销
     * - 阵营查询结果存入局部变量queueKey后立即使用
     */
    public static function add(bullet:Object):Void {
        // === 宏展开：实例状态标志位 ===
        #include "../macros/STATE_FRIENDLY_FIRE.as"

        // 读取实例状态标志位，检测友军伤害标志
        var sf:Number = bullet.stateFlags | 0;
        var isFriendlyFire:Boolean = (sf & STATE_FRIENDLY_FIRE) != 0;

        // 根据友军伤害标志选择队列类型
        var queueKey:String = isFriendlyFire ? FRIENDLY_FIRE_KEY :
            FactionManager.getFactionFromUnit(_root.gameworld[bullet.发射者名]);

        // 将子弹添加到对应队列
        activeQueues[queueKey].add(bullet);
    }

    // ========================================================================
    // 子弹预检查方法（按实现类型分类优化）
    // ========================================================================

    /**
     * 透明子弹专用的预检查方法
     *
     * 透明子弹是指使用纯Object实现的轻量级子弹，无MovieClip渲染开销。
     * 此类子弹通过数据驱动模拟，总是需要进行逻辑碰撞检测，因此直接加入执行队列。
     *
     * @param {Object} bullet 透明子弹对象（非MovieClip实例）
     *
     * 技术特点：
     * - 无渲染树开销：不占用Flash显示列表资源
     * - 纯数据驱动：通过Object属性模拟子弹行为
     * - 性能优化：减少内存分配和垃圾回收压力
     *
     * 处理流程：
     * 1. 更新子弹的AABB碰撞器边界（基于数据计算）
     * 2. 无条件将子弹加入执行队列进行碰撞检测
     */
    public static function preCheckTransparent(bullet):Void {
        var areaAABB:AABBCollider = bullet.aabbCollider;
        var detectionArea:MovieClip = bullet.子弹区域area;

        // 更新碰撞检测边界
        if (detectionArea) {
            // 基于关联的可视区域更新AABB（如引导激光等）
            areaAABB.updateFromBullet(bullet, detectionArea);
        } else {
            // 基于透明子弹数据属性更新AABB（纯数学计算）
            areaAABB.updateFromTransparentBullet(bullet);
        }

        // 透明子弹总是进入碰撞检测执行段
        BulletQueueProcessor.add(bullet);
    }

    /**
     * 射线子弹专用预检查方法
     *
     * 射线子弹不进入常规 BulletQueue，而是加入独立的 _rayBullets 数组。
     * 在 processAllQueues() 中由 processRayBullets() 单独处理，
     * 避免主碰撞循环中每发子弹都执行射线类型分支检测。
     *
     * @param bullet 射线子弹对象（透明/浅拷贝类型）
     */
    public static function preCheckRay(bullet):Void {
        // RayCollider 在 TeslaRayLifecycle.bindCollider() 中已创建并设置到 bullet.aabbCollider
        // 此处无需更新 AABB（射线碰撞器的边界在创建时已确定）
        _rayBullets.push(bullet);
    }

    /**
     * MovieClip子弹专用的优化预检查工厂方法
     *
     * 返回一个针对特定MovieClip子弹实例优化的预检查函数。此函数会根据子弹的
     * 区域属性决定是否需要进行碰撞检测，区分纯运动弹和实际战斗子弹。
     *
     * @param {MovieClip} bullet 要创建预检查函数的MovieClip子弹对象
     * @return {Function} 特化的预检查函数，返回boolean表示是否进入执行段
     *
     * 返回函数的行为：
     * - 若子弹无碰撞区域：仅更新位移，返回false（装饰性/纯运动弹）
     * - 若子弹有碰撞区域：更新AABB并加入队列，返回true（战斗子弹）
     *
     * 性能优化：
     * - 函数特化：避免运行时重复检查子弹类型
     * - 早期过滤：将非战斗子弹在预检查阶段过滤掉
     * - 减少队列负载：降低主处理循环的工作量
     *
     * 注意：返回函数需以**子弹为调用者**绑定（`this === bullet`），例如：`bullet.onEnterFrame = returnedFn;`
     */
    public static function createNormalPreCheck(bullet:MovieClip):Function {
        // 返回针对该MovieClip子弹特化的预检查函数
        return function():Boolean {
            // === 宏展开：实例状态标志位（闭包内也可使用，编译期文本替换） ===
            #include "../macros/STATE_HIT_MAP.as"

            var x:Number = this._x;
            var y:Number = this.Z轴坐标;

            if(x < _root.Xmin || x > _root.Xmax || y < _root.Ymin || y > _root.Ymax) {
                // 超出边界的子弹直接移除
                // 目前存在未定位的僵尸子弹成因
                // 引入更强的边界清理以防万一
                // 使用位运算直接写入 stateFlags
                this.stateFlags |= STATE_HIT_MAP;
            }


            var detectionArea:MovieClip = this.area;

            // 纯运动弹分支：无碰撞区域的装饰性子弹
            if (!detectionArea) {
                // 仅执行位移更新，不参与碰撞检测
                this.updateMovement(this);
                // _root.服务器.发布服务器消息("BulletQueueProcessor: skip non-combat bullet " + this._name);
                return false;
            }

            // 战斗子弹分支：有碰撞区域的实际战斗子弹
            var areaAABB:AABBCollider = this.aabbCollider;
            areaAABB.updateFromBullet(this, detectionArea);

            // 加入碰撞检测执行段
            BulletQueueProcessor.add(this);
            // _root.服务器.发布服务器消息("BulletQueueProcessor: enqueue combat bullet " + this._name);
            return true;
        };
    }

    // ========================================================================
    // 射线子弹辅助函数
    // ========================================================================

    /** 每次扫描只证明一次源类型/有限边界，并读取真实 Band 半宽；不保留跨帧缓存。 */
    public static function prepareRayYWindow(ray:Object):Object {
        if (ray == null) return null;
        var proto:Object = ray.__proto__;
        if (proto !== RayCollider.prototype && proto !== BandRayCollider.prototype) return null;
        if (ray.getAABB !== RayCollider.prototype.getAABB) return null;
        if (proto === BandRayCollider.prototype && ray.getHalfWidth !== BandRayCollider.prototype.getHalfWidth) return null;
        var rayLeft:Number = ray.left, rayRight:Number = ray.right;
        var rayTop:Number = ray.top, rayBottom:Number = ray.bottom;
        var halfWidth:Number = proto === BandRayCollider.prototype ? BandRayCollider(ray).getHalfWidth() : 0;
        if (typeof rayLeft != "number" || typeof rayRight != "number"
            || typeof rayTop != "number" || typeof rayBottom != "number" || typeof halfWidth != "number"
            || (rayLeft - rayLeft) != 0 || (rayRight - rayRight) != 0
            || (rayTop - rayTop) != 0 || (rayBottom - rayBottom) != 0
            || (halfWidth - halfWidth) != 0 || halfWidth < 0) return null;
        return {top:rayTop, bottom:rayBottom, halfWidth:halfWidth};
    }

    /**
     * 仅把 RayCollider 已有的 Y 宽相拒绝前移；原 checkCollision 仍是唯一窄相。
     * window 只来自本次扫描的 prepareRayYWindow。每个候选只证明目标的 C2/C3 和 Y/Z。
     * 未知类型/覆写 getAABB/非有限 Y 输入保守返回 false，不写共享 AABB/CollisionResult。
     */
    public static function rejectRayCandidateY(window:Object, target:Object, zOffset:Number):Boolean {
        if (window == null || target == null) return false;
        var proto:Object = target.__proto__;
        if (proto === AABBCollider.prototype || proto === CoverageAABBCollider.prototype) {
            if (target.getAABB !== AABBCollider.prototype.getAABB) return false;
        } else if (proto === RayCollider.prototype || proto === BandRayCollider.prototype) {
            if (target.getAABB !== RayCollider.prototype.getAABB) return false;
        } else return false;
        var otherTop:Number = target.top, otherBottom:Number = target.bottom;
        if (typeof otherTop != "number" || typeof otherBottom != "number" || typeof zOffset != "number"
            || (otherTop - otherTop) != 0 || (otherBottom - otherBottom) != 0 || (zOffset - zOffset) != 0) return false;
        // Preserve getAABB(zOffset) then Band expansion order, including strict grazing boundaries.
        var halfWidth:Number = window.halfWidth;
        var expandedTop:Number = (otherTop + zOffset) - halfWidth;
        var expandedBottom:Number = (otherBottom + zOffset) + halfWidth;
        if ((expandedTop - expandedTop) != 0 || (expandedBottom - expandedBottom) != 0) return false;
        return window.bottom <= expandedTop || window.top >= expandedBottom;
    }
    /**
     * 在单调非降数组 rightMaxValues 上执行二分查找，
     * 返回第一个满足 rightMaxValues[i] >= targetLeft 的索引。
     *
     * 用于跳过右边界前缀最大值 < targetLeft 的所有目标——
     * 这些目标的右边界全部在搜索窗口左侧，不可能碰撞。
     *
     * @param rightMax  cache.rightMaxValues（单调非降）
     * @param len       数组有效长度
     * @param targetLeft 搜索窗口左边界
     * @return 扫描起始索引（0 ≤ result ≤ len）
     */
    private static function bsearchScanStart(rightMax:Array,
                                              len:Number,
                                              targetLeft:Number):Number {
        if (rightMax == undefined) return 0;
        var lo:Number = 0;
        var hi:Number = len;
        while (lo < hi) {
            var mid:Number = (lo + hi) >> 1;
            if (rightMax[mid] < targetLeft) {
                lo = mid + 1;
            } else {
                hi = mid;
            }
        }
        return lo;
    }

    /**
     * 射线命中结算：闪避→伤害→事件→显示→特效
     *
     * 从 processRayBullets 的 4 个命中处理分支（pierce/single/chain/fork）
     * 中提取的公共管线。每次命中调用一次，单帧内最多约 pierceLimit 次，
     * 函数调用开销可忽略。
     *
     * @param ctx       命中上下文（_rayHitCtx，每发子弹入口初始化一次）
     *                  包含: bullet, shooter, result(CollisionResult),
     *                        flags, meleeMask, Dodge, Damage, FX
     * @param hitTarget 命中目标
     * @param hitX      命中点 X
     * @param hitY      命中点 Y
     * @param dmgMult   伤害乘数（穿透衰减/折射衰减等）
     * @param tEntry    射线参数 t（chain/fork 传 -1）
     * @param fireLegacyHitHook 本节点是否仍持有“首个真实命中”钩子资格
     * @return damageResult 对象；真实命中分类同步写入 ctx.actualHit，调用方不得重复解析结果。
     */
    private static function settleRayHit(
            ctx:Object, hitTarget:MovieClip,
            hitX:Number, hitY:Number,
            dmgMult:Number, tEntry:Number, fireLegacyHitHook:Boolean):Object {

        var bullet:Object = ctx.bullet;
        var shooter:MovieClip = ctx.shooter;
        var finalResult:CollisionResult = ctx.result;
        if (ctx.projectRay) RayVisualBridge.noteTarget(bullet, hitTarget); // 仅视觉拓扑，先于可能卸载目标的命中事件。

        // 更新复用命中几何（射线 caller 责任：成形 collisionResult 后透传给 settleHit）
        finalResult.overlapCenter.x = hitX;
        finalResult.overlapCenter.y = hitY;
        finalResult.overlapRatio = dmgMult;
        finalResult.tEntry = tEntry;

        // 闪避判定（射线 caller 自算 dodgeState，settleHit 不内算闪避）
        var dodgeState:String = (bullet.伤害类型 == "真伤") ? "未躲闪" :
            ctx.Dodge.calculateDodgeState(
                hitTarget,
                ctx.Dodge.calcDodgeResult(shooter, hitTarget, bullet.命中率),
                bullet
            );

        // 统一伤害结算核心（子弹命中-伤害双管线拆分 阶段2，与主循环共用同一 settleHit）：
        //   命中对象同步(幂等) → calculateDamage → hitCount+= → publish("hit")
        //   → kill/death(带 _killed 守卫，D1：修复射线原缺守卫导致的潜在重复击杀 / killStats 按 _name 膨胀)
        //   → triggerDisplay。FX 仍由本函数在下方逐命中点处理（D3）。
        var damageResult:Object = settleHit(
            ctx, hitTarget, finalResult, dmgMult, dodgeState, fireLegacyHitHook);

        // MISS 仍显示伤害数字，但绝不能播放单位命中特效；不要永久改写 bullet 标志，
        // 否则同一穿透/持久射线后续的真实命中也会被错误静音。
        if ((ctx.actualHit || damageResult === DamageResult.NULL)
                && bullet.shouldGeneratePostHitEffect) {
            ctx.FX.Effect(bullet.击中后子弹的效果, hitX, hitY, shooter._xscale, undefined, true);
        }

        return damageResult;
    }

    /**
     * 只允许命中前参数函数返回这些 scoped 字段；函数本身不得写目标、Buff、计时器、
     * MovieClip 或全局状态。返回值在 MISS/NULL 时回滚，真实命中时保留，因而既能让
     * 稀有旧弹保持“参数先于本次伤害”的数值合同，也不会把副作用泄漏到 MISS。
     */
    private static function applyPreHitDamageTransform(bullet:Object, hitTarget:MovieClip):Object {
        var transform:Function = bullet.命中前伤害参数函数;
        if (typeof transform != "function") return null;

        var overrides:Object = transform.call(bullet, hitTarget);
        if (!overrides) return null;

        var keys:Array = [];
        var previous:Object = {};
        for (var i:Number = 0; i < _preHitTransformKeys.length; i++) {
            var key:String = _preHitTransformKeys[i];
            if (overrides[key] !== undefined) {
                // FLAG_CHAIN 会把霰弹值编码成负数作为延迟消费账本；窗口内只允许
                // MultiShotDamageHandle 与 __commitDeferScatter 写入。稀有弹参数投影
                // 若覆盖该值，会同时破坏本次判定和最终提交，因此联弹窗口内忽略此项。
                if (key == "霰弹值" && Number(bullet.霰弹值) < -65535) continue;
                keys[keys.length] = key;
                previous[key] = bullet[key];
                bullet[key] = overrides[key];
            }
        }
        return keys.length > 0 ? {keys:keys, previous:previous} : null;
    }

    private static function restorePreHitDamageTransform(bullet:Object, receipt:Object):Void {
        if (!receipt) return;
        var keys:Array = receipt.keys;
        for (var i:Number = 0; i < keys.length; i++) {
            var key:String = keys[i];
            bullet[key] = receipt.previous[key];
        }
    }

    /**
     * 地图碰撞与单位真实命中使用不同能力。进入地图钩子前清掉最后一次单位几何
     * 引用，避免“单位 MISS 后同帧撞墙”把 target-dependent 旧钩子施加到闪避者。
     * 地图钩子只负责爆炸/消弹等弹体生命周期，异常不得截断统一终止收尾。
     */
    private static function fireMapHitHook(bullet:Object):Void {
        if (!bullet) return;
        bullet.hitTarget = null;
        bullet.命中对象 = null;
        var hook:Function = bullet.击中地图时触发函数;
        if (typeof hook != "function") return;
        try {
            hook.call(bullet);
        } catch (mapHookError) {
            trace("[BulletQueueProcessor] map hit hook failed: " + mapHookError);
        }
    }

    /** 新模式专用入口：预算/几何/身份守门先于 RNG、伤害与任何命中副作用。 */
    private static function settleShotgunHit(ctx:Object, hitTarget:MovieClip,
            collisionResult:Object, unitArea:Object, zOffset:Number):Object {
        var bullet:Object = ctx.bullet;
        var group:ChainGroup = bullet.chainGroup;
        if (!group.shotgun.prepareContact(group, hitTarget, unitArea, zOffset)) {
            ctx.actualHit = false;
            return null;
        }
        bullet.附加层伤害计算 = 0;
        bullet.hitTarget = hitTarget;
        bullet.命中对象 = hitTarget;
        var Dodge:Object = ctx.Dodge;
        var dodgeState:String = bullet.伤害类型 == "真伤" ? "未躲闪" :
            Dodge.calculateDodgeState(hitTarget,
                Dodge.calcDodgeResult(ctx.shooter, hitTarget, bullet.命中率), bullet);
        return settleHit(ctx, hitTarget, collisionResult, 1, dodgeState, true);
    }

    /**
     * 统一伤害结算。闪避仍由 caller 计算，附加层重置仍由 caller 决定；旧式
     * 击中时触发函数则在 DamageResult 证明至少一段真实命中后、hitBehavior/hit/kill
     * 之前执行。这样普通 MISS 与联弹全段 MISS 只留下数字，不再加 Buff、倒地、
     * 停弹、爆炸或修改后续目标。
     *
     * @param ctx              per-bullet 不变量容器（读 bullet/shooter/Damage/flags/meleeMask）
     * @param hitTarget        命中目标
     * @param collisionResult  已成形的命中几何，hit 事件透传（订阅者只读 overlapCenter）
     * @param dmgMult          独立伤害乘数：AABB=1 / polygon=overlapRatio / ray=衰减乘积
     * @param dodgeState       caller 已算好的闪避态（不在此重算）
     * @param fireLegacyHitHook 当前节点是否允许消费旧式 actual-hit 钩子
     *   注：tEntry 不入参——caller 形成 collisionResult 时已写入，本函数不读。
     */
    private static function settleHit(
            ctx:Object, hitTarget:MovieClip,
            collisionResult:Object, dmgMult:Number, dodgeState:String,
            fireLegacyHitHook:Boolean):Object {

        var bullet:Object = ctx.bullet;
        var shooter:MovieClip = ctx.shooter;

        // no-death 等价测试探针：生产恒 null 零开销；非 null 时录命中并短路（纯比对 selection）
        if (_raySettleProbe != null) {
            ctx.actualHit = false;
            _raySettleProbe(hitTarget, dmgMult);
            return null;
        }

        // 同步命中对象引用（幂等；caller 通常已设，供其 击中时触发函数 读取）
        bullet.hitTarget = hitTarget;
        bullet.命中对象 = hitTarget;

        // 只有 caller 仍持有旧式钩子资格时才应用纯参数投影；MISS/NULL 会在下方精确恢复。
        var transformReceipt:Object = null;
        if (fireLegacyHitHook && bullet.命中前伤害参数函数 != undefined) {
            transformReceipt = applyPreHitDamageTransform(bullet, hitTarget);
        }

        var damageResult:Object;
        if (!transformReceipt) {
            // 绝大多数子弹没有 scoped transform；保持 AVM1 命中热路不生成 ActionTry。
            if (bullet.hitBehavior != undefined) {
                BulletHitEffectRegistry.prepare(bullet, shooter, hitTarget);
            }
            damageResult = ctx.Damage.calculateDamage(
                bullet, shooter, hitTarget, dmgMult, dodgeState
            );
        } else {
            try {
                // 灰蛊的节点击溃/满层斩杀属于当前命中的动态属性，必须在 DamageManager 执行前配给。
                // 普通子弹无 hitBehavior，不进入注册表。
                if (bullet.hitBehavior != undefined) {
                    BulletHitEffectRegistry.prepare(bullet, shooter, hitTarget);
                }

                // 伤害计算
                damageResult = ctx.Damage.calculateDamage(
                    bullet, shooter, hitTarget, dmgMult, dodgeState
                );
            } catch (damageError) {
                // 参数投影是本次同步结算的局部事务；下游异常不能把半投影状态
                // 留给同一 MovieClip 的下一目标或下一帧。
                restorePreHitDamageTransform(bullet, transformReceipt);
                throw damageError;
            }
        }
        bullet.hitCount += damageResult.actualScatterUsed;

        // AVM1 热路刻意内联一次分类：不要改回 DamageResult.hasActualHit，也不要在下游
        // 重复解析。普通命中只付顺序属性比较；稀有普通/全段 MISS 立刻走冷分支返回。
        var actualHit:Boolean = damageResult !== DamageResult.NULL
            && damageResult.dodgeStatus != "MISS"
            && (damageResult.scatterModelEnabled !== true
                || damageResult.actualScatterUsed <= 0
                || damageResult.scatterMissCount < damageResult.actualScatterUsed);
        ctx.actualHit = actualHit;
        if (!actualHit) {
            restorePreHitDamageTransform(bullet, transformReceipt);
            if (damageResult !== DamageResult.NULL) {
                damageResult.triggerDisplay(hitTarget._x, hitTarget._y, hitTarget._name);
                return damageResult;
            }
        } else if (fireLegacyHitHook && bullet.击中时触发函数) {
            // 旧钩子的目标写、Buff、动画和状态提交只允许发生在真实命中；仍早于
            // hitBehavior.apply / hit / kill / display，保持消费者看到完整命中后状态。
            bullet.击中时触发函数();
        }

        // 有效命中在伤害结算后沉积层数；随后 HitUpdater 发布的 ToughnessBroken
        // 可为同一候选追加一次枪种等价命中。
        // 普通子弹没有该字段，不进入注册表，保持热路径成本接近零。
        if (actualHit && bullet.hitBehavior != undefined) {
            BulletHitEffectRegistry.apply(bullet, shooter, hitTarget, damageResult);
        }

        // 死亡类型在 hit 事件前取快照；injectHit 未来若误重入也不污染本次 kill/death 判定。
        var isNormalKill:Boolean = (ctx.flags & ctx.meleeMask) == 0;

        // 事件发布（collisionResult 透传，订阅者只读 overlapCenter）。
        // 稀有 resolved MISS 已在上方冷分支返回；这里仅剩真实命中与 NULL 几何命中。
        // HitUpdater/ImpactStateHandler 不再重复防守，旁路 producer 不得发布 resolved MISS。
        // DamageResult.NULL 仍承载无敌/UnitBullet 的旧几何命中合同。
        var targetDispatcher:Object = hitTarget.dispatcher;
        targetDispatcher.publish("hit", hitTarget, shooter, bullet, collisionResult, damageResult);

        // 死亡事件（_killed 守卫普适，D1：防 UnitBullet 重复 kill/death + killStats 按 _name 膨胀）
        if (hitTarget.hp <= 0 && !hitTarget._killed) {
            targetDispatcher.publish(isNormalKill ? "kill" : "death", hitTarget);
            shooter.dispatcher.publish("enemyKilled", hitTarget, bullet);
        }

        // 伤害数字显示
        damageResult.triggerDisplay(hitTarget._x, hitTarget._y, hitTarget._name);

        return damageResult;
    }

    /**
     * injectHit —— 旁路命中注入（公开 API，子弹命中-伤害双管线拆分 阶段3）。
     *
     * 不经几何检测，直接对指定目标结算"一次"命中（→ settleHit）。这是"命中/伤害分离"的
     * 直接消费形态（约束2/3）：命中由外部生产者**指定**而非几何扫描产出，伤害管线原样消费。
     *
     * 消费者：
     *  - 装备/技能层"锁定直伤"——替代 G1111 用 `区域定位area = autoTarget.area` + shootX/Y/Z
     *    伪造命中区域、靠 spawn 子弹蹭中锁定目标的 hack；
     *  - 锁定射击跨行首发——替代 `setRayFast` 重定向射线（z 远目标会令射线视觉露怯）；
     *  - 未来 C# 回灌（同一接口的外部消费者）。
     *
     * 设计契约：
     *  - **视觉无关**：不重定向射线、不 spawn 子弹、不动任何表现；命中点 (hitX,hitY) 仅供 hit 事件读。
     *  - **仅首发直结算**："后续机制"（chain/fork/穿透）由 caller 自行下一帧调度（时序可变更，见设计 §6.4）。
     *  - **不进影子记账窗口**：与射线侧同，bullet.霰弹值 须为正，MultiShotDamageHandle 走直接模式（§5.1 红线②）。
     *  - 用独立 `_injectCtx`（不碰主循环 _hitCtx）；复用 `_rayHitResult` 作 collisionResult（同步消费安全）。
     *  - **不可从 hit 订阅者同步重入 injectHit**：事件链内复用 collisionResult；需要追加命中时延迟到下一帧/producer 阶段。
     *
     * @param bullet   命中数据载体（含 calculateDamage/settleHit 读取的字段：伤害类型/命中率/子弹威力/
     *                 霰弹值/flags/hitCount 等；可为轻量 Object，不必是 MovieClip）。
     * @param shooter  发射者（须含 dispatcher，用于 enemyKilled）。
     * @param target   注入命中的目标（须含 hp/dispatcher/_x/_y/_name/_killed）。
     * @param hitX,hitY 命中点（写入 hit 事件 collisionResult.overlapCenter）。
     * @param dmgMult  伤害乘数（直伤通常 1；锁定可传衰减乘数）。
     * @param fireLegacyHitHook 是否允许本次真实命中消费旧式单位命中钩子；外部省略时为 false。
     * @return DamageResult；目标非法（自身 / 已死 / 防止无限飞）时返回 null，不结算。
     */
    public static function injectHit(bullet:Object, shooter:MovieClip, target:MovieClip,
                                     hitX:Number, hitY:Number, dmgMult:Number,
                                     fireLegacyHitHook:Boolean):Object {
        // 合法性兜底（§5.6：外部注入须自排自身，此处再守一道——hp>0 / 防止无限飞 / 非自身）
        if (target == bullet || !(target.hp > 0) || target.防止无限飞 == true) {
            _injectCtx.actualHit = false;
            return null;
        }

        // 近战/爆炸位掩码（与主循环/射线一致，经宏 include 注入；供 settleHit 内 isNormalKill 判定）
        #include "../macros/FLAG_MELEE.as"
        #include "../macros/FLAG_EXPLOSIVE.as"

        // per-call 不变量打包（独立 _injectCtx）
        var ctx:Object = _injectCtx;
        ctx.bullet = bullet;
        ctx.shooter = shooter;
        ctx.Damage = DamageCalculator;
        ctx.flags = bullet.flags | 0;
        ctx.meleeMask = FLAG_MELEE | FLAG_EXPLOSIVE;

        // 成形 collisionResult（复用静态 _rayHitResult；订阅者只读 overlapCenter）
        var cr:CollisionResult = _rayHitResult;
        cr.overlapCenter.x = hitX;
        cr.overlapCenter.y = hitY;
        cr.overlapRatio = dmgMult;

        // 闪避（injectHit 是入口，自算 dodgeState；经 Object 引用绕开 DodgeHandler 返回类型检查，与射线侧 ctx.Dodge 同）
        var Dodge:Object = DodgeHandler;
        var dodgeState:String = (bullet.伤害类型 == "真伤") ? "未躲闪" :
            Dodge.calculateDodgeState(
                target,
                Dodge.calcDodgeResult(shooter, target, bullet.命中率),
                bullet
            );

        return settleHit(ctx, target, cr, dmgMult, dodgeState, fireLegacyHitHook);
    }

    // ========================================================================
    // 射线子弹独立处理（不进入主碰撞循环）
    // ========================================================================

    /**
     * 处理所有待检测的射线子弹
     *
     * 射线子弹独立于主碰撞循环处理，原因：
     * 1. 射线子弹是单帧检测（发射即检测即销毁），不需要逐帧移动
     * 2. 独立处理避免主循环中每发常规子弹都承担 FLAG_RAY 分支检测开销
     *
     * 支持四种射线模式（由 TeslaRayConfig.rayMode 控制）：
     * - "single" (默认): 命中最近单目标
     * - "pierce": 穿透射线，命中路径上所有目标（按 tEntry 距离排序）
     * - "chain": 连锁弹跳，命中后从命中点搜索附近下一目标
     * - "fork": 分裂射线，命中后从命中点分裂出多条子射线
     *
     * 优化策略：
     * - 利用 cache.rightMaxValues（右边界前缀最大值，单调非降）二分查找起始索引
     * - 利用 cache.leftValues（左边界升序）右截断扫描窗口
     * - 复杂度从 O(T) 降低为 O(log T + W)，W = 碰撞窗口内目标数
     * - 使用 tEntry（Slab 算法输出）直接比较距离，消除 sqrt 和 dist² 开销
     * - 复用静态 _rayHitResult 传递命中数据，零分配
     *
     * 调用时机：processQueue() 中，主循环之前
     */
    private static function processRayBullets():Void {
        var rayList:Array = _rayBullets;
        var count:Number = rayList.length;
        if (count == 0) return;
        // _root.服务器.立即发送("[RAY-0] processRayBullets 入口 count=" + count);

        // === 宏展开：标志位常量 ===
        #include "../macros/STATE_FRIENDLY_FIRE.as"
        #include "../macros/FLAG_MELEE.as"
        #include "../macros/FLAG_EXPLOSIVE.as"

        var gameWorld:MovieClip = _root.gameworld;
        var debugMode:Boolean = _root.调试模式;
        var MELEE_EXPLOSIVE_MASK:Number = FLAG_MELEE | FLAG_EXPLOSIVE;
        var Dodge:Object = DodgeHandler;
        var Damage:Object = DamageCalculator;
        var FX:Object = EffectSystem;
        var DEG_TO_RAD:Number = Math.PI / 180;

        // deferral=B 持久射线存活集：本帧后仍存活的射线（pierce/chain 一期）重建回 _rayBullets
        var survivors:Array = _raySurvivors;
        survivors.length = 0;

        // 遍历所有待处理射线子弹
        for (var i:Number = 0; i < count; i++) {
            var bullet:Object = rayList[i];
            var projectRay:Boolean = !org.flashNight.arki.render.WorkerProjectionPolicy.isNone("ray");
            var shooter:MovieClip = gameWorld[bullet.发射者名];
            if (shooter == null) {
                bullet.removeMovieClip();
                continue;
            }

            // 射线子弹绕过主循环，需手动初始化效果标志
            // （主循环中此标志在每发子弹处理前设置为 true）
            bullet.shouldGeneratePostHitEffect = true;

            // ---- 阵营判定 + 目标缓存获取 ----
            var sf:Number = bullet.stateFlags | 0;
            var isFriendlyFire:Boolean = (sf & STATE_FRIENDLY_FIRE) != 0;
            var queueKey:String = isFriendlyFire ? FRIENDLY_FIRE_KEY :
                FactionManager.getFactionFromUnit(shooter);
            var fakeUnit:Object = fakeUnits[queueKey];
            var cache:Object;
            if (queueKey == FRIENDLY_FIRE_KEY) {
                cache = TargetCacheManager.acquireAllCache(fakeUnit, 1);
            } else {
                cache = TargetCacheManager.acquireEnemyCache(fakeUnit, 1);
            }

            var unitMap:Array = cache.data;
            var unitLen:Number = unitMap.length;

            // ---- 射线碰撞参数 ----
            var areaAABB:AABBCollider = bullet.aabbCollider;
            var rayOriginX:Number = bullet._x;
            var rayOriginY:Number = bullet._y;
            var bulletZOffset:Number = bullet.Z轴坐标;
            var bulletZRange:Number = bullet.Z轴攻击范围 || 50;
            // 注：带宽射线只放宽【屏幕-Y】命中（BandRayCollider.checkCollision 的 ±半宽，治矮碰撞箱），
            // 【不】碰深度门——深度对齐由战斗 AI 保证（zoff≈0 恒过门；实测日志 rat zoff≤23<42）。
            // 早期曾把半宽并入此门（误判矮敌=深度问题），日志证伪后回退：深度与屏幕-Y 是正交两道滤镜。
            var flags:Number = bullet.flags | 0;

            // ---- 射线模式判定 ----
            var config:TeslaRayConfig = TeslaRayConfig(bullet.rayConfig);
            var rayMode:String = (config != null && config.rayMode != undefined)
                ? config.rayMode : "single";
            var rayModeMask:Number = (config != null && config.rayModeMask != undefined)
                ? config.rayModeMask : 0;

            // 目标数量从 bullet.pierceLimit 读取（与普通子弹共用 <attribute> 层字段）
            // 射线子弹不进入主循环，不会与普通穿透机制冲突
            // undefined/NaN → 默认 1（single 行为）
            var bulletPierceLimit:Number = bullet.pierceLimit;
            if (!(bulletPierceLimit > 0)) bulletPierceLimit = 1;

            // ---- 利用有序缓存进行窗口裁剪 ----
            // cache.leftValues 按 X 升序排列，rightMaxValues 是右边界前缀最大值（单调非降）
            // 射线 AABB 水平范围 [rayLeft, rayRight] 定义碰撞窗口
            var rayLeft:Number = areaAABB.left;
            var rayRight:Number = areaAABB.right;
            var unitLeftKeys:Array = cache.leftValues;
            var unitRightMax:Array = cache.rightMaxValues;

            // 二分查找起始索引：跳过右边界全部在射线左侧的目标
            var lo:Number; // 持久射线由其扫描函数独立定位，避免先做一次未使用的二分。

            // 复用静态命中结果（同步事件处理保证安全）
            var finalResult:CollisionResult = _rayHitResult;

            // 初始化命中上下文（每发子弹不变的参数打包，settleRayHit 13→6 参数）
            var ctx:Object = _rayHitCtx;
            ctx.bullet = bullet;
            ctx.projectRay = projectRay;
            ctx.shooter = shooter;
            ctx.result = finalResult;
            ctx.flags = flags;
            ctx.meleeMask = MELEE_EXPLOSIVE_MASK;
            ctx.Dodge = Dodge;
            ctx.Damage = Damage;
            ctx.FX = FX;

            // === deferral=B 持久射线（pierce / chain / combo 组合）===
            // 把每帧扫描所需的窗口/几何/配置打包进 ctx，交给 processPersistentRay 贪心推进。
            // single / 纯 fork 仍走下方旧批量路（single 一帧即结无需持久；纯 fork 暂未纳入）。
            ctx.unitMap = unitMap;
            ctx.unitLen = unitLen;
            ctx.unitLeftKeys = unitLeftKeys;
            ctx.unitRightMax = unitRightMax;
            ctx.areaAABB = areaAABB;
            ctx.rayOriginX = rayOriginX;
            ctx.rayOriginY = rayOriginY;
            ctx.bulletZOffset = bulletZOffset;
            ctx.bulletZRange = bulletZRange;
            ctx.config = config;
            ctx.rayMode = rayMode;
            ctx.pierceLimit = bulletPierceLimit;
            var persistentCombo:Boolean = (config != null && config.isCombo() && config.hasPierce());
            var isFlameMode:Boolean = (config != null && (rayMode == "flame" || config.hasFlame()));
            if (_rayPersistent && config != null && !isFlameMode && (persistentCombo || rayMode == "pierce" || rayMode == "chain")) {
                if (processPersistentRay(ctx)) {
                    survivors[survivors.length] = bullet;   // 跨帧存活，保留在 _rayBullets
                } else {
                    bullet.removeMovieClip();                // 结束（budget 耗尽 / 本帧无命中）→ 销毁
                }
                continue;   // 跳过批量 lockon 块 + 模式分派 + 末尾 removeMovieClip
            }

            lo = bsearchScanStart(unitRightMax, unitLen, rayLeft);

            // ---- Lockon 目标解析 ----
            // 【契约】lockonTarget 由武器层通过 TargetCacheManager 选靶，
            //  缓存已保证 hp>0 且 防止无限飞!=true。此处不重复校验（契约大于防护）。
            //  若 aabbCollider 为 null → AABB 算术产生 NaN → lockonDistSq 比较失败
            //  → isLockon 保持 false → 自然 fallback 到几何模式（AS2 NaN 比较返回 falsy）。
            var lockonTarget:MovieClip = bullet.lockonTarget;
            var isLockon:Boolean = false;
            var lockonHitX:Number;
            var lockonHitY:Number;
            var lockonTEntry:Number;

            if (lockonTarget != null) {
                var ltAABB:AABBCollider = lockonTarget.aabbCollider;
                lockonHitX = (ltAABB.left + ltAABB.right) * 0.5;
                lockonHitY = (ltAABB.top + ltAABB.bottom) * 0.5;
                var lockonDirX:Number = lockonHitX - rayOriginX;
                var lockonDirY:Number = lockonHitY - rayOriginY;
                var lockonDistSq:Number = lockonDirX * lockonDirX + lockonDirY * lockonDirY;
                if (lockonDistSq > 0.001) {
                    isLockon = true;
                    lockonTEntry = Math.sqrt(lockonDistSq);
                    // 更新 RayCollider 方向（用于 pierce 几何扫描）
                    // setRayFast 内部归一化方向 + 重算 AABB bounds
                    // areaAABB 编译期类型 AABBCollider，运行时实际 RayCollider 子类
                    // 索引记法绕过编译期方法检查
                    areaAABB["setRayFast"](rayOriginX, rayOriginY,
                        lockonDirX, lockonDirY, config.rayLength || 900);
                    // 重算窗口边界
                    rayLeft = areaAABB.left;
                    rayRight = areaAABB.right;
                    lo = bsearchScanStart(unitRightMax, unitLen, rayLeft);
                }
            }

            // 预计算射线角度（VFX 终点用），非 lockon 时值等于原 bullet._rotation * DEG_TO_RAD
            var resolvedRayAngle:Number = isLockon
                ? Math.atan2(lockonDirY, lockonDirX)
                : (bullet._rotation * DEG_TO_RAD);

            // lockon 距离衰减乘数（武器层设置，默认 1 = 无衰减）
            var lockonDmgMult:Number = (isLockon && bullet.lockonDmgMult) ? bullet.lockonDmgMult : 1;

            ctx.resolvedRayAngle = resolvedRayAngle;
            if (_rayPersistent && isFlameMode) {
                // 射线子弹是透明 Object；_rotation 只是 BulletFactory 写入的 MovieClip 兼容字段。
                // 火焰 VFX 使用队列本轮解析出的方向，避免未来重定向逻辑与视觉终点分叉。
                if (isLockon) {
                    ctx.resolvedRayDirX = lockonDirX / lockonTEntry;
                    ctx.resolvedRayDirY = lockonDirY / lockonTEntry;
                } else {
                    ctx.resolvedRayDirX = Math.cos(resolvedRayAngle);
                    ctx.resolvedRayDirY = Math.sin(resolvedRayAngle);
                }

                var flameAlive:Boolean = processContinuousFlame(ctx);
                ctx.resolvedRayDirX = undefined;
                ctx.resolvedRayDirY = undefined;

                if (flameAlive) {
                    survivors[survivors.length] = bullet;   // 喷火短寿命存活，下一帧继续扫描/缩放
                } else {
                    bullet.removeMovieClip();
                }
                continue;
            }

            // ================================================================
            // 组合模式：多个能力位同时置位时走此分支（isCombo）
            // hasPierce → per-node 管道（逐穿透节点触发 chain/fork）
            // !hasPierce → per-phase 管道（chain+fork 从 hit₁ 触发）
            // ================================================================
            if (config != null && config.isCombo()) {
                var MASK_P:Number = TeslaRayConfig.MASK_PIERCE;
                var MASK_C:Number = TeslaRayConfig.MASK_CHAIN;
                var MASK_F:Number = TeslaRayConfig.MASK_FORK;
                var comboMask:Number = rayModeMask;
                var budget:Number = bulletPierceLimit; // 共享名额池
                var globalVisited:Object = {};         // 全局去重

            if (config.hasPierce()) {
                // ================================================================
                // per-node 管道：pierce + chain/fork
                // 沿穿透路径逐节点触发 chain/fork，分支效果均匀分布在射线上
                // ================================================================
                var wantChain:Boolean = (comboMask & MASK_C) != 0;
                var wantFork:Boolean  = (comboMask & MASK_F) != 0;

                // ══════ Phase 0：扫描所有碰撞，收集 allHits（按 tEntry 升序） ══════
                var comboAllHits:Array = null;
                var comboAllLen:Number = 0;

                for (var cu0:Number = lo; cu0 < unitLen && unitLeftKeys[cu0] <= rayRight; cu0++) {
                    var ct0:MovieClip = unitMap[cu0];
                    var cz0:Number = bulletZOffset - ct0.Z轴坐标;
                    if (cz0 >= bulletZRange || cz0 <= -bulletZRange) continue;

                    if (ct0.hp > 0 && ct0.防止无限飞 != true) {
                        var ca0:AABBCollider = ct0.aabbCollider;
                        var cr0:Object = areaAABB.checkCollision(ca0, cz0);

                        if (cr0.isColliding) {
                            var cte0:Number = cr0.tEntry;
                            if (comboAllHits == null) comboAllHits = [];
                            var cNewHit:Object = {
                                target: ct0,
                                hitX: cr0.overlapCenter.x,
                                hitY: cr0.overlapCenter.y,
                                tEntry: cte0,
                                zOffset: cz0
                            };
                            // 插入排序（按 tEntry 升序）
                            var cInsPos:Number = comboAllLen;
                            for (var cip:Number = comboAllLen - 1; cip >= 0; cip--) {
                                if (comboAllHits[cip].tEntry > cte0) {
                                    comboAllHits[cip + 1] = comboAllHits[cip];
                                    cInsPos = cip;
                                } else {
                                    break;
                                }
                            }
                            comboAllHits[cInsPos] = cNewHit;
                            comboAllLen++;
                        }
                    }
                }

                // ---- Lockon 注入（combo pierce）----
                if (isLockon) {
                    var ltFoundA:Boolean = false;
                    for (var lti:Number = 0; lti < comboAllLen; lti++) {
                        if (comboAllHits[lti].target == lockonTarget) {
                            ltFoundA = true;
                            break;
                        }
                    }
                    if (!ltFoundA) {
                        if (comboAllHits == null) comboAllHits = [];
                        var ltInsPos:Number = comboAllLen;
                        for (var ltk:Number = comboAllLen - 1; ltk >= 0; ltk--) {
                            if (comboAllHits[ltk].tEntry > lockonTEntry) {
                                comboAllHits[ltk + 1] = comboAllHits[ltk];
                                ltInsPos = ltk;
                            } else break;
                        }
                        comboAllHits[ltInsPos] = {
                            target: lockonTarget,
                            hitX: lockonHitX, hitY: lockonHitY,
                            tEntry: lockonTEntry,
                            zOffset: bulletZOffset - lockonTarget.Z轴坐标
                        };
                        comboAllLen++;
                    }
                }

                if (comboAllHits != null && comboAllLen > 0) {
                    bullet.附加层伤害计算 = 0;
                    var pnLegacyHookDone:Boolean = false;

                    var pnFalloff:Number = config.damageFalloff;
                    var pnDmgMult:Number = 1.0;
                    var pnHitPoints:Array = projectRay ? [] : null;
                    var pnHitCount:Number = 0, pnLastHitX:Number = 0, pnLastHitY:Number = 0;
                    var pnChainRadius:Number = config.chainRadius;
                    var pnChainRadiusSq:Number = pnChainRadius * pnChainRadius;
                    var pnChainIdx:Number = 0; // chain 段全局编号
                    var pnForkIdx:Number = 0;  // fork 段全局编号

                    // ══════ 逐节点 pipeline ══════
                    for (var ni:Number = 0; ni < comboAllLen; ni++) {
                        var nodeHit:Object = comboAllHits[ni];
                        if (globalVisited[nodeHit.target._name] == true) continue;
                        if (budget <= 0) break;

                        // ── pierce 命中处理 ──
                        globalVisited[nodeHit.target._name] = true;
                        budget--;

                        settleRayHit(ctx, nodeHit.target,
                            nodeHit.hitX, nodeHit.hitY, pnDmgMult, nodeHit.tEntry,
                            !pnLegacyHookDone);
                        if (!pnLegacyHookDone && ctx.actualHit) {
                            pnLegacyHookDone = true;
                        }
                        pnHitCount++; pnLastHitX = nodeHit.hitX; pnLastHitY = nodeHit.hitY;
                        if (projectRay) pnHitPoints.push({x: nodeHit.hitX, y: nodeHit.hitY});
                        pnDmgMult *= pnFalloff;

                        // ── chain 子阶段：从当前穿透节点开始连锁弹跳 ──
                        if (wantChain && budget > 0) {
                            var ccDmgMult:Number = pnDmgMult; // 继承当前衰减后的倍率
                            var ccPrevX:Number = nodeHit.hitX;
                            var ccPrevY:Number = nodeHit.hitY;
                            var ccPrevZ:Number = nodeHit.target.Z轴坐标;

                            for (var cci:Number = 0; budget > 0; cci++) {
                                var ccSearchL:Number = ccPrevX - pnChainRadius;
                                var ccSearchR:Number = ccPrevX + pnChainRadius;
                                var ccLo:Number = bsearchScanStart(unitRightMax, unitLen, ccSearchL);

                                var ccBestDistSq:Number = pnChainRadiusSq;
                                var ccBestTarget:MovieClip = null;
                                var ccBestX:Number = 0;
                                var ccBestY:Number = 0;

                                for (var ccu:Number = ccLo; ccu < unitLen && unitLeftKeys[ccu] <= ccSearchR; ccu++) {
                                    var ccT:MovieClip = unitMap[ccu];
                                    if (globalVisited[ccT._name] == true) continue;
                                    var ccZOff:Number = ccPrevZ - ccT.Z轴坐标;
                                    if (ccZOff >= bulletZRange || ccZOff <= -bulletZRange) continue;

                                    if (ccT.hp > 0 && ccT.防止无限飞 != true) {
                                        var ccAABB:AABBCollider = ccT.aabbCollider;
                                        var ccCX:Number = (ccAABB.left + ccAABB.right) * 0.5;
                                        var ccCY:Number = (ccAABB.top + ccAABB.bottom) * 0.5;
                                        var ccdx:Number = ccCX - ccPrevX;
                                        var ccdy:Number = ccCY - ccPrevY;
                                        var ccDSq:Number = ccdx * ccdx + ccdy * ccdy;

                                        if (ccDSq < ccBestDistSq) {
                                            ccBestDistSq = ccDSq;
                                            ccBestTarget = ccT;
                                            ccBestX = ccCX;
                                            ccBestY = ccCY;
                                        }
                                    }
                                }

                                if (ccBestTarget == null) break; // 链断裂

                                globalVisited[ccBestTarget._name] = true;
                                budget--;

                                settleRayHit(ctx, ccBestTarget,
                                    ccBestX, ccBestY, ccDmgMult, -1, !pnLegacyHookDone);
                                if (!pnLegacyHookDone && ctx.actualHit) {
                                    pnLegacyHookDone = true;
                                }

                                if (projectRay) {
                                    var ccMeta:Object = {
                                        segmentKind: "chain",
                                        hitIndex: pnChainIdx,
                                        intensity: ccDmgMult,
                                        isHit: true,
                                        parentEndX: ccPrevX,
                                        parentEndY: ccPrevY
                                    };
                                    RayVfxManager.spawnForBullet(bullet, ccPrevX, ccPrevY,
                                        ccBestX, ccBestY, config, ccMeta);
                                }
                                pnChainIdx++;

                                ccPrevX = ccBestX;
                                ccPrevY = ccBestY;
                                ccPrevZ = ccBestTarget.Z轴坐标;
                                ccDmgMult *= pnFalloff;
                            }
                        }

                        // ── fork 子阶段：从当前穿透节点搜索近邻分裂 ──
                        if (wantFork && budget > 0) {
                            var cfRefZ:Number = nodeHit.target.Z轴坐标;
                            var cfSearchL:Number = nodeHit.hitX - pnChainRadius;
                            var cfSearchR:Number = nodeHit.hitX + pnChainRadius;
                            var cfLo:Number = bsearchScanStart(unitRightMax, unitLen, cfSearchL);

                            // 收集前 budget 近的未命中目标
                            var cfHits:Array = [];
                            var cfLen:Number = 0;
                            var cfMaxCount:Number = budget;

                            for (var cfu:Number = cfLo; cfu < unitLen && unitLeftKeys[cfu] <= cfSearchR; cfu++) {
                                var cfT:MovieClip = unitMap[cfu];
                                if (globalVisited[cfT._name] == true) continue;
                                var cfZOff:Number = cfRefZ - cfT.Z轴坐标;
                                if (cfZOff >= bulletZRange || cfZOff <= -bulletZRange) continue;

                                if (cfT.hp > 0 && cfT.防止无限飞 != true) {
                                    var cfAABB:AABBCollider = cfT.aabbCollider;
                                    var cfCX:Number = (cfAABB.left + cfAABB.right) * 0.5;
                                    var cfCY:Number = (cfAABB.top + cfAABB.bottom) * 0.5;
                                    var cfdx:Number = cfCX - nodeHit.hitX;
                                    var cfdy:Number = cfCY - nodeHit.hitY;
                                    var cfDSq:Number = cfdx * cfdx + cfdy * cfdy;

                                    if (cfDSq < pnChainRadiusSq) {
                                        if (cfLen < cfMaxCount || cfDSq < cfHits[cfLen - 1].distSq) {
                                            var cfNewHit:Object = {
                                                target: cfT,
                                                centerX: cfCX,
                                                centerY: cfCY,
                                                distSq: cfDSq
                                            };
                                            var cfInsPos:Number = cfLen;
                                            if (cfInsPos > 0) {
                                                var cfScanStart:Number = (cfLen >= cfMaxCount) ? cfLen - 2 : cfLen - 1;
                                                for (var cfpi:Number = cfScanStart; cfpi >= 0; cfpi--) {
                                                    if (cfHits[cfpi].distSq > cfDSq) {
                                                        cfHits[cfpi + 1] = cfHits[cfpi];
                                                        cfInsPos = cfpi;
                                                    } else {
                                                        break;
                                                    }
                                                }
                                            }
                                            cfHits[cfInsPos] = cfNewHit;
                                            if (cfLen < cfMaxCount) cfLen++;
                                        }
                                    }
                                }
                            }

                            // 对每个 fork 目标造成伤害 + 渲染
                            for (var cfk:Number = 0; cfk < cfLen; cfk++) {
                                var cfh:Object = cfHits[cfk];
                                var cfhTarget:MovieClip = cfh.target;

                                // chain 子阶段可能已命中此目标
                                if (globalVisited[cfhTarget._name] == true) continue;

                                globalVisited[cfhTarget._name] = true;
                                budget--;

                                settleRayHit(ctx, cfhTarget,
                                    cfh.centerX, cfh.centerY, pnDmgMult, -1, !pnLegacyHookDone);
                                if (!pnLegacyHookDone && ctx.actualHit) {
                                    pnLegacyHookDone = true;
                                }

                                if (projectRay) {
                                    var cfMeta:Object = {
                                        segmentKind: "fork",
                                        hitIndex: pnForkIdx,
                                        intensity: pnDmgMult,
                                        isHit: true,
                                        parentEndX: nodeHit.hitX,
                                        parentEndY: nodeHit.hitY
                                    };
                                    RayVfxManager.spawnForBullet(bullet, nodeHit.hitX, nodeHit.hitY,
                                        cfh.centerX, cfh.centerY, config, cfMeta);
                                }
                                pnForkIdx++;

                                if (budget <= 0) break;
                            }
                        }
                    } // end per-node loop

                    // ══════ pierce VFX segment：一条覆盖全射线 ══════
                    var rayAngle:Number = resolvedRayAngle;
                    var rayLength:Number = (config != null && !isNaN(config.rayLength))
                        ? config.rayLength : 900;
                    var rayEndX:Number = rayOriginX + Math.cos(rayAngle) * rayLength;
                    var rayEndY:Number = rayOriginY + Math.sin(rayAngle) * rayLength;

                    // 预算耗尽时射线截止到最后一个穿透命中点
                    if (budget <= 0 && pnHitCount > 0) {
                        rayEndX = pnLastHitX;
                        rayEndY = pnLastHitY;
                    }

                    if (projectRay) {
                        var pnPierceMeta:Object = {
                            segmentKind: "pierce",
                            hitIndex: 0,
                            intensity: 1.0,
                            isHit: pnHitPoints.length > 0,
                            hitPoints: pnHitPoints.length > 0 ? pnHitPoints : null
                        };
                        RayVfxManager.spawnForBullet(bullet, rayOriginX, rayOriginY,
                            rayEndX, rayEndY, config, pnPierceMeta);
                    }

                    // 射线到达全长时播放地图命中效果
                    if (budget > 0) {
                        FX.Effect(bullet.击中地图效果, rayEndX, rayEndY, shooter._xscale, undefined, true);
                    }

                } else {
                    // per-node 未命中：射线打到最远处
                    var rayAngle:Number = resolvedRayAngle;
                    var rayLength:Number = (config != null && !isNaN(config.rayLength))
                        ? config.rayLength : 900;
                    var rayEndX:Number = rayOriginX + Math.cos(rayAngle) * rayLength;
                    var rayEndY:Number = rayOriginY + Math.sin(rayAngle) * rayLength;

                    FX.Effect(bullet.击中地图效果, rayEndX, rayEndY, shooter._xscale, undefined, true);
                    if (projectRay) {
                        var pnMissMeta:Object = {
                            segmentKind: "pierce",
                            hitIndex: 0,
                            intensity: 1.0,
                            isHit: false,
                            hitPoints: null
                        };
                        RayVfxManager.spawnForBullet(bullet, rayOriginX, rayOriginY,
                            rayEndX, rayEndY, config, pnMissMeta);
                    }
                }

            } else {
                // ================================================================
                // per-phase 管道：chain + fork（无 pierce）
                // 从 hit₁ 触发 chain → fork，适用于 chain+fork 组合
                // ================================================================

                // ══════ 扫描找最近命中 ══════
                var comboNearestTEntry:Number = Infinity;
                var comboNearestTarget:MovieClip = null;
                var comboNearestHitX:Number = 0;
                var comboNearestHitY:Number = 0;

                for (var cu0:Number = lo; cu0 < unitLen && unitLeftKeys[cu0] <= rayRight; cu0++) {
                    var ct0:MovieClip = unitMap[cu0];
                    var cz0:Number = bulletZOffset - ct0.Z轴坐标;
                    if (cz0 >= bulletZRange || cz0 <= -bulletZRange) continue;

                    if (ct0.hp > 0 && ct0.防止无限飞 != true) {
                        var ca0:AABBCollider = ct0.aabbCollider;
                        var cr0:Object = areaAABB.checkCollision(ca0, cz0);

                        if (cr0.isColliding && cr0.tEntry < comboNearestTEntry) {
                            comboNearestTEntry = cr0.tEntry;
                            comboNearestTarget = ct0;
                            comboNearestHitX = cr0.overlapCenter.x;
                            comboNearestHitY = cr0.overlapCenter.y;
                        }
                    }
                }

                // ---- Lockon 覆盖（combo no-pierce）----
                if (isLockon && comboNearestTarget != lockonTarget) {
                    comboNearestTarget = lockonTarget;
                    comboNearestHitX = lockonHitX;
                    comboNearestHitY = lockonHitY;
                    comboNearestTEntry = lockonTEntry;
                }

                if (comboNearestTarget != null) {
                    budget--;
                    globalVisited[comboNearestTarget._name] = true;

                    bullet.附加层伤害计算 = 0;
                    var comboLegacyHookDone:Boolean = false;
                    settleRayHit(ctx, comboNearestTarget,
                        comboNearestHitX, comboNearestHitY, 1, comboNearestTEntry, true);
                    if (ctx.actualHit) comboLegacyHookDone = true;

                    if (projectRay) {
                        var comboMainMeta:Object = {
                            segmentKind: "main",
                            hitIndex: 0,
                            intensity: 1.0,
                            isHit: true
                        };
                        RayVfxManager.spawnForBullet(bullet, rayOriginX, rayOriginY,
                            comboNearestHitX, comboNearestHitY, config, comboMainMeta);
                    }

                    // ══════ chain 连锁（从 hit₁ 开始弹跳） ══════
                    if ((comboMask & MASK_C) != 0 && budget > 0) {
                        var ccRadius:Number = config.chainRadius;
                        var ccFalloff:Number = config.damageFalloff;
                        var ccRadiusSq:Number = ccRadius * ccRadius;
                        var ccDmgMult:Number = ccFalloff;
                        var ccPrevX:Number = comboNearestHitX;
                        var ccPrevY:Number = comboNearestHitY;
                        var ccPrevZ:Number = comboNearestTarget.Z轴坐标;

                        for (var cci:Number = 0; budget > 0; cci++) {
                            var ccSearchL:Number = ccPrevX - ccRadius;
                            var ccSearchR:Number = ccPrevX + ccRadius;
                            var ccLo:Number = bsearchScanStart(unitRightMax, unitLen, ccSearchL);

                            var ccBestDistSq:Number = ccRadiusSq;
                            var ccBestTarget:MovieClip = null;
                            var ccBestX:Number = 0;
                            var ccBestY:Number = 0;

                            for (var ccu:Number = ccLo; ccu < unitLen && unitLeftKeys[ccu] <= ccSearchR; ccu++) {
                                var ccT:MovieClip = unitMap[ccu];
                                if (globalVisited[ccT._name] == true) continue;
                                var ccZOff:Number = ccPrevZ - ccT.Z轴坐标;
                                if (ccZOff >= bulletZRange || ccZOff <= -bulletZRange) continue;

                                if (ccT.hp > 0 && ccT.防止无限飞 != true) {
                                    var ccAABB:AABBCollider = ccT.aabbCollider;
                                    var ccCX:Number = (ccAABB.left + ccAABB.right) * 0.5;
                                    var ccCY:Number = (ccAABB.top + ccAABB.bottom) * 0.5;
                                    var ccdx:Number = ccCX - ccPrevX;
                                    var ccdy:Number = ccCY - ccPrevY;
                                    var ccDSq:Number = ccdx * ccdx + ccdy * ccdy;

                                    if (ccDSq < ccBestDistSq) {
                                        ccBestDistSq = ccDSq;
                                        ccBestTarget = ccT;
                                        ccBestX = ccCX;
                                        ccBestY = ccCY;
                                    }
                                }
                            }

                            if (ccBestTarget == null) break; // 链断裂

                            globalVisited[ccBestTarget._name] = true;
                            budget--;

                            settleRayHit(ctx, ccBestTarget,
                                ccBestX, ccBestY, ccDmgMult, -1, !comboLegacyHookDone);
                            if (!comboLegacyHookDone && ctx.actualHit) {
                                comboLegacyHookDone = true;
                            }

                            if (projectRay) {
                                var ccMeta:Object = {
                                    segmentKind: "chain",
                                    hitIndex: cci + 1,
                                    intensity: ccDmgMult,
                                    isHit: true,
                                    parentEndX: ccPrevX,
                                    parentEndY: ccPrevY
                                };
                                RayVfxManager.spawnForBullet(bullet, ccPrevX, ccPrevY,
                                    ccBestX, ccBestY, config, ccMeta);
                            }

                            ccPrevX = ccBestX;
                            ccPrevY = ccBestY;
                            ccPrevZ = ccBestTarget.Z轴坐标;
                            ccDmgMult *= ccFalloff;
                        }
                    }

                    // ══════ fork 分裂（仅从 hit₁ 发射） ══════
                    if ((comboMask & MASK_F) != 0 && budget > 0) {
                        var cfRadius:Number = config.chainRadius;
                        var cfFalloff:Number = config.damageFalloff;
                        var cfRadiusSq:Number = cfRadius * cfRadius;
                        var cfRefZ:Number = comboNearestTarget.Z轴坐标;

                        var cfSearchL:Number = comboNearestHitX - cfRadius;
                        var cfSearchR:Number = comboNearestHitX + cfRadius;
                        var cfLo:Number = bsearchScanStart(unitRightMax, unitLen, cfSearchL);

                        var cfHits:Array = [];
                        var cfLen:Number = 0;
                        var cfMaxCount:Number = budget;

                        for (var cfu:Number = cfLo; cfu < unitLen && unitLeftKeys[cfu] <= cfSearchR; cfu++) {
                            var cfT:MovieClip = unitMap[cfu];
                            if (globalVisited[cfT._name] == true) continue;
                            var cfZOff:Number = cfRefZ - cfT.Z轴坐标;
                            if (cfZOff >= bulletZRange || cfZOff <= -bulletZRange) continue;

                            if (cfT.hp > 0 && cfT.防止无限飞 != true) {
                                var cfAABB:AABBCollider = cfT.aabbCollider;
                                var cfCX:Number = (cfAABB.left + cfAABB.right) * 0.5;
                                var cfCY:Number = (cfAABB.top + cfAABB.bottom) * 0.5;
                                var cfdx:Number = cfCX - comboNearestHitX;
                                var cfdy:Number = cfCY - comboNearestHitY;
                                var cfDSq:Number = cfdx * cfdx + cfdy * cfdy;

                                if (cfDSq < cfRadiusSq) {
                                    if (cfLen < cfMaxCount || cfDSq < cfHits[cfLen - 1].distSq) {
                                        var cfNewHit:Object = {
                                            target: cfT,
                                            centerX: cfCX,
                                            centerY: cfCY,
                                            distSq: cfDSq
                                        };
                                        var cfInsPos:Number = cfLen;
                                        if (cfInsPos > 0) {
                                            var cfScanStart:Number = (cfLen >= cfMaxCount) ? cfLen - 2 : cfLen - 1;
                                            for (var cfpi:Number = cfScanStart; cfpi >= 0; cfpi--) {
                                                if (cfHits[cfpi].distSq > cfDSq) {
                                                    cfHits[cfpi + 1] = cfHits[cfpi];
                                                    cfInsPos = cfpi;
                                                } else {
                                                    break;
                                                }
                                            }
                                        }
                                        cfHits[cfInsPos] = cfNewHit;
                                        if (cfLen < cfMaxCount) cfLen++;
                                    }
                                }
                            }
                        }

                        for (var cfk:Number = 0; cfk < cfLen; cfk++) {
                            var cfh:Object = cfHits[cfk];
                            var cfhTarget:MovieClip = cfh.target;

                            if (globalVisited[cfhTarget._name] == true) continue;

                            globalVisited[cfhTarget._name] = true;
                            budget--;

                            settleRayHit(ctx, cfhTarget,
                                cfh.centerX, cfh.centerY, cfFalloff, -1, !comboLegacyHookDone);
                            if (!comboLegacyHookDone && ctx.actualHit) {
                                comboLegacyHookDone = true;
                            }

                            if (projectRay) {
                                var cfMeta:Object = {
                                    segmentKind: "fork",
                                    hitIndex: cfk,
                                    intensity: cfFalloff,
                                    isHit: true,
                                    parentEndX: comboNearestHitX,
                                    parentEndY: comboNearestHitY
                                };
                                RayVfxManager.spawnForBullet(bullet, comboNearestHitX, comboNearestHitY,
                                    cfh.centerX, cfh.centerY, config, cfMeta);
                            }

                            if (budget <= 0) break;
                        }
                    }

                } else {
                    // per-phase 未命中：射线打到最远处
                    var rayAngle:Number = resolvedRayAngle;
                    var rayLength:Number = (config != null && !isNaN(config.rayLength))
                        ? config.rayLength : 900;
                    var rayEndX:Number = rayOriginX + Math.cos(rayAngle) * rayLength;
                    var rayEndY:Number = rayOriginY + Math.sin(rayAngle) * rayLength;

                    FX.Effect(bullet.击中地图效果, rayEndX, rayEndY, shooter._xscale, undefined, true);
                    if (projectRay) {
                        var comboMissMeta:Object = {
                            segmentKind: "main",
                            hitIndex: 0,
                            intensity: 1.0,
                            isHit: false
                        };
                        RayVfxManager.spawnForBullet(bullet, rayOriginX, rayOriginY,
                            rayEndX, rayEndY, config, comboMissMeta);
                    }
                }
            } // end per-phase

            // ================================================================
            // 穿透模式（单模式）：扫描时维护前 N 小 tEntry 有序表 → 逐个伤害
            // ================================================================
            } else if (rayMode == "pierce") {
                var pierceLimit:Number = bulletPierceLimit;
                var pierceFalloff:Number = config.damageFalloff;

                // 前 N 小 tEntry 有序表（按 tEntry 升序，长度 ≤ pierceLimit）
                // 每个元素: {target, hitX, hitY, tEntry, zOffset}
                var pierceHits:Array = [];
                var pLen:Number = 0;

                for (var u:Number = lo; u < unitLen && unitLeftKeys[u] <= rayRight; u++) {
                    var hitTarget:MovieClip = unitMap[u];
                    var zOffset:Number = bulletZOffset - hitTarget.Z轴坐标;
                    if (zOffset >= bulletZRange || zOffset <= -bulletZRange) continue;

                    if (hitTarget.hp > 0 && hitTarget.防止无限飞 != true) {
                        var unitArea:AABBCollider = hitTarget.aabbCollider;
                        var collisionResult:Object = areaAABB.checkCollision(unitArea, zOffset);

                        if (collisionResult.isColliding) {
                            var newTEntry:Number = collisionResult.tEntry;

                            // 有序表未满或 newTEntry < 表尾最大值 → 需要插入
                            if (pLen < pierceLimit || newTEntry < pierceHits[pLen - 1].tEntry) {
                                var newHit:Object = {
                                    target: hitTarget,
                                    hitX: collisionResult.overlapCenter.x,
                                    hitY: collisionResult.overlapCenter.y,
                                    tEntry: newTEntry,
                                    zOffset: zOffset
                                };

                                // 插入排序：从表尾向前找插入位置（表长 ≤ pierceLimit，O(N)）
                                var insertPos:Number = pLen;
                                if (insertPos > 0) {
                                    // 若表已满则从倒数第二个开始比较（表尾将被挤出）
                                    var scanStart:Number = (pLen >= pierceLimit) ? pLen - 2 : pLen - 1;
                                    for (var pi:Number = scanStart; pi >= 0; pi--) {
                                        if (pierceHits[pi].tEntry > newTEntry) {
                                            pierceHits[pi + 1] = pierceHits[pi];
                                            insertPos = pi;
                                        } else {
                                            break;
                                        }
                                    }
                                }
                                pierceHits[insertPos] = newHit;
                                if (pLen < pierceLimit) pLen++;
                            }
                        }
                    }
                }

                // ---- Lockon 注入（pure pierce）----
                if (isLockon) {
                    var ltFoundP:Boolean = false;
                    for (var ltpi:Number = 0; ltpi < pLen; ltpi++) {
                        if (pierceHits[ltpi].target == lockonTarget) {
                            ltFoundP = true;
                            break;
                        }
                    }
                    if (!ltFoundP) {
                        var ltpInsPos:Number = pLen;
                        if (pLen >= pierceLimit) {
                            if (lockonTEntry < pierceHits[pLen - 1].tEntry) {
                                ltpInsPos = pLen - 1;
                                for (var ltpk:Number = pLen - 2; ltpk >= 0; ltpk--) {
                                    if (pierceHits[ltpk].tEntry > lockonTEntry) {
                                        pierceHits[ltpk + 1] = pierceHits[ltpk];
                                        ltpInsPos = ltpk;
                                    } else break;
                                }
                            } else {
                                ltpInsPos = pLen - 1;
                            }
                        } else {
                            for (var ltpk:Number = pLen - 1; ltpk >= 0; ltpk--) {
                                if (pierceHits[ltpk].tEntry > lockonTEntry) {
                                    pierceHits[ltpk + 1] = pierceHits[ltpk];
                                    ltpInsPos = ltpk;
                                } else break;
                            }
                            pLen++;
                        }
                        pierceHits[ltpInsPos] = {
                            target: lockonTarget,
                            hitX: lockonHitX, hitY: lockonHitY,
                            tEntry: lockonTEntry,
                            zOffset: bulletZOffset - lockonTarget.Z轴坐标
                        };
                    }
                }

                if (pLen > 0) {
                    var pDmgMult:Number = 1.0;
                    // 【设计决策】附加层伤害计算 仅在首命中前重置，副命中不重置。
                    // 当前该字段未被下游消费，若未来启用需评估是否每次命中都重置。
                    bullet.附加层伤害计算 = 0;
                    var pierceLegacyHookDone:Boolean = false;

                    // 逐个处理所有穿透命中
                    for (var pk:Number = 0; pk < pLen; pk++) {
                        var ph:Object = pierceHits[pk];
                        hitTarget = ph.target;

                        settleRayHit(ctx, hitTarget,
                            ph.hitX, ph.hitY, pDmgMult, ph.tEntry, !pierceLegacyHookDone);
                        if (!pierceLegacyHookDone && ctx.actualHit) {
                            pierceLegacyHookDone = true;
                        }

                        if (debugMode) {
                            unitArea = hitTarget.aabbCollider;
                            AABBRenderer.renderAABB(areaAABB, ph.zOffset, "thick");
                            AABBRenderer.renderAABB(unitArea, ph.zOffset, "filled");
                        }

                        pDmgMult *= pierceFalloff;
                    }

                    // 穿透射线视觉
                    var rayAngle:Number = resolvedRayAngle;
                    var rayLength:Number = config.rayLength || 900;
                    var rayEndX:Number;
                    var rayEndY:Number;

                    // 判断是否达到穿透上限
                    // pLen == pierceLimit 表示命中数达到上限，终点截止到最后一个命中的敌人
                    // pLen < pierceLimit 表示敌人数量不足，射线应该打到 rayLength 全长
                    if (pLen >= pierceLimit) {
                        // 命中数达到上限：终点为最后一个命中的敌人位置
                        var lastHit:Object = pierceHits[pLen - 1];
                        rayEndX = lastHit.hitX;
                        rayEndY = lastHit.hitY;
                    } else {
                        // 敌人不足：射线延伸到 rayLength 全长，并播放击中地图效果
                        rayEndX = rayOriginX + Math.cos(rayAngle) * rayLength;
                        rayEndY = rayOriginY + Math.sin(rayAngle) * rayLength;
                        FX.Effect(bullet.击中地图效果, rayEndX, rayEndY, shooter._xscale, undefined, true);
                    }

                    // 构建 SegmentMeta，包含所有命中点信息（用于 WaveRenderer 的命中点波纹）
                    var pierceHitPoints:Array = null;
                    if (projectRay) {
                        pierceHitPoints = [];
                        for (var hpi:Number = 0; hpi < pLen; hpi++) {
                            pierceHitPoints.push({x: pierceHits[hpi].hitX, y: pierceHits[hpi].hitY});
                        }
                    }
                    if (projectRay) {
                        var pierceMeta:Object = {
                            segmentKind: "pierce",
                            hitIndex: 0,
                            intensity: 1.0,
                            isHit: true,
                            hitPoints: pierceHitPoints
                        };

                        RayVfxManager.spawnForBullet(bullet, rayOriginX, rayOriginY, rayEndX, rayEndY, config, pierceMeta);
                    }

                } else {
                    // 穿透射线未命中：电弧打到最远处
                    rayAngle = resolvedRayAngle;
                    rayLength = (config != null && !isNaN(config.rayLength)) ? config.rayLength : 900;
                    rayEndX = rayOriginX + Math.cos(rayAngle) * rayLength;
                    rayEndY = rayOriginY + Math.sin(rayAngle) * rayLength;

                    FX.Effect(bullet.击中地图效果, rayEndX, rayEndY, shooter._xscale, undefined, true);

                    // 未命中的 pierce 射线 meta
                    if (projectRay) {
                        var missedPierceMeta:Object = {
                            segmentKind: "pierce",
                            hitIndex: 0,
                            intensity: 1.0,
                            isHit: false,
                            hitPoints: null
                        };
                        RayVfxManager.spawnForBullet(bullet, rayOriginX, rayOriginY, rayEndX, rayEndY, config, missedPierceMeta);
                    }
                }

            // ================================================================
            // single / chain / fork 模式：先找最近命中
            // ================================================================
            } else {
                // ---- 在窗口内扫描候选目标，找到最近命中 ----
                // 使用 tEntry（Slab 输出）直接比较，比 dist² 更精确
                var rayNearestTEntry:Number = Infinity;
                var rayNearestTarget:MovieClip = null;
                var rayNearestHitX:Number = 0;
                var rayNearestHitY:Number = 0;

                for (u = lo; u < unitLen && unitLeftKeys[u] <= rayRight; u++) {
                    hitTarget = unitMap[u];
                    zOffset = bulletZOffset - hitTarget.Z轴坐标;
                    if (zOffset >= bulletZRange || zOffset <= -bulletZRange) continue;

                    if (hitTarget.hp > 0 && hitTarget.防止无限飞 != true) {
                        unitArea = hitTarget.aabbCollider;
                        collisionResult = areaAABB.checkCollision(unitArea, zOffset);

                        if (collisionResult.isColliding) {
                            // 使用 tEntry 直接比较距离
                            // Slab 算法保证 tEntry 就是射线参数，无需额外 dist² 计算
                            if (collisionResult.tEntry < rayNearestTEntry) {
                                rayNearestTEntry = collisionResult.tEntry;
                                rayNearestTarget = hitTarget;
                                rayNearestHitX = collisionResult.overlapCenter.x;
                                rayNearestHitY = collisionResult.overlapCenter.y;
                            }
                        }
                    }
                }

                // ---- Lockon 覆盖（single/chain/fork）----
                if (isLockon) {
                    rayNearestTarget = lockonTarget;
                    rayNearestHitX = lockonHitX;
                    rayNearestHitY = lockonHitY;
                    rayNearestTEntry = lockonTEntry;
                }

                // ---- 主命中处理 ----
                if (rayNearestTarget != null) {
                    hitTarget = rayNearestTarget;

                    // 【设计决策】附加层伤害计算 仅在主命中前重置，chain/fork 副命中不重置。
                    // 当前该字段未被下游消费，若未来启用需评估是否每次命中都重置。
                    bullet.附加层伤害计算 = 0;
                    var singleLegacyHookDone:Boolean = false;
                    settleRayHit(ctx, hitTarget,
                        rayNearestHitX, rayNearestHitY, lockonDmgMult, rayNearestTEntry, true);
                    if (ctx.actualHit) singleLegacyHookDone = true;
                    // 构建主命中 SegmentMeta
                    if (projectRay) {
                        var mainMeta:Object = {
                            segmentKind: "main",
                            hitIndex: 0,
                            intensity: lockonDmgMult,
                            isHit: true
                        };
                        RayVfxManager.spawnForBullet(bullet, rayOriginX, rayOriginY, rayNearestHitX, rayNearestHitY, config, mainMeta);
                    }

                    if (debugMode) {
                        unitArea = hitTarget.aabbCollider;
                        zOffset = bulletZOffset - hitTarget.Z轴坐标;
                        AABBRenderer.renderAABB(areaAABB, zOffset, "thick");
                        AABBRenderer.renderAABB(unitArea, zOffset, "filled");
                    }

                    // ========================================================
                    // chain 模式：从命中点连锁弹跳到附近目标
                    // ========================================================
                    if (rayMode == "chain" && bulletPierceLimit > 1) {
                        // bulletPierceLimit - 1 = 弹跳次数（主命中已消耗1个名额）
                        var chainMaxBounces:Number = bulletPierceLimit - 1;
                        // _root.服务器.立即发送("[RAY-C0] chain开始 maxBounces=" + chainMaxBounces + " unitLen=" + unitLen);
                        var chainRadius:Number = config.chainRadius;
                        var chainFalloff:Number = config.damageFalloff;
                        var chainRadiusSq:Number = chainRadius * chainRadius;
                        var chainDmgMult:Number = lockonDmgMult * chainFalloff; // 主命中衰减 × 弹跳衰减

                        // 已命中目标集合（防重复弹跳）
                        var chainVisited:Object = {};
                        chainVisited[rayNearestTarget._name] = true;

                        var prevChainX:Number = rayNearestHitX;
                        var prevChainY:Number = rayNearestHitY;
                        // Z 轴传递：从上一个命中目标的 Z 位置继续搜索
                        var prevChainZ:Number = rayNearestTarget.Z轴坐标;

                        for (var ci:Number = 0; ci < chainMaxBounces; ci++) {
                            // _root.服务器.立即发送("[RAY-C" + (ci+1) + "] bounce prevX=" + prevChainX + " prevY=" + prevChainY);
                            // 从当前命中点搜索最近未命中目标
                            var searchLeft:Number = prevChainX - chainRadius;
                            var searchRight:Number = prevChainX + chainRadius;

                            // 二分查找起始索引
                            var clo:Number = bsearchScanStart(unitRightMax, unitLen, searchLeft);

                            var chainBestDistSq:Number = chainRadiusSq;
                            var chainBestTarget:MovieClip = null;
                            var chainBestX:Number = 0;
                            var chainBestY:Number = 0;

                            for (var cu:Number = clo; cu < unitLen && unitLeftKeys[cu] <= searchRight; cu++) {
                                var chainTarget:MovieClip = unitMap[cu];

                                // 跳过已命中目标
                                if (chainVisited[chainTarget._name] == true) continue;

                                // Z 轴范围检查（参照上一个弹跳目标的 Z，允许跨层传播）
                                var czOff:Number = prevChainZ - chainTarget.Z轴坐标;
                                if (czOff >= bulletZRange || czOff <= -bulletZRange) continue;

                                if (chainTarget.hp > 0 && chainTarget.防止无限飞 != true) {
                                    // 使用 AABB 中心计算距离（链式弹跳不需要精确入射点）
                                    var ctAABB:AABBCollider = chainTarget.aabbCollider;
                                    var ctCenterX:Number = (ctAABB.left + ctAABB.right) * 0.5;
                                    var ctCenterY:Number = (ctAABB.top + ctAABB.bottom) * 0.5;

                                    var cdx:Number = ctCenterX - prevChainX;
                                    var cdy:Number = ctCenterY - prevChainY;
                                    var cdistSq:Number = cdx * cdx + cdy * cdy;

                                    if (cdistSq < chainBestDistSq) {
                                        chainBestDistSq = cdistSq;
                                        chainBestTarget = chainTarget;
                                        chainBestX = ctCenterX;
                                        chainBestY = ctCenterY;
                                    }
                                }
                            }

                            // 未找到目标：链断裂
                            if (chainBestTarget == null) break;

                            // 标记已命中
                            chainVisited[chainBestTarget._name] = true;

                            // 对链式目标应用伤害
                            settleRayHit(ctx, chainBestTarget,
                                chainBestX, chainBestY, chainDmgMult, -1, !singleLegacyHookDone);
                            if (!singleLegacyHookDone && ctx.actualHit) {
                                singleLegacyHookDone = true;
                            }
                            // 构建 chain 弹跳 SegmentMeta (hitIndex 从 1 开始，0 是主命中)
                            if (projectRay) {
                                var chainMeta:Object = {
                                    segmentKind: "chain",
                                    hitIndex: ci + 1,
                                    intensity: chainDmgMult,
                                    isHit: true,
                                    parentEndX: prevChainX,
                                    parentEndY: prevChainY
                                };
                                RayVfxManager.spawnForBullet(bullet, prevChainX, prevChainY, chainBestX, chainBestY, config, chainMeta);
                            }

                            // 更新链式起点（含 Z 轴传递）
                            prevChainX = chainBestX;
                            prevChainY = chainBestY;
                            prevChainZ = chainBestTarget.Z轴坐标;
                            chainDmgMult *= chainFalloff;
                        }
                        // _root.服务器.立即发送("[RAY-CE] chain结束");

                    // ========================================================
                    // fork 模式：光棱折射 —— 从命中点搜索附近目标定向折射
                    //
                    // 类似红警光棱塔：主射线命中后，从命中点搜索半径内
                    // 最近的 N 个敌人，对每个目标发射定向折射光束。
                    // 没有目标 = 不发射，不存在"打空"的光束。
                    // 复用 chainRadius 作为搜索半径。
                    // ========================================================
                    } else if (rayMode == "fork" && bulletPierceLimit > 1) {
                        var forkCount:Number = bulletPierceLimit - 1;
                        var forkRadius:Number = config.chainRadius;
                        var forkFalloff:Number = config.damageFalloff;
                        var forkRadiusSq:Number = forkRadius * forkRadius;

                        // Z 轴参照主命中目标（折射从命中点出发，继承其 Z 位置）
                        var forkRefZ:Number = rayNearestTarget.Z轴坐标;

                        // 搜索窗口：以命中点为中心 ± forkRadius
                        var forkSearchLeft:Number = rayNearestHitX - forkRadius;
                        var forkSearchRight:Number = rayNearestHitX + forkRadius;

                        // 二分查找起始索引
                        var flo:Number = bsearchScanStart(unitRightMax, unitLen, forkSearchLeft);

                        // 维护前 N 近有序表（按距离升序，长度 ≤ forkCount）
                        // 每个元素: {target, centerX, centerY, distSq}
                        var forkHits:Array = [];
                        var fLen:Number = 0;

                        for (var fu:Number = flo; fu < unitLen && unitLeftKeys[fu] <= forkSearchRight; fu++) {
                            var fTarget:MovieClip = unitMap[fu];

                            // 跳过主射线已命中的目标
                            if (fTarget == rayNearestTarget) continue;

                            // Z 轴范围检查（参照主命中目标 Z）
                            var fzOff:Number = forkRefZ - fTarget.Z轴坐标;
                            if (fzOff >= bulletZRange || fzOff <= -bulletZRange) continue;

                            if (fTarget.hp > 0 && fTarget.防止无限飞 != true) {
                                // 计算到命中点的距离²
                                var ftAABB:AABBCollider = fTarget.aabbCollider;
                                var ftCX:Number = (ftAABB.left + ftAABB.right) * 0.5;
                                var ftCY:Number = (ftAABB.top + ftAABB.bottom) * 0.5;

                                var fdx:Number = ftCX - rayNearestHitX;
                                var fdy:Number = ftCY - rayNearestHitY;
                                var fdistSq:Number = fdx * fdx + fdy * fdy;

                                if (fdistSq < forkRadiusSq) {
                                    // 有序表未满或比表尾更近 → 插入
                                    if (fLen < forkCount || fdistSq < forkHits[fLen - 1].distSq) {
                                        var fNewHit:Object = {
                                            target: fTarget,
                                            centerX: ftCX,
                                            centerY: ftCY,
                                            distSq: fdistSq
                                        };

                                        // 插入排序（表长 ≤ forkCount，O(N)）
                                        var fInsertPos:Number = fLen;
                                        if (fInsertPos > 0) {
                                            var fScanStart:Number = (fLen >= forkCount) ? fLen - 2 : fLen - 1;
                                            for (var fpi:Number = fScanStart; fpi >= 0; fpi--) {
                                                if (forkHits[fpi].distSq > fdistSq) {
                                                    forkHits[fpi + 1] = forkHits[fpi];
                                                    fInsertPos = fpi;
                                                } else {
                                                    break;
                                                }
                                            }
                                        }
                                        forkHits[fInsertPos] = fNewHit;
                                        if (fLen < forkCount) fLen++;
                                    }
                                }
                            }
                        }

                        // 对每个折射目标造成伤害 + 渲染定向电弧
                        for (var fk:Number = 0; fk < fLen; fk++) {
                            var fh:Object = forkHits[fk];
                            var fhTarget:MovieClip = fh.target;

                            settleRayHit(ctx, fhTarget,
                                fh.centerX, fh.centerY, forkFalloff, -1, !singleLegacyHookDone);
                            if (!singleLegacyHookDone && ctx.actualHit) {
                                singleLegacyHookDone = true;
                            }
                            // 折射电弧：从主命中点定向射向折射目标
                            if (projectRay) {
                                var forkMeta:Object = {
                                    segmentKind: "fork",
                                    hitIndex: fk,
                                    intensity: forkFalloff,
                                    isHit: true,
                                    parentEndX: rayNearestHitX,
                                    parentEndY: rayNearestHitY
                                };
                                RayVfxManager.spawnForBullet(bullet, rayNearestHitX, rayNearestHitY, fh.centerX, fh.centerY, config, forkMeta);
                            }
                        }
                    }
                    // single 模式无额外处理

                } else {
                    // 射线未命中：电弧打到最远处
                    rayAngle = resolvedRayAngle;
                    rayLength = (config != null && !isNaN(config.rayLength))
                        ? config.rayLength : 900;
                    rayEndX = rayOriginX + Math.cos(rayAngle) * rayLength;
                    rayEndY = rayOriginY + Math.sin(rayAngle) * rayLength;

                    // 未命中时无 HitUpdater 回调，直接播放击中地图效果
                    FX.Effect(bullet.击中地图效果, rayEndX, rayEndY, shooter._xscale, undefined, true);
                    if (projectRay) {
                        var missMeta:Object = {
                            segmentKind: "main",
                            hitIndex: 0,
                            intensity: 1.0,
                            isHit: false
                        };
                        RayVfxManager.spawnForBullet(bullet, rayOriginX, rayOriginY, rayEndX, rayEndY, config, missMeta);
                    }
                }
            }

            // 射线子弹单帧检测后销毁
            bullet.removeMovieClip();
        }

        // 重建射线队列：仅保留 deferral=B 持久存活的射线（pierce/chain/含 pierce 的 combo）；
        // 其余批量射线（single/fork/no-pierce combo）本帧均已 removeMovieClip。
        // 注：处理期间 spawn 的新射线（index >= count）与原 length=0 行为一致——被丢弃。
        _rayBullets = survivors;
        _raySurvivors = rayList;
        rayList.length = 0;
    }

    /**
     * 喷火持续射线：每帧重扫沿线目标，计算阻挡目标长度，并按 tickInterval 重复灼烧。
     *
     * 与 processPersistentRay 的关键差异：
     * - 不使用 _rayVisited；同一目标可以按间隔重复受击。
     * - 每帧重算第 pierceLimit 个命中目标作为 targetLength，目标离开后火束继续增长。
     * - 视觉 currentLength 可按 grow/retract 追随 targetLength；伤害长度始终 clamp 到 targetLength。
     */
    private static function processContinuousFlame(ctx:Object):Boolean {
        var projectRay:Boolean = ctx.projectRay;
        var bullet:Object = ctx.bullet;
        var shooter:MovieClip = ctx.shooter;
        var config:TeslaRayConfig = TeslaRayConfig(ctx.config);
        var rayLength:Number = config.rayLength || 900;
        var pierceLimit:Number = ctx.pierceLimit;
        if (!(pierceLimit > 0)) pierceLimit = 1;

        var growSpeed:Number = config.flameGrowSpeed;
        if (!(growSpeed > 0)) growSpeed = rayLength;
        var retractSpeed:Number = config.flameRetractSpeed;
        if (!(retractSpeed > 0)) retractSpeed = rayLength;
        if (config.flameUseWeaponVelocity) {
            var velocityBase:Number = config.flameVelocityBase;
            if (!(velocityBase > 0)) velocityBase = 35;
            var weaponVelocity:Number = Number(bullet.子弹速度);
            if (weaponVelocity < 0) weaponVelocity = -weaponVelocity;
            if (!(weaponVelocity > 0)) weaponVelocity = velocityBase;
            var velocityScale:Number = weaponVelocity / velocityBase;
            var minScale:Number = config.flameVelocityMinScale;
            if (!(minScale > 0)) minScale = 0.65;
            var maxScale:Number = config.flameVelocityMaxScale;
            if (!(maxScale > 0)) maxScale = 1.35;
            if (maxScale < minScale) maxScale = minScale;
            if (velocityScale < minScale) velocityScale = minScale;
            else if (velocityScale > maxScale) velocityScale = maxScale;
            growSpeed *= velocityScale;
            retractSpeed *= velocityScale;
        }
        var tickInterval:Number = config.flameTickInterval;
        if (!(tickInterval > 0)) tickInterval = 1;
        var lifetime:Number = config.flameLifetime;
        if (!(lifetime > 0)) lifetime = 1;

        if (!bullet._flameInited) {
            var startLength:Number = config.flameStartLength;
            if (!(startLength >= 0)) startLength = 0;
            if (startLength > rayLength) startLength = rayLength;
            bullet._flameAge = 0;
            bullet._flameCurrentLength = startLength;
            bullet._flameHitFrameByTarget = {};
            bullet._flameHitCountByTarget = {};
            bullet._flameHits = [];
            bullet._flameTotalHitsDone = 0;
            bullet._flameFirstHitDone = false;
            bullet._flameBaseDamageType = bullet.伤害类型;
            bullet._flameBaseMagicType = bullet.魔法伤害属性;
            bullet._flameShotSeed = Math.random() * 6.283185307179586;
            if (projectRay) {
                bullet._flameVfxKey = RayVisualBridge.flameKey(bullet);
                bullet._flameVfxSerial = ++_flameVfxSerialCounter;
            }
            bullet._flameInited = true;
        }

        var age:Number = bullet._flameAge;
        if (age >= lifetime) return false;

        var flameDirX:Number = Number(ctx.resolvedRayDirX);
        var flameDirY:Number = Number(ctx.resolvedRayDirY);
        if ((flameDirX - flameDirX) != 0 || (flameDirY - flameDirY) != 0 ||
            !(flameDirX * flameDirX + flameDirY * flameDirY > 0.000001)) {
            var angle:Number = (ctx.resolvedRayAngle != undefined) ? Number(ctx.resolvedRayAngle) : bullet._rotation * (Math.PI / 180);
            if ((angle - angle) != 0) return false;
            flameDirX = Math.cos(angle);
            flameDirY = Math.sin(angle);
        }

        var hits:Array = collectFlameHits(ctx, pierceLimit);
        var hLen:Number = ctx.flameHitCount;
        var targetLength:Number = rayLength;
        var blocked:Boolean = false;
        if (hLen >= pierceLimit) {
            targetLength = hits[pierceLimit - 1].tEntry;
            blocked = true;
        }

        var currentLength:Number = bullet._flameCurrentLength;
        if (!(currentLength >= 0)) currentLength = 0;
        if (targetLength > currentLength) {
            currentLength = Math.min(targetLength, currentLength + growSpeed);
        } else if (targetLength < currentLength) {
            currentLength = Math.max(targetLength, currentLength - retractSpeed);
        }
        if (currentLength > rayLength) currentLength = rayLength;
        bullet._flameCurrentLength = currentLength;

        // 收缩滞后只影响残影视觉；伤害不允许越过当前阻挡长度。
        var damageLength:Number = Math.min(currentLength, targetLength);
        var hitPoints:Array = null;
        var damageHitPoints:Array = null;
        var falloff:Number = config.damageFalloff;
        var dmgMult:Number = 1.0;
        var pulseCount:Number = config.flamePulseCount;
        var pulseIndex:Number = 0;
        var useGlobalPulse:Boolean = (pulseCount > 0);
        var isDamagePulse:Boolean = true;
        var hotStart:Number = config.flameHotPulseStart;
        if (!(hotStart >= 0)) hotStart = 1;
        var hotCount:Number = config.flameHotPulseCount;
        if (!(hotCount > 0)) hotCount = 0;
        var isHotPulse:Boolean = false;
        var totalHitBudget:Number = config.flameTotalHitBudget;
        if (!(totalHitBudget > 0)) totalHitBudget = 0;
        var maxHitsPerTarget:Number = config.flameMaxHitsPerTarget;
        if (!(maxHitsPerTarget > 0)) maxHitsPerTarget = 0;

        if (useGlobalPulse) {
            pulseIndex = Math.floor(age / tickInterval);
            isDamagePulse = (age % tickInterval == 0) && (pulseIndex < pulseCount);
            if (pulseIndex >= pulseCount) pulseIndex = pulseCount - 1;
            if (pulseIndex < 0) pulseIndex = 0;
            isHotPulse = (pulseIndex >= hotStart && pulseIndex < hotStart + hotCount);
        }

        var baseDamageType:Object = bullet._flameBaseDamageType;
        var baseMagicType:Object = bullet._flameBaseMagicType;
        if (useGlobalPulse && isDamagePulse) {
            if (isHotPulse) {
                bullet.伤害类型 = config.flameHotDamageType ? config.flameHotDamageType : "魔法";
                bullet.魔法伤害属性 = config.flameHotMagicType ? config.flameHotMagicType : "热";
            } else {
                bullet.伤害类型 = baseDamageType;
                bullet.魔法伤害属性 = baseMagicType;
            }
        }

        for (var i:Number = 0; i < hLen; i++) {
            var h:Object = hits[i];
            if (h.tEntry > damageLength + 0.001) break;

            if (projectRay) {
                if (hitPoints == null) hitPoints = [];
                hitPoints[hitPoints.length] = {x: h.hitX, y: h.hitY};
            }

            var lastTick = bullet._flameHitFrameByTarget[h.target._name];
            var targetHitCount:Number = Number(bullet._flameHitCountByTarget[h.target._name]);
            if (!(targetHitCount > 0)) targetHitCount = 0;
            var hasTotalBudget:Boolean = (totalHitBudget <= 0 || bullet._flameTotalHitsDone < totalHitBudget);
            var hasTargetBudget:Boolean = (maxHitsPerTarget <= 0 || targetHitCount < maxHitsPerTarget);
            if (isDamagePulse && hasTotalBudget && hasTargetBudget &&
                (lastTick == undefined || age - Number(lastTick) >= tickInterval)) {
                if (!bullet._flameFirstHitDone) {
                    bullet.附加层伤害计算 = 0;
                }
                var flameHookPending:Boolean = !bullet._flameFirstHitDone;
                var damageResult:Object = injectHit(
                    bullet, shooter, h.target, h.hitX, h.hitY, dmgMult, flameHookPending);
                var flameActualHit:Boolean = _injectCtx.actualHit;
                if (flameHookPending && flameActualHit) {
                    bullet._flameFirstHitDone = true;
                }
                if (damageResult != null) {
                    // 几何相交仍消耗喷火脉冲预算，但 MISS 不得进入 renderer 的
                    // 单位命中纹理点集。
                    if (flameActualHit || damageResult === DamageResult.NULL) {
                        if (projectRay) {
                            if (damageHitPoints == null) damageHitPoints = [];
                            damageHitPoints[damageHitPoints.length] = {x: h.hitX, y: h.hitY};
                        }
                    }
                    bullet._flameHitFrameByTarget[h.target._name] = age;
                    bullet._flameHitCountByTarget[h.target._name] = targetHitCount + 1;
                    bullet._flameTotalHitsDone++;
                }
            }

            dmgMult *= falloff;
        }

        if (useGlobalPulse && isDamagePulse) {
            bullet.伤害类型 = baseDamageType;
            bullet.魔法伤害属性 = baseMagicType;
        }

        if (projectRay) {
            var endX:Number = ctx.rayOriginX + flameDirX * currentLength;
            var endY:Number = ctx.rayOriginY + flameDirY * currentLength;
            RayVfxManager.spawnForBullet(bullet, ctx.rayOriginX, ctx.rayOriginY, endX, endY, config,
                {
                    segmentKind: "flame",
                    hitIndex: 0,
                    intensity: 1.0,
                    isHit: hitPoints != null,
                    hitPoints: hitPoints,
                    damageHitPoints: damageHitPoints,
                    isBlocked: blocked,
                    targetLength: targetLength,
                    damageLength: damageLength,
                    pulseIndex: pulseIndex,
                    pulseCount: pulseCount,
                    isHotPulse: isHotPulse,
                    isDamagePulse: isDamagePulse,
                    shotSeed: bullet._flameShotSeed,
                    flameVfxKey: bullet._flameVfxKey,
                    flameVfxSerial: bullet._flameVfxSerial
                });
        }

        bullet._flameAge = age + 1;
        return bullet._flameAge < lifetime;
    }

    /**
     * 收集沿火束方向最近的 maxCount 个目标，按 tEntry 升序返回。
     */
    private static function collectFlameHits(ctx:Object, maxCount:Number):Array {
        var areaAABB:AABBCollider = ctx.areaAABB;
        var rejectY:Function = rejectRayCandidateY;
        var rayYWindow:Object = prepareRayYWindow(areaAABB);
        var unitMap:Array = ctx.unitMap;
        var unitLen:Number = ctx.unitLen;
        var unitLeftKeys:Array = ctx.unitLeftKeys;
        var unitRightMax:Array = ctx.unitRightMax;
        var bulletZOffset:Number = ctx.bulletZOffset;
        var bulletZRange:Number = ctx.bulletZRange;
        var rayRight:Number = areaAABB.right;
        var lo:Number = bsearchScanStart(unitRightMax, unitLen, areaAABB.left);
        var bullet:Object = ctx.bullet;
        var hits:Array = bullet._flameHits;
        if (hits == null) {
            hits = [];
            bullet._flameHits = hits;
        }
        var hLen:Number = 0;

        for (var u:Number = lo; u < unitLen && unitLeftKeys[u] <= rayRight; u++) {
            var t:MovieClip = unitMap[u];
            var zoff:Number = bulletZOffset - t.Z轴坐标;
            if (zoff >= bulletZRange || zoff <= -bulletZRange) continue;
            if (t.hp > 0 && t.防止无限飞 != true) {
                var candidateCollider:AABBCollider = t.aabbCollider;
                if (rejectY(rayYWindow, candidateCollider, zoff)) continue;
                var cr:Object = areaAABB.checkCollision(candidateCollider, zoff);
                if (cr.isColliding) {
                    var newTEntry:Number = cr.tEntry;
                    if (hLen < maxCount || newTEntry < hits[hLen - 1].tEntry) {
                        var nh:Object;
                        var ins:Number = (hLen >= maxCount) ? hLen - 1 : hLen;
                        var scanStart:Number = (hLen >= maxCount) ? hLen - 2 : hLen - 1;
                        if (hLen >= maxCount) {
                            nh = hits[hLen - 1];
                        } else {
                            nh = hits[hLen];
                            if (nh == null) {
                                nh = {};
                                hits[hLen] = nh;
                            }
                        }
                        nh.target = t;
                        nh.hitX = cr.overlapCenter.x;
                        nh.hitY = cr.overlapCenter.y;
                        nh.tEntry = newTEntry;
                        for (var pi:Number = scanStart; pi >= 0; pi--) {
                            if (hits[pi].tEntry > newTEntry) {
                                hits[pi + 1] = hits[pi];
                                ins = pi;
                            } else {
                                break;
                            }
                        }
                        hits[ins] = nh;
                        if (hLen < maxCount) hLen++;
                    }
                }
            }
        }

        ctx.flameHitCount = hLen;
        return hits;
    }

    /**
     * deferral=B 持久射线：每帧贪心结算至多 N 个命中，跨帧存活携带 state。
     * 服务 pierce / chain / 含 pierce 的 combo；single/fork/no-pierce combo 仍走批量路。
     *
     * 模型（设计稿 §6）：射线本身是 spawn 出来的、自带 damageManager → injectHit(bullet,...)
     * 直接可用（射线天然适配旁路原语）。未结束的射线留在 _rayBullets，每帧推进 1 命中（N 默认 1）；
     * budget 耗尽或本帧找不到下一命中即结束。首发触发"击中时触发函数"一次；lockon 首发直伤、
     * 几何冻结于首帧（之后不再 re-aim）。
     *
     * 持久 state 挂在 bullet 上：_rayInited / _rayBudget / _rayVisited / _rayCursorX/Y/Z /
     * _rayLastTEntry / _rayFirstHitDone / _rayFirstActualHookDone / _rayDmgMult /
     * _rayPrevVfxX/Y / _rayEndX/Y / _rayHitPoints /
     * _rayCombo（combo 迭代游标 RayComboCursor 实例）。
     *
     * @param ctx 已打包的每帧上下文（bullet/shooter/几何/窗口/config/rayMode/pierceLimit/FX 等）
     * @return true=本帧后仍存活（caller 保留），false=已结束（caller removeMovieClip）
     */
    private static function processPersistentRay(ctx:Object):Boolean {
        var projectRay:Boolean = ctx.projectRay;
        var bullet:Object = ctx.bullet;
        var shooter:MovieClip = ctx.shooter;
        var config:TeslaRayConfig = TeslaRayConfig(ctx.config);
        var areaAABB:AABBCollider = ctx.areaAABB;
        var rayMode:String = ctx.rayMode;
        var falloff:Number = config.damageFalloff;
        var rayLength:Number = config.rayLength || 900;
        var lockonDmgMult:Number = (bullet.lockonDmgMult > 0) ? bullet.lockonDmgMult : 1;

        // N = 每帧命中数（未配置默认 1）。ctx.config 为无类型链 → 读未声明字段不报错。
        var N:Number = ctx.config.hitsPerFrame;
        if (!(N > 0)) N = 1;

        var hits:Number = 0;   // 本帧已结算命中数

        // ── 首帧 setup：lockon 解析 + 冻结几何 + 首发直伤 ──
        if (!bullet._rayInited) {
            bullet._rayBudget = ctx.pierceLimit;
            bullet._rayVisited = {};
            bullet._rayDmgMult = 1;
            bullet._rayFirstHitDone = false;
            bullet._rayFirstActualHookDone = false;
            bullet._rayLastTEntry = -1;
            bullet._rayCursorX = ctx.rayOriginX;
            bullet._rayCursorY = ctx.rayOriginY;
            bullet._rayCursorZ = bullet.Z轴坐标;
            if (projectRay) { bullet._rayPrevVfxX = ctx.rayOriginX; bullet._rayPrevVfxY = ctx.rayOriginY; }
            var initAng:Number = bullet._rotation * (Math.PI / 180);
            bullet._rayEndX = ctx.rayOriginX + Math.cos(initAng) * rayLength;
            bullet._rayEndY = ctx.rayOriginY + Math.sin(initAng) * rayLength;
            bullet._rayHitPoints = (projectRay && rayMode == "pierce") ? [] : null;
            bullet.附加层伤害计算 = 0;
            // combo per-node 迭代游标（组件化为 RayComboCursor 类；首帧 new，跨帧 resume）
            bullet._rayCombo = new RayComboCursor();

            var lockonTarget:MovieClip = bullet.lockonTarget;
            if (lockonTarget != null && lockonTarget.aabbCollider != null) {
                var ltA:AABBCollider = lockonTarget.aabbCollider;
                var lhx:Number = (ltA.left + ltA.right) * 0.5;
                var lhy:Number = (ltA.top + ltA.bottom) * 0.5;
                var ldx:Number = lhx - ctx.rayOriginX;
                var ldy:Number = lhy - ctx.rayOriginY;
                var ldsq:Number = ldx * ldx + ldy * ldy;
                if (ldsq > 0.001) {
                    var lockonDist:Number = Math.sqrt(ldsq);
                    // 冻结射线几何朝向锁定目标（仅首帧；之后不再 re-aim，避免变成跟踪光束）
                    areaAABB["setRayFast"](ctx.rayOriginX, ctx.rayOriginY, ldx, ldy, rayLength);
                    bullet._rayEndX = ctx.rayOriginX + (ldx / lockonDist) * rayLength;
                    bullet._rayEndY = ctx.rayOriginY + (ldy / lockonDist) * rayLength;
                    // 首发直伤 = 锁定目标；几何游标与 actual-only 旧钩子资格分开推进。
                    if (projectRay) RayVisualBridge.noteTarget(bullet, lockonTarget); // 纯显示身份快照。
                    injectHit(
                        bullet, shooter, lockonTarget, lhx, lhy, lockonDmgMult,
                        !bullet._rayFirstActualHookDone);
                    if (_injectCtx.actualHit) {
                        bullet._rayFirstActualHookDone = true;
                    }
                    spawnPersistentRaySeg(ctx, bullet, lhx, lhy, lockonDmgMult, false);
                    if (projectRay && rayMode == "pierce") {
                        bullet._rayHitPoints[bullet._rayHitPoints.length] = {x: lhx, y: lhy};
                    }
                    bullet._rayFirstHitDone = true;
                    bullet._rayVisited[lockonTarget._name] = true;
                    bullet._rayBudget--;
                    bullet._rayLastTEntry = lockonDist;
                    bullet._rayCursorX = lhx;
                    bullet._rayCursorY = lhy;
                    bullet._rayCursorZ = lockonTarget.Z轴坐标;
                    bullet._rayDmgMult *= falloff;
                    hits = 1;   // lockon 首发计入本帧命中（N=1 时本帧不再追加）
                }
            }
            bullet._rayInited = true;
        }

        // ── 每帧贪心：至多 N 命中 ──
        var isCombo:Boolean = config.isCombo();
        while (hits < N && bullet._rayBudget > 0) {
            var next:Object;
            if (isCombo) {
                // 组合（含 pierce，如铁枪 chain,fork,pierce）：增量复刻 batch per-node 遍历
                // （节点→其 chain 走链→其 fork→下一节点），no-death 下命中序与衰减 ≡ batch。
                next = findNextComboPerNode(ctx, bullet);
            } else if (rayMode == "pierce") {
                // 沿线推进：tEntry 严格大于已推进位置的最近碰撞
                next = findAlongRay(ctx, bullet._rayVisited, bullet._rayLastTEntry);
            } else {
                // chain：首命中=沿线最近；之后=游标周 chainRadius 最近
                if (!bullet._rayFirstHitDone) {
                    next = findAlongRay(ctx, bullet._rayVisited, -1);
                } else {
                    next = findNearCursor(ctx, bullet);
                }
            }
            if (next == null) break;   // 本帧找不到下一命中 → 结束

            // 首个几何命中只负责原有游标/附加层语义；旧钩子另等首个真实命中。
            if (!bullet._rayFirstHitDone) {
                bullet.附加层伤害计算 = 0;
            }

            // combo：dmgMult 由迭代器按 phase 算好放在 next.dmgMult；pierce/chain：统一累乘 _rayDmgMult。
            var dm:Number = (isCombo ? next.dmgMult : bullet._rayDmgMult) * lockonDmgMult;
            if (projectRay) RayVisualBridge.noteTarget(bullet, next.target); // 不改变迭代器、预算或结算。
            injectHit(
                bullet, shooter, next.target, next.hitX, next.hitY, dm,
                !bullet._rayFirstActualHookDone);
            if (!bullet._rayFirstActualHookDone && _injectCtx.actualHit) {
                bullet._rayFirstActualHookDone = true;
            }
            if (projectRay) spawnPersistentRaySeg(ctx, bullet, next.hitX, next.hitY, dm, bullet._rayFirstHitDone);
            if (projectRay && rayMode == "pierce") {
                bullet._rayHitPoints[bullet._rayHitPoints.length] = {x: next.hitX, y: next.hitY};
            }

            bullet._rayFirstHitDone = true;
            bullet._rayVisited[next.target._name] = true;
            bullet._rayBudget--;
            hits++;
            if (!isCombo) {
                // pierce/chain 的统一游标/tEntry/衰减推进；combo 的等价状态由迭代器内部管理
                bullet._rayLastTEntry = next.tEntry;
                bullet._rayCursorX = next.hitX;
                bullet._rayCursorY = next.hitY;
                bullet._rayCursorZ = next.target.Z轴坐标;
                bullet._rayDmgMult *= falloff;
            }
        }

        // ── 从未命中过 + 本帧也未命中 → 画全长 miss 光束让玩家看到（一次性，随后结束）──
        if (hits == 0 && !bullet._rayFirstHitDone) {
            var ex:Number = bullet._rayEndX;
            var ey:Number = bullet._rayEndY;
            ctx.FX.Effect(bullet.击中地图效果, ex, ey, shooter._xscale, undefined, true);
            if (projectRay) RayVfxManager.spawnForBullet(bullet, ctx.rayOriginX, ctx.rayOriginY, ex, ey, config,
                {segmentKind: "main", hitIndex: 0, intensity: 1.0, isHit: false});
        } else if (hits == 0 && rayMode == "pierce" && bullet._rayBudget > 0) {
            finishPersistentPierceTail(ctx, bullet);
        }

        // 本帧有命中且仍有预算 → 跨帧存活；否则结束
        return (bullet._rayBudget > 0 && hits > 0);
    }

    /**
     * 纯 pierce 持久射线结束时补齐旧批量路径的尾段语义：
     * 预算尚未耗尽但沿线无更多目标 → 打到冻结射线终点，并携带 hitPoints 给渲染层。
     */
    private static function finishPersistentPierceTail(ctx:Object, bullet:Object):Void {
        var config:TeslaRayConfig = TeslaRayConfig(ctx.config);
        var ex:Number = bullet._rayEndX;
        var ey:Number = bullet._rayEndY;
        ctx.FX.Effect(bullet.击中地图效果, ex, ey, ctx.shooter._xscale, undefined, true);
        if (ctx.projectRay) RayVfxManager.spawnForBullet(bullet, ctx.rayOriginX, ctx.rayOriginY, ex, ey, config,
            {segmentKind: "pierce", hitIndex: 0, intensity: 1.0, isHit: true, hitPoints: bullet._rayHitPoints});
    }

    /**
     * 沿射线找"下一个"命中：窗口内 tEntry 严格大于 minTEntry 的最近未命中碰撞。
     * pierce 全程用它（minTEntry=上次推进位置）；chain 首命中用它（minTEntry=-1 取最近）。
     * @return {target, hitX, hitY, tEntry} 或 null
     */
    public static function findAlongRay(ctx:Object, visited:Object, minTEntry:Number):Object {
        var areaAABB:AABBCollider = ctx.areaAABB;
        var rejectY:Function = rejectRayCandidateY;
        var rayYWindow:Object = prepareRayYWindow(areaAABB);
        var unitMap:Array = ctx.unitMap;
        var unitLen:Number = ctx.unitLen;
        var unitLeftKeys:Array = ctx.unitLeftKeys;
        var unitRightMax:Array = ctx.unitRightMax;
        var bulletZOffset:Number = ctx.bulletZOffset;
        var bulletZRange:Number = ctx.bulletZRange;
        var rayRight:Number = areaAABB.right;
        var lo:Number = bsearchScanStart(unitRightMax, unitLen, areaAABB.left);
        var bestTE:Number = Infinity;
        var best:Object = null;
        for (var u:Number = lo; u < unitLen && unitLeftKeys[u] <= rayRight; u++) {
            var t:MovieClip = unitMap[u];
            if (visited[t._name] == true) continue;
            var zoff:Number = bulletZOffset - t.Z轴坐标;
            if (zoff >= bulletZRange || zoff <= -bulletZRange) continue;
            if (t.hp > 0 && t.防止无限飞 != true) {
                var candidateCollider:AABBCollider = t.aabbCollider;
                if (rejectY(rayYWindow, candidateCollider, zoff)) continue;
                var cr:Object = areaAABB.checkCollision(candidateCollider, zoff);
                if (cr.isColliding && cr.tEntry > minTEntry && cr.tEntry < bestTE) {
                    bestTE = cr.tEntry;
                    if (best == null) best = {};
                    best.target = t;
                    best.hitX = cr.overlapCenter.x;
                    best.hitY = cr.overlapCenter.y;
                    best.tEntry = cr.tEntry;
                }
            }
        }
        return best;
    }

    /**
     * 从指定点 (cx,cy,cz) 起 chainRadius 内最近的未命中目标（AABB 中心距）。
     * chain 弹跳 / combo chain 子阶段共用。
     * @return {target, hitX, hitY, tEntry:-1} 或 null
     */
    public static function findNearestAt(ctx:Object, visited:Object, cx:Number, cy:Number, cz:Number):Object {
        var config:TeslaRayConfig = TeslaRayConfig(ctx.config);
        var radius:Number = config.chainRadius;
        var radiusSq:Number = radius * radius;
        var unitMap:Array = ctx.unitMap;
        var unitLen:Number = ctx.unitLen;
        var unitLeftKeys:Array = ctx.unitLeftKeys;
        var unitRightMax:Array = ctx.unitRightMax;
        var bulletZRange:Number = ctx.bulletZRange;

        var lo:Number = bsearchScanStart(unitRightMax, unitLen, cx - radius);
        var sr:Number = cx + radius;
        var bestDSq:Number = radiusSq;
        var best:Object = null;
        for (var u:Number = lo; u < unitLen && unitLeftKeys[u] <= sr; u++) {
            var t:MovieClip = unitMap[u];
            if (visited[t._name] == true) continue;
            var zoff:Number = cz - t.Z轴坐标;
            if (zoff >= bulletZRange || zoff <= -bulletZRange) continue;
            if (t.hp > 0 && t.防止无限飞 != true) {
                var a:AABBCollider = t.aabbCollider;
                var ccx:Number = (a.left + a.right) * 0.5;
                var ccy:Number = (a.top + a.bottom) * 0.5;
                var dx:Number = ccx - cx;
                var dy:Number = ccy - cy;
                var dsq:Number = dx * dx + dy * dy;
                if (dsq < bestDSq) {
                    bestDSq = dsq;
                    if (best == null) best = {};
                    best.target = t;
                    best.hitX = ccx;
                    best.hitY = ccy;
                    best.tEntry = -1;
                }
            }
        }
        return best;
    }

    /** chain 弹跳：从游标 (_rayCursorX/Y/Z) 起最近未命中。 */
    private static function findNearCursor(ctx:Object, bullet:Object):Object {
        return findNearestAt(ctx, bullet._rayVisited, bullet._rayCursorX, bullet._rayCursorY, bullet._rayCursorZ);
    }

    /**
     * 收集 (cx,cy,cz) 起 chainRadius 内、前 maxCount 近的未命中目标（按距离升序），
     * 复刻 batch combo fork 的收集（插入排序、距离封顶）。
     * @return [{target, hitX, hitY, distSq}, ...]
     */
    public static function collectForkList(ctx:Object, visited:Object, cx:Number, cy:Number, cz:Number, maxCount:Number):Array {
        var config:TeslaRayConfig = TeslaRayConfig(ctx.config);
        var radius:Number = config.chainRadius;
        var radiusSq:Number = radius * radius;
        var unitMap:Array = ctx.unitMap;
        var unitLen:Number = ctx.unitLen;
        var unitLeftKeys:Array = ctx.unitLeftKeys;
        var unitRightMax:Array = ctx.unitRightMax;
        var bulletZRange:Number = ctx.bulletZRange;

        var lo:Number = bsearchScanStart(unitRightMax, unitLen, cx - radius);
        var sr:Number = cx + radius;
        var arr:Array = [];
        var aLen:Number = 0;
        for (var u:Number = lo; u < unitLen && unitLeftKeys[u] <= sr; u++) {
            var t:MovieClip = unitMap[u];
            if (visited[t._name] == true) continue;
            var zoff:Number = cz - t.Z轴坐标;
            if (zoff >= bulletZRange || zoff <= -bulletZRange) continue;
            if (t.hp > 0 && t.防止无限飞 != true) {
                var a:AABBCollider = t.aabbCollider;
                var ccx:Number = (a.left + a.right) * 0.5;
                var ccy:Number = (a.top + a.bottom) * 0.5;
                var dx:Number = ccx - cx;
                var dy:Number = ccy - cy;
                var dsq:Number = dx * dx + dy * dy;
                if (dsq < radiusSq) {
                    if (aLen < maxCount || dsq < arr[aLen - 1].distSq) {
                        var nh:Object = {target: t, hitX: ccx, hitY: ccy, distSq: dsq};
                        var ins:Number = aLen;
                        if (ins > 0) {
                            var ss:Number = (aLen >= maxCount) ? aLen - 2 : aLen - 1;
                            for (var pi:Number = ss; pi >= 0; pi--) {
                                if (arr[pi].distSq > dsq) { arr[pi + 1] = arr[pi]; ins = pi; } else break;
                            }
                        }
                        arr[ins] = nh;
                        if (aLen < maxCount) aLen++;
                    }
                }
            }
        }
        return arr;
    }

    /**
     * combo 增量 per-node 迭代：薄包装，桥接 processPersistentRay 与 RayComboCursor 组件
     * （combo 状态机 + ~14 字段已抽到 RayComboCursor 类，见该类）。游标实例挂 bullet._rayCombo
     * （processPersistentRay 首帧 new、跨帧 resume）。几何扫描原语 findAlongRay/findNearestAt/
     * collectForkList 是本类 public static（射线扫描层 = 未来 findNextHit 策略复用面），由游标回调。
     * @return {target, hitX, hitY, dmgMult} 或 null（节点耗尽=combo 结束）
     */
    private static function findNextComboPerNode(ctx:Object, bullet:Object):Object {
        var config:TeslaRayConfig = TeslaRayConfig(ctx.config);
        return bullet._rayCombo.next(
            ctx, bullet._rayVisited, config.damageFalloff,
            config.hasChain(), config.hasFork(), bullet._rayBudget);
    }

    /**
     * 持久射线 VFX：从上一段终点(_rayPrevVfxX/Y)画到本命中点，并推进 prev 游标。
     * isBounce=false → "main" 段（首命中/直线骨干）；true → "chain" 段（弹跳/续段）。
     */
    private static function spawnPersistentRaySeg(ctx:Object, bullet:Object, hitX:Number, hitY:Number, intensity:Number, isBounce:Boolean):Void {
        if (!ctx.projectRay) return;
        var config:TeslaRayConfig = TeslaRayConfig(ctx.config);
        RayVfxManager.spawnForBullet(bullet, bullet._rayPrevVfxX, bullet._rayPrevVfxY, hitX, hitY, config,
            {segmentKind: (isBounce ? "chain" : "main"), hitIndex: 0, intensity: intensity, isHit: true});
        bullet._rayPrevVfxX = hitX;
        bullet._rayPrevVfxY = hitY;
    }

    // ========================================================================
    // 核心处理方法：高性能批量碰撞检测
    // ========================================================================

    /**
     * 处理所有阵营的子弹队列
     *
     * 这是整个子弹碰撞检测系统的核心方法，使用双指针扫描线算法实现
     * O(B+T)摊还复杂度的高性能批量碰撞检测。每帧调用一次。
     *
     * 【算法概述】
     * 1. 子弹按左边界排序 - 启用扫描线算法的前提条件
     * 2. 双指针扫描线推进 - 只遍历有碰撞可能的子弹-目标对
     * 3. 空窗口快判 - O(1)时间过滤无目标区域
     * 4. 右边界截断 - 提前终止无效检测
     * 5. 多级碰撞检测 - Z轴粗判→AABB检测→精确多边形检测
     * 6. 批量生命周期管理 - 统一处理子弹终止和清理
     *
     * 【性能优化技术】
     * - 内联展开：消除高频函数调用开销，最小化栈帧切换
     * - 变量声明提升：避免循环内重复var声明开销
     * - 属性缓存：减少对象属性查找的哈希计算开销
     * - 循环展开：4步展开减少75%的循环条件判断
     * - 静态上下文复用：零分配策略，避免GC压力
     * - 延迟计算：按需获取昂贵的计算结果（如旋转角度）
     *
     * 【复杂度分析】
     * - 排序阶段：`O(B log B)`；若上一帧到下一帧**近乎有序**，TimSort/插入优化摊还近 `O(B)`
     * - 扫描阶段（双指针）：`O(B+T)` 摊还
     * - 空间：方法级**额外分配 ~ O(1)**；系统依赖 `BulletQueue/SortedUnitCache` 的**预分配缓冲 O(B+T)**；首次命中某些联弹可能触发**多边形碰撞体懒创建**
     *
     * 【适用场景】
     * - 大规模实时战斗
     * - 稳定帧率要求
     * - AS2虚拟机环境
     *
     * @complexity 摊还时间复杂度 O(B+T)，B=子弹数量，T=目标数量
     */
    public static function processQueue():Void {
        
        if (_root.暂停) {
            // 重置并清空消弹队列，确保暂停期间不会累积消弹区域
            BulletCancelQueueProcessor.reset();

            // 清空所有子弹队列，确保暂停期间不会累积子弹
            var __k:String;
            var __q:BulletQueue;
            for (__k in activeQueues) {
                __q = activeQueues[__k];
                __q.clear();
            }
            // deferral=B 持久射线跨帧携带 state；暂停只冻结，不清空。
            // reset/场景切换才负责 removeMovieClip + 清空，防 RayCollider MC 泄漏。
            return;
        }

        // ---- 射线子弹独立处理（优先于主循环，零主循环开销）----
        processRayBullets();

        // ================================================================
        // 性能优化说明：
        // - 内联展开executeLogic以消除高频函数调用开销
        // - sortByLeftBoundary和clear保留函数调用（每帧仅调用数次）
        // - 所有热点代码完全内联，最小化栈帧切换成本
        // ================================================================

        // 子弹类型标志位（通过宏引入，用于位运算判断）
        // FLAG_CHAIN: 联弹标志 - 需要精确多边形碰撞检测
        // FLAG_MELEE: 近战标志 - 触发硬直，不受消弹影响
        // FLAG_PIERCE: 穿透标志 - 可贯穿多个目标
        // FLAG_EXPLOSIVE: 爆炸标志 - 特殊终止处理
        // FLAG_UNIT_BULLET: 可拦截单位子弹标志 - Z轴宽容判定
        // 标志位可叠加使用，如 FLAG_MELEE | FLAG_PIERCE 表示穿透近战弹
        #include "../macros/FLAG_CHAIN.as"
        #include "../macros/FLAG_MELEE.as"
        #include "../macros/FLAG_PIERCE.as"
        #include "../macros/FLAG_EXPLOSIVE.as"
        #include "../macros/FLAG_UNIT_BULLET.as"

        // 实例状态标志位（用于硬直免疫检测和击中地图检测）
        #include "../macros/STATE_NO_STUN.as"
        #include "../macros/STATE_HIT_MAP.as"
        
        // 批处理前的通用初始化
        var gameWorld:MovieClip = _root.gameworld;
        var debugMode:Boolean = _root.调试模式;
        var MELEE_EXPLOSIVE_MASK:Number = FLAG_MELEE | FLAG_EXPLOSIVE;
        var PIERCE_LIMIT_REMOVE:Number = KF_PIERCE_LIMIT_REMOVE;
        var MODE_VANISH:Number = KF_MODE_VANISH;
        var MODE_REMOVE:Number = KF_MODE_REMOVE;
        var REASON_UNIT_HIT:Number = KF_REASON_UNIT_HIT;  // 缓存命中单位的原因标志

        // 外部静态系统引用缓存（AS2中减少作用域链查找）
        var shotgunGroup:ChainGroup;
        var isShotgunPattern:Boolean;
        var Dodge:Object = DodgeHandler;
        var Damage:Object = DamageCalculator;
        var FX:Object = EffectSystem;
        var CFR:Object = ColliderFactoryRegistry;
        var PolyFactoryId:String = ColliderFactoryRegistry.PolygonFactory;
        var stunTime:Number = _root.钝感硬直时间;

        // === 仅准备一次消弹区域缓存，供所有阵营复用 ===
        // prepareIfActive()：无消弹时 O(1) 返回 false，有消弹时完成索引排序
        // 直接引用 BulletCancelQueueProcessor 的 public 静态数组，消除中间 Object 分配
        var hasCZ:Boolean = BulletCancelQueueProcessor.prepareIfActive();

        // 消弹 SoA 数组本地别名（减少跨类属性查找开销）
        // 各字段语义：
        //   idxArr:       消弹区域排序索引（按 xMin 升序）
        //   xMinArr/xMaxArr/yMinArr/yMaxArr: 消弹区域 AABB（gameworld 坐标系）
        //   shootZArr:    消弹区域的 Z 轴基准高度
        //   zRangeArr:    消弹区域的 Z 轴有效范围
        //   dirCodeArr:   方向过滤码（0=全向，1=向右，-1=向左）
        //   isEnemyArr:   区域阵营标识（与 bullet.是否为敌人 比较，相同则跳过）
        //   isBounceArr:  是否反弹模式
        //   isPowerfulArr:是否强力消弹（穿透弹会直接移除）
        //   shooterArr:   反弹模式下的新发射者名称
        var idxArr:Array     = BulletCancelQueueProcessor.sortIdx;
        var xMinArr:Array    = BulletCancelQueueProcessor.xMin;
        var xMaxArr:Array    = BulletCancelQueueProcessor.xMax;
        var yMinArr:Array    = BulletCancelQueueProcessor.yMin;
        var yMaxArr:Array    = BulletCancelQueueProcessor.yMax;
        var shootZArr:Array  = BulletCancelQueueProcessor.shootZ;
        var zRangeArr:Array  = BulletCancelQueueProcessor.zRange;
        var dirCodeArr:Array = BulletCancelQueueProcessor.dirCode;
        var isEnemyArr:Array = BulletCancelQueueProcessor.isEnemy;
        var isBounceArr:Array    = BulletCancelQueueProcessor.isBounce;
        var isPowerfulArr:Array  = BulletCancelQueueProcessor.isPowerful;
        var shooterArr:Array     = BulletCancelQueueProcessor.shooter;

        var areaLen:Number = hasCZ ? BulletCancelQueueProcessor.soaLen : 0;

        // ================================================================
        // 统一变量声明区域（性能热点优化：避免循环内重复var声明开销）
        // ================================================================

        // ---- 队列上下文管理变量 ----
        var key:String;                     // 当前处理的阵营键名（如"PLAYER", "ENEMY", FRIENDLY_FIRE_KEY等）
        var q:BulletQueue;                  // 当前阵营的子弹队列实例
        var n:Number;                       // 队列中子弹数量（用于空队列早退判断）
        var frameId:Number;                 // 当前帧ID
        var queueUID:Number;                // 队列唯一标识符
        var queueStamp:Number;              // 队列时间戳（frameId和queueUID组合）

        // ---- 已排序子弹数据 ----
        var sortedArr:Array;                // 按左边界排序后的子弹数组引用
        var sortedLength:Number;            // 排序数组长度快照（避免重复length查询）

        // ---- 目标缓存系统 ----
        var cache:SortedUnitCache;          // 排序后的单位缓存对象
        var fakeUnit:Object;                // 阵营代理单位（用于查询缓存键）

        // ---- 双指针扫描线算法缓冲区 ----
        var unitMap:Array;                  // 目标单位映射数组
        var unitRightKeys:Array;            // 目标单位右边界键值数组（用于扫描优化）
        var unitLeftKeys:Array;             // 目标单位左边界键值数组（用于碰撞窗口计算）
        var bulletLeftKeys:Array;           // 子弹左边界键值数组
        var bulletRightKeys:Array;          // 子弹右边界键值数组
        var sweepIndex:Number;              // 扫描线当前索引位置
        var len:Number;                     // 目标数组长度（循环边界）

        // ---- 消弹区域处理变量（阶段1专用） ----
        var cancelToken:Array;              // 消弹结果token数组
        var cancelBounceShooter:Array;      // 反弹发射者数组
        var hasCancelResult:Boolean;        // 是否有消弹结果
        var areaPtr:Number;                 // 消弹区域指针
        var bulletPtr:Number;               // 子弹指针（消弹扫描用）
        var areaIdx:Number;                 // 消弹区域索引
        var areaMin:Number;                 // 消弹区域最小X边界
        var areaMax:Number;                 // 消弹区域最大X边界
        var czOff:Number;                   // Z轴偏移（消弹检测）
        var czr:Number;                     // Z轴范围（消弹检测）
        var d:Number;                       // 方向代码
        var bdir:Number;                    // 子弹方向
        var bx:Number;                      // 子弹X坐标
        var by:Number;                      // 子弹Y坐标
        var mode:Number;                    // 消弹模式

        // ---- 子弹遍历状态变量 ----
        var bulletIndex:Number;             // 子弹数组遍历索引（原idx）
        var bullet:MovieClip;               // 当前处理的子弹实例
        var flags:Number;                   // 子弹类型标志位（联弹、近战、穿透等）
        var areaAABB:AABBCollider;          // 子弹的AABB碰撞检测器
        var isPointSet:Boolean;             // 是否需要精确多边形碰撞检测（旋转联弹）
        var rot:Number;                     // 子弹旋转角度（仅联弹需要）
        var bulletZOffset:Number;           // 子弹Z轴坐标
        var bulletZRange:Number;            // 子弹Z轴攻击范围
        var killFlags:Number;               // 子弹终止标志位（命中、穿透上限等）
        var shooter:MovieClip;              // 子弹发射者实例
        var Lb:Number;                      // 子弹左边界
        var Rb:Number;                      // 子弹右边界
        var skipUnits:Boolean;              // 是否跳过单位碰撞检测
        var isUpdatePolygon:Boolean;        // 多边形碰撞器是否已更新
        var needsDeferScatter:Boolean;      // 是否需要影子记账（仅联弹子弹）

        var wantDestroy:Boolean;            // 早退销毁路径控制

        // ---- 消弹状态变量 ----
        var token:Number;                   // 当前子弹的消弹token
        var stamp:Number;                   // token中的时间戳部分
        var valid:Boolean;                  // token是否有效
        var tokenMode:Number;               // 消弹模式（0=NONE, 1=VANISH, 2=REMOVE, 3=BOUNCE）
        var bounceShooter:String;           // 反弹发射者名称

        // ---- 碰撞检测变量 ----
        var queryLeft:Number;               // 子弹左边界查询坐标
        var startIndex:Number;              // 目标扫描起始索引
        var hitTarget:MovieClip;            // 当前命中的目标单位
        var zOffset:Number;                 // Z轴偏移量（子弹与目标的高度差）
        var unitArea:AABBCollider;          // 目标单位的AABB碰撞检测器
        var collisionResult:CollisionResult; // 碰撞检测结果对象
        var polygonCollider:ICollider;      // 多边形碰撞检测器（精确检测用）
        var unitIndex:Number;               // 单位遍历索引（原i）
        var i:Number;                       // 通用循环索引（用于消弹区域遍历）
        var uTop:Number;                    // 目标AABB上边界（含Z偏移投影）
        var uBottom:Number;                 // 目标AABB下边界（含Z偏移投影）
        var crCenter:Vector;                // overlapCenter缓存（避免重复属性链访问）

        // ---- 命中后处理变量 ----
        // 注：isNormalKill/damageResult/targetDispatcher/targetX/targetY 随 settleHit 抽取（阶段1）已下沉进 settleHit，此处移除其死声明。
        var shouldStun:Boolean;             // 是否应该硬直
        var isPierce:Boolean;               // 是否穿透
        var dodgeState:String;              // 闪避状态
        var hasUnitHitFx:Boolean;            // 当前弹体本轮是否至少有 actual/NULL 单位命中 FX
        var settlementResult:Object;         // 当前几何节点的伤害结算结果（NULL 仍保留命中 FX）

        // ---- 射弹预警变量（Phase 2+ 尾循环）----
        var hasTZ:Boolean;              // 全局门控：是否有单位订阅 bulletThreat
        var effectiveRb:Number;         // 预警扩展右边界（空窗快判用）
        var warnRb:Number;              // 尾循环终止边界 = Rb + WARN_PAD_X
        var warnTarget:MovieClip;       // 预警循环当前目标
        var warnZOff:Number;            // Z 偏移
        var warnEta:Number;             // 到达帧数估算
        var warnDx:Number;              // X 距离
        var warnSpd:Number;             // X 速度绝对值
        var warnPredictY:Number;        // Y 轴线性外推预测位置
        var wi:Number;                  // 左向预警反向扫描索引

        // ================================================================
        // 主处理循环：按阵营遍历所有活动队列
        // ================================================================

        // 获取当前帧ID（每帧恒定，提到队列循环外）
        frameId = _root.帧计时器.当前帧数;

        for (key in activeQueues) {

            q = activeQueues[key];

            // ---- 空队列优化：早期退出避免无效计算 ----
            n = q.getCount();
            if (n == 0) continue;

            // 使用预计算的 UID，避免每帧重复调用 Dictionary.getStaticUID()
            // 旧实现（已优化）：
            //   fakeUnit = fakeUnits[key];
            //   queueUID = Dictionary.getStaticUID(fakeUnit) & 0x0FFF; // 每帧调用+位运算
            // 新实现：直接查表获取初始化时预计算的12位UID
            queueUID = queueUIDs[key];  // O(1) 对象属性查找，避免函数调用
            queueStamp = (frameId << 12) | queueUID;

            // ---- 子弹排序：按左边界排序以优化扫描线算法 ----
            q.sortByLeftBoundary();

            // _root.服务器.发布服务器消息(key + " : " + q.toString()); // 调试输出当前队列状态

            // ---- 获取排序后数据：避免重复方法调用的性能开销 ----
            sortedArr = q.getBulletsReference();        // 排序后子弹数组的直接引用
            sortedLength = sortedArr.length;            // 长度快照，避免.length属性重复查询

            // ---- 阵营单位获取：用于目标缓存查询 ----
            fakeUnit = fakeUnits[key];  // 获取阵营代理单位（用于缓存查询）

            // ---- 目标缓存获取：根据阵营类型选择合适的缓存策略 ----
            if(key == FRIENDLY_FIRE_KEY) {
                // 友伤模式：获取所有单位（包括友军）
                // updateInterval=1 强制每帧刷新缓存，保证碰撞检测使用最新数据
                cache = TargetCacheManager.acquireAllCache(fakeUnit, 1);
            } else {
                // 敌对模式：仅获取敌方单位
                // updateInterval=1 强制每帧刷新缓存，避免碰撞检测读取超期数据
                cache = TargetCacheManager.acquireEnemyCache(fakeUnit, 1);
            }

            // ---- 双指针扫描线数据准备：核心优化算法的数据基础 ----
            unitMap = cache.data;                       // 目标单位实例数组
            // 使用 rightMaxValues（right 前缀最大值）作为扫描线推进键：保证单调性，避免单位宽度变化导致跳过不安全
            unitRightKeys = cache.rightMaxValues != undefined ? cache.rightMaxValues : cache.rightValues;
            unitLeftKeys = cache.leftValues;            // 目标左边界数组（用于碰撞窗口判断）
            len = unitMap.length;                       // 目标遍历边界（整个队列处理期间不变）
            bulletLeftKeys = q.getLeftKeysRef();        // 子弹左边界数组（查询起点）
            bulletRightKeys = q.getRightKeysRef();      // 子弹右边界数组（截断终点）
            sweepIndex = 0;                             // 扫描线索引重置

            // ---- 射弹预警门控：全局开关，O(1)布尔检查 ----
            hasTZ = BulletThreatScanProcessor.hasListeners();

            // --- UnitBullet 诊断：目标缓存内容（调试完成后注释） ---
            // if (key == "PLAYER" && len > 0 && (frameId % 30) == 0) {
            //     var __ubDiag:String = "[UB Sweep] PLAYER targets=" + len;
            //     for (var __di:Number = 0; __di < len; __di++) {
            //         var __du:Object = unitMap[__di];
            //         if (__du.element != undefined) {
            //             var __da = __du.aabbCollider;
            //             __ubDiag += " | EL:" + __du._name
            //                 + " L=" + Math.round(__da.left) + " R=" + Math.round(__da.right)
            //                 + " T=" + Math.round(__da.top) + " B=" + Math.round(__da.bottom)
            //                 + " Z=" + Math.round(__du.Z轴坐标)
            //                 + " hp=" + __du.hp;
            //         }
            //     }
            //     _root.服务器.发布服务器消息(__ubDiag);
            // }

            // --- 调试期单位池预检与清洗 ---
            if (false) {
                var __pc:Object = __debugPrecheckAndCleanUnitArrays(unitMap, unitLeftKeys, unitRightKeys, key);
                if (__pc != null) {
                    unitMap       = __pc.map;
                    unitLeftKeys  = __pc.left;
                    unitRightKeys = __pc.right;
                    len           = __pc.len;

                    _root.服务器.发布服务器消息(cache.getStatusReport());
                }
            }

            // ================================================================
            // 阶段1：消弹区域与子弹的双扫描线预处理
            //
            // 跳过规则（按顺序检查，任一满足即continue）：
            // 1. token已被本队列本帧写入 -> 跳过（避免重复处理）
            // 2. 近战子弹(FLAG_MELEE) -> 跳过（近战不受消弹影响）
            // 3. 静止子弹(xmov==0 && ymov==0) -> 跳过（静止弹不参与消弹）
            // 4. 同阵营(isEnemyArr==是否为敌人) -> 跳过（同阵营区域不消同阵营子弹）
            // 5. 方向不匹配(dirCode!=0且方向相反) -> 跳过（定向区域过滤）
            // 6. Z轴超出范围 -> 跳过（高度差超过有效范围）
            // 7. XY坐标在区域外 -> 跳过（位置不在消弹区域内）
            // ================================================================
            cancelToken = null;
            cancelBounceShooter = null;
            hasCancelResult = false;
            if (hasCZ && sortedLength > 0 && areaLen > 0) {
                cancelToken = _cancelToken;
                cancelBounceShooter = _cancelBounceShooter;

                bulletPtr = 0;
                // 所有变量已在函数开头声明
                for (areaPtr = 0; areaPtr < areaLen; ++areaPtr) {
                    areaIdx = idxArr[areaPtr];
                    areaMin = xMinArr[areaIdx];
                    areaMax = xMaxArr[areaIdx];
                    // 循环展开优化：每次跳4个子弹，减少条件判断开销
                    while (bulletPtr + 3 < sortedLength && bulletRightKeys[bulletPtr + 3] < areaMin) {
                        bulletPtr += 4;
                    }
                    // 处理剩余的0-3个子弹
                    while (bulletPtr < sortedLength && bulletRightKeys[bulletPtr] < areaMin) {
                        ++bulletPtr;
                    }
                    for (i = bulletPtr; i < sortedLength && bulletLeftKeys[i] <= areaMax; ++i) {
                        // 基于 token 的逐帧有效性判定
                        token = cancelToken[i];
                        if ((token >>> 2) == queueStamp) continue; // 仅当本队列本帧已写过才跳过
                        bullet = sortedArr[i];
                        flags = bullet.flags;
                        if ((flags & FLAG_MELEE) != 0) continue;
                        // 保护条件：静止子弹不参与消弹检测
                        if (bullet.xmov == 0 && bullet.ymov == 0) continue;
                        if (isEnemyArr[areaIdx] == bullet.是否为敌人) continue;
                        d = dirCodeArr[areaIdx];
                        if (d != 0) {
                            if (bullet.xmov == 0) continue; // 垂直/静止不匹配定向区
                            bdir = (bullet.xmov > 0) ? 1 : -1;
                            if (bdir != d) continue;
                        }
                        czOff = bullet.Z轴坐标 - shootZArr[areaIdx];
                        czr = zRangeArr[areaIdx];
                        if (czOff >= czr || czOff <= -czr) continue;
                        bx = bullet._x;
                        by = bullet._y;
                        if (bx < xMinArr[areaIdx] || bx > xMaxArr[areaIdx] ||
                            by < yMinArr[areaIdx] || by > yMaxArr[areaIdx]) continue;
                        hasCancelResult = true;
                        // 写入 token：低两位为 mode，高位为 queueStamp=(frameId<<12)|queueUID
                        if (isBounceArr[areaIdx]) {
                            mode = 3; // BOUNCE
                            cancelBounceShooter[i] = shooterArr[areaIdx];
                        } else {
                            // 强力消弹且穿透 -> REMOVE，否则 VANISH
                            mode = (isPowerfulArr[areaIdx] && (flags & FLAG_PIERCE) != 0) ? 2 : 1;
                        }
                        cancelToken[i] = (queueStamp << 2) | mode;
                    }
                }
                if (!hasCancelResult) {
                    cancelToken = null;
                    cancelBounceShooter = null;
                }
            }

            var _aabbResult:CollisionResult = AABBCollider.result; // 预缓存静态AABB碰撞结果

            for (bulletIndex = 0; bulletIndex < sortedLength; bulletIndex++) {
                bullet = sortedArr[bulletIndex];
                flags = bullet.flags;
                areaAABB = bullet.aabbCollider;
                
                // 每次弹体循环初始化销毁路径标志
                wantDestroy = false;
                isPointSet = (flags & FLAG_CHAIN) != 0;
                if (isPointSet) {
                    rot = bullet._rotation;
                    isPointSet = rot != 0 && rot != 180;
                }
                shotgunGroup = bullet.chainGroup;
                isShotgunPattern = shotgunGroup.shotgun != null;
                if (isShotgunPattern) isPointSet = false;
                bulletZOffset = bullet.Z轴坐标;          // 子弹Z轴坐标
                bulletZRange = bullet.Z轴攻击范围;       // Z轴攻击范围
                killFlags = 0;
                if (debugMode) {
                    AABBRenderer.renderAABB(areaAABB, 0, "line", bulletZRange);
                }
                shooter = gameWorld[bullet.发射者名];
                Lb = bulletLeftKeys[bulletIndex];
                Rb = bulletRightKeys[bulletIndex];
                // —— 读取 token：是否本帧消弹，以及具体模式
                token = (cancelToken != null) ? (cancelToken[bulletIndex] | 0) : 0; // undefined -> 0
                stamp = token >>> 2;
                valid = ((stamp >>> 12) == frameId) && ((stamp & 0x0FFF) == queueUID);
                tokenMode = valid ? (token & 3) : 0; // 0=NONE,1=VANISH,2=REMOVE,3=BOUNCE

                if (tokenMode == 3) {
                    bounceShooter = cancelBounceShooter ? cancelBounceShooter[bulletIndex] : null;
                    BulletCancelQueueProcessor.handleBounce(bullet, bounceShooter);
                    bullet.updateMovement(bullet);
                    continue;
                }
                if (tokenMode == 1 || tokenMode == 2) {
                    // 旧约定：记账到收尾统一表现
                    killFlags = (tokenMode == 2) ? MODE_REMOVE : MODE_VANISH;
                    bullet.霰弹值 = 1;
                    // 使用位运算直接写入 stateFlags（需在循环外已读取 sf）
                    bullet.stateFlags |= STATE_HIT_MAP;
                }
                skipUnits = (tokenMode == 1 || tokenMode == 2);
                // 阶段2：子弹 vs 单位碰撞检测
                // ================================================================
                if (!skipUnits) {
                    // ---- 影子记账优化：仅对联弹子弹启用（零额外开销for非联弹） ----
                    needsDeferScatter = (flags & FLAG_CHAIN) != 0;
                    if (needsDeferScatter) {
                        __initDeferScatter(bullet);
                    }
                    // ---- 扫描线算法：双指针优化的碰撞检测窗口计算 ----
                        queryLeft = Lb;        // 使用已缓存的子弹左边界
                    // 推进扫描线：跳过所有右边界小于子弹左边界的目标
                    // 循环展开优化：每次跳4个，减少循环判断开销
                    while (sweepIndex + 3 < len && unitRightKeys[sweepIndex + 3] < queryLeft) {
                        sweepIndex += 4;
                        // _root.服务器.发布服务器消息("快速推进4步至索引 " + sweepIndex); // 调试输出
                    }
                    // 处理剩余的0-3个元素
                    while (sweepIndex < len && unitRightKeys[sweepIndex] < queryLeft) {
                        ++sweepIndex;
                    }
                    startIndex = sweepIndex;                // 记录有效检测的起始索引
                    // ---- 空窗口快判：O(1)时间复杂度，避免无效循环开销 ----
                    effectiveRb = (hasTZ && bullet.xmov > 0) ? (Rb + WARN_PAD_X) : Rb;
                    if (startIndex >= len || effectiveRb < unitLeftKeys[startIndex]) {

                        // 【僵尸子弹防御】优先检查边界标志，防止隧穿出地图的子弹逃逸
                        // 背景：高速子弹可能隧穿出地图边界，此时shouldDestroy中的
                        // collisionLayer.hitTest会失效（边界外返回false），导致子弹永久存活
                        // 修复：在空窗口阶段强制检查击中地图标志，确保边界外子弹被及时销毁
                        // 读取实例状态标志位，检测击中地图标志
                        var sfCheck:Number = bullet.stateFlags | 0;
                        if ((sfCheck & STATE_HIT_MAP) != 0) {
                            // 标记销毁意图，交给统一收尾处理
                            wantDestroy = true;
                            killFlags |= MODE_VANISH;
                            startIndex = len;
                        }
                        // 【极快路径】无销毁需求 → 维持旧逻辑，最快早退
                        // 例外：左向子弹需执行预警左侧反向扫描 → 不能 continue
                        else if (!bullet.shouldDestroy(bullet)) {
                            if (hasTZ && bullet.xmov < 0) {
                                // 碰撞循环因空窗条件自然 0 迭代
                                // 落入 Phase 2+ 预警左侧反向扫描
                            } else {
                                bullet.updateMovement(bullet);
                                if (needsDeferScatter) {
                                    __commitDeferScatter(bullet);
                                }
                                continue;
                            }
                        }
                        // 【需要销毁】不在这里做释放/FX/移除，只声明"终止意图"，交给单出口收尾
                        else {
                            wantDestroy = true;
                            killFlags |= MODE_VANISH;
                            // 跳过单位循环（但不 continue），让流程落到统一尾部
                            startIndex = len;
                        }
                    }
                    // ---- 击中后效果标志：确保命中时能正确触发效果 ----
                    bullet.shouldGeneratePostHitEffect = true;
                    hasUnitHitFx = false;

                    // ---- 子弹类型预计算：直接使用位运算结果作为条件判断 ----
                    // ---- 命中上下文：per-bullet 不变量打包，供统一 settleHit（§4.0 (a)；对齐 _rayHitCtx）----
                    // （原 isNormalKill 预计算移入 settleHit 内部，从 ctx.flags & ctx.meleeMask 求得）
                    _hitCtx.bullet = bullet;
                    _hitCtx.shooter = shooter;
                    _hitCtx.Damage = Damage;
                    if (isShotgunPattern) _hitCtx.Dodge = Dodge;
                    _hitCtx.flags = flags;
                    _hitCtx.meleeMask = MELEE_EXPLOSIVE_MASK;
                    // 近战硬直：近战类型 && 非硬直免疫（STATE_NO_STUN 位为0）
                    shouldStun = (flags & FLAG_MELEE) != 0 && ((bullet.stateFlags | 0) & STATE_NO_STUN) == 0;
                    isPierce = (flags & FLAG_PIERCE) != 0;  // 穿透
                    // 注意：当前实现下，若同时标记 MELEE 与 PIERCE，则命中时不会触发硬直（由 !isPierce 分支控制）

                    // ---- 多边形更新控制：避免同一子弹重复更新碰撞器 ----
                    isUpdatePolygon = false;

                    // ----------- 命中循环（带右边界截断） -----------
                    for (unitIndex = startIndex; unitIndex < len && unitLeftKeys[unitIndex] <= Rb; ++unitIndex) {
                        hitTarget = unitMap[unitIndex];  // 只读取目标，延迟写入

                        // --- UnitBullet 碰撞诊断（调试完成后注释） ---
                        // if (hitTarget.element != undefined && hitTarget.element === hitTarget) {
                        //     unitArea = hitTarget.aabbCollider;
                        //     zOffset = bulletZOffset - hitTarget.Z轴坐标;
                        //     _root.服务器.发布服务器消息("[UB Col] bullet=" + bullet._name
                        //         + " target=" + hitTarget._name
                        //         + " bAABB=[" + Math.round(areaAABB.left) + "," + Math.round(areaAABB.right) + "," + Math.round(areaAABB.top) + "," + Math.round(areaAABB.bottom) + "]"
                        //         + " uAABB=[" + Math.round(unitArea.left) + "," + Math.round(unitArea.right) + "," + Math.round(unitArea.top) + "," + Math.round(unitArea.bottom) + "]"
                        //         + " zOff=" + Math.round(zOffset) + " zRange=" + bulletZRange
                        //         + " uTop=" + Math.round(unitArea.top + zOffset) + " uBot=" + Math.round(unitArea.bottom + zOffset)
                        //         + " Zpass=" + (!(zOffset >= bulletZRange || zOffset <= -bulletZRange))
                        //         + " Xpass=" + (!(areaAABB.left >= unitArea.right))
                        //         + " Ypass=" + (!(areaAABB.bottom <= (unitArea.top + zOffset) || areaAABB.top >= (unitArea.bottom + zOffset)))
                        //     );
                        // }

                        // Z 轴粗判（避免Math.abs函数调用开销）
                        // UnitBullet（可拦截子弹）使用宽容 effectiveRange = bulletZRange + zTolerance
                        // 解决飞行物 shootZ 与攻击子弹 bulletZOffset 存在小幅偏差时被误判跳过的问题
                        zOffset = bulletZOffset - hitTarget.Z轴坐标;
                        var effectiveRange:Number = ((hitTarget.flags & FLAG_UNIT_BULLET) != 0)
                            ? bulletZRange + (hitTarget.unitBulletZTolerance | 0)
                            : bulletZRange;
                        if (zOffset >= effectiveRange || zOffset <= -effectiveRange) {
                            continue;
                        }

                        // hitTarget !== bullet: 防御性自碰撞剔除
                        // UnitBullet 同时存在于 BulletQueue（作为子弹）和 TargetCache（作为单位），
                        // 当前阵营路由已保证同阵营不交叉，但保留零开销指针比较作为安全兜底
                        if (hitTarget.hp > 0 && hitTarget.防止无限飞 != true && hitTarget !== bullet) {
                            unitArea = hitTarget.aabbCollider;

                            // 扫描线特化AABB宽相检测（全内联，依赖 ICollider C2 不变量）
                            // 前置条件：areaAABB/unitArea 的 left/right/top/bottom 已由各自 update 方法维护
                            // X-left分离已由扫描线右截断保证（unitLeftKeys[i] <= Rb）
                            // getAABB内联：仅Y坐标需要zOffset投影，X坐标直接使用
                            uTop = unitArea.top + zOffset;
                            uBottom = unitArea.bottom + zOffset;
                            if (areaAABB.left >= unitArea.right ||
                                areaAABB.bottom <= uTop ||
                                areaAABB.top >= uBottom) {
                                continue;
                            }

                            // 多边形碰撞器的懒加载与生命周期管理
                            // 契约说明：
                            // 1. 创建时机：首次需要精确碰撞检测时懒创建（减少60-80%内存占用）
                            // 2. 更新策略：每帧首次使用时更新一次，同帧后续命中复用
                            // 3. 工厂职责：ColliderFactoryRegistry管理对象池，负责创建和回收
                            // 4. 回收时机：子弹终止时调用releaseCollider归还对象池
                            // 5. 对象池假设：工厂内部维护碰撞器池，避免频繁GC
                            if (isPointSet) {
                                if(!isUpdatePolygon) {
                                    polygonCollider = bullet.polygonCollider;
                                    var chainPolyArea:MovieClip = bullet.子弹区域area || bullet.area;
                                    if (chainPolyArea) {
                                        if(!polygonCollider) {
                                            // 统一懒加载策略：所有点集联弹的多边形碰撞器都在此时创建
                                            // 注意：createFromBullet内部已包含初始更新
                                            polygonCollider = bullet.polygonCollider = CFR.getFactory(PolyFactoryId).createFromBullet(bullet, chainPolyArea);
                                        }
                                        // 更新碰撞器（创建时已包含更新，但既有碰撞器需要显式更新）
                                        polygonCollider.updateFromBullet(bullet, chainPolyArea);
                                    } else {
                                        // 对象化联弹（无 area 子剪辑且无 子弹区域area）：
                                        // 从组碰撞盒数据构造/更新 OBB（扩展方法不在接口内，经无类型引用分发）
                                        var chainPolyFactory = CFR.getFactory(PolyFactoryId);
                                        var chainPolyCollider = polygonCollider;
                                        if(!chainPolyCollider) {
                                            polygonCollider = bullet.polygonCollider = chainPolyFactory.createFromChainObject(bullet);
                                        } else {
                                            chainPolyCollider.updateFromChainObject(bullet);
                                        }
                                    }
                                    isUpdatePolygon = true;
                                } else {
                                    // 后续命中直接使用已更新的碰撞器
                                    polygonCollider = bullet.polygonCollider;
                                }

                                collisionResult = polygonCollider.checkCollision(unitArea, zOffset);

                                // 如果更精确的多边形检测都没有碰撞，则跳过这个目标
                                if (!collisionResult.isColliding) {
                                    continue;
                                }
                            } else {
                                // AABB宽相直接命中：填充碰撞结果（窄相路径由各自collider负责）
                                // 未来扩展：Ray窄相在此处增加 else if 分支即可
                                collisionResult = _aabbResult;
                                crCenter = collisionResult.overlapCenter;
                                crCenter.x = (((areaAABB.left > unitArea.left) ? areaAABB.left : unitArea.left) + ((areaAABB.right < unitArea.right) ? areaAABB.right : unitArea.right)) >> 1;
                                crCenter.y = (((areaAABB.top > uTop) ? areaAABB.top : uTop) + ((areaAABB.bottom < uBottom) ? areaAABB.bottom : uBottom)) >> 1;
                            }

                            // 确认命中后才写入hitTarget，避免无效的哈希表操作
                            bullet.hitTarget = hitTarget;

                            if (debugMode) {
                                AABBRenderer.renderAABB(areaAABB, zOffset, "thick");
                                AABBRenderer.renderAABB(unitArea, zOffset, "filled");
                            }

                            // ---------- 命中后的业务处理（完全内联展开） ----------
                            // 使用预声明的局部变量，减少内存分配

                            if (isShotgunPattern) {
                                settlementResult = settleShotgunHit(_hitCtx, hitTarget, collisionResult, unitArea, zOffset);
                                if (settlementResult == null) continue;
                            } else {
                                // --- 上下文填充（hitCount移至伤害计算后） ---
                                bullet.附加层伤害计算 = 0;
                                bullet.命中对象 = hitTarget;

                                // --- 闪避/命中状态（使用预声明变量） ---
                                dodgeState = (bullet.伤害类型 == "真伤") ? "未躲闪" :
                                    Dodge.calculateDodgeState(
                                        hitTarget,
                                        Dodge.calcDodgeResult(shooter, hitTarget, bullet.命中率),
                                        bullet
                                    );

                                // --- 统一伤害结算（§4.0 (a)）---
                                // 闪避(上方)→伤害→actual-only 旧钩子→事件；MISS 只保留数字。
                                // dmgMult = collisionResult.overlapRatio（AABB 命中恒为 1，polygon 为真实重叠比，§1.4）。
                                // settleHit 内含：命中对象同步(幂等) → calculateDamage → hitCount+= → publish("hit")
                                //                → kill/death(_killed 守卫) → triggerDisplay。
                                settlementResult = settleHit(_hitCtx, hitTarget, collisionResult,
                                    collisionResult.overlapRatio, dodgeState, true);
                            }
                            if (_hitCtx.actualHit || settlementResult === DamageResult.NULL) {
                                hasUnitHitFx = true;
                            }

                            // --- 终止意图：近战硬直 或 非穿刺 命中即"消失" ---
                            if (!isPierce) {  // 非穿透
                                if (shouldStun) {  // 应该硬直
                                    shooter.硬直(shooter.man, stunTime);  // 使用缓存的硬直时间
                                }
                                killFlags |= (REASON_UNIT_HIT | MODE_VANISH);  // 使用缓存的常量
                            }
                            if (isShotgunPattern && !ShotgunPattern.hasBudget(bullet)) break;
                        }

                        
                        
                        // 穿刺上限：设置终止标志并结束循环
                        if (bullet.pierceLimit && bullet.pierceLimit < bullet.hitCount) {
                            killFlags |= PIERCE_LIMIT_REMOVE;
                            // _root.发布消息(bullet._name, bullet.hitCount, bullet.pierceLimit);
                            break;
                        }
                    }
                    
                    // 命中后效果（一次性）
                    if (hasUnitHitFx && bullet.shouldGeneratePostHitEffect) {
                        FX.Effect(bullet.击中后子弹的效果, bullet._x, bullet._y, shooter._xscale, undefined, true);
                    }
                    // ---- 影子记账提交：仅对已初始化的联弹子弹 ----
                    if (needsDeferScatter) {
                        __commitDeferScatter(bullet);
                    }

                    // ============================================================
                    // Phase 2+: 射弹预警（方向感知双向扫描 + AABB 边缘 ETA）
                    //
                    // xmov > 0 → 右侧尾循环：unitIndex 衔接碰撞循环，扫 (Rb, Rb+WARN_PAD_X]
                    // xmov < 0 → 左侧反向扫描：从 startIndex-1 向左回扫
                    // ETA 使用 AABB 边缘距离（非锚点 _x）
                    // 门控：hasTZ=true 且子弹未被终止
                    // ============================================================

                    // ── 右侧尾循环（xmov > 0：子弹向右飞，预警右方单位）──
                    if (hasTZ && bullet.xmov > 0 && (killFlags & (MODE_VANISH | MODE_REMOVE)) == 0) {
                        warnRb = Rb + WARN_PAD_X;
                        for (; unitIndex < len && unitLeftKeys[unitIndex] <= warnRb; ++unitIndex) {
                            warnTarget = unitMap[unitIndex];

                            // (1) 订阅门控
                            if (warnTarget._btEnabled != true) continue;

                            // (2) 存活过滤
                            if (warnTarget.hp <= 0) continue;

                            // (3) Z 粗判
                            warnZOff = bulletZOffset - warnTarget.Z轴坐标;
                            if (warnZOff >= bulletZRange || warnZOff <= -bulletZRange) continue;

                            // (4) AABB 边缘 ETA：目标左边界 - 子弹右边界
                            warnDx = unitLeftKeys[unitIndex] - Rb;
                            if (warnDx < 0) warnDx = 0; // 重叠：即将命中
                            warnEta = warnDx / bullet.xmov; // xmov > 0
                            if (warnEta > ETA_MAX_FRAMES) continue;

                            // (5) Y 走廊预测（线性外推 + WARN_PAD_Y 容差）
                            warnPredictY = bullet._y + bullet.ymov * warnEta;
                            unitArea = warnTarget.aabbCollider;
                            uTop = unitArea.top + warnZOff;
                            uBottom = unitArea.bottom + warnZOff;
                            if (warnPredictY < uTop - WARN_PAD_Y || warnPredictY > uBottom + WARN_PAD_Y) continue;

                            // (6) 节流：同帧同单位仅累积
                            if (warnTarget._btFrame != frameId) {
                                warnTarget._btFrame = frameId;
                                warnTarget._btCount = 0;
                                warnTarget._btMinETA = 9999;
                                warnTarget._btDirX = 0;
                            }
                            warnTarget._btCount++;
                            if (warnEta < warnTarget._btMinETA) {
                                warnTarget._btMinETA = warnEta;
                                warnTarget._btShooter = shooter;
                            }
                            warnTarget._btDirX += 1;
                        }
                    }

                    // ── 左侧反向扫描（xmov < 0：子弹向左飞，预警左方单位）──
                    // startIndex 左侧的单位已被 sweepIndex 跳过（unitRightKeys < Lb），
                    // 其实际右边界 < Lb，即在子弹左方——正是左飞子弹的预警目标。
                    if (hasTZ && bullet.xmov < 0 && (killFlags & (MODE_VANISH | MODE_REMOVE)) == 0) {
                        warnSpd = -bullet.xmov; // 取绝对值（xmov < 0）
                        for (wi = startIndex - 1; wi >= 0; --wi) {
                            // 终止条件：单位左边界距子弹太远（WARN_PAD_X + 300 容许最大单位宽度）
                            if (Lb - unitLeftKeys[wi] > WARN_PAD_X + 300) break;

                            warnTarget = unitMap[wi];

                            // (1) 订阅门控
                            if (warnTarget._btEnabled != true) continue;

                            // (2) 存活过滤
                            if (warnTarget.hp <= 0) continue;

                            // (3) Z 粗判
                            warnZOff = bulletZOffset - warnTarget.Z轴坐标;
                            if (warnZOff >= bulletZRange || warnZOff <= -bulletZRange) continue;

                            // (4) AABB 边缘 ETA：子弹左边界 - 目标右边界
                            unitArea = warnTarget.aabbCollider;
                            warnDx = Lb - unitArea.right;
                            if (warnDx < 0) warnDx = 0; // 重叠：即将命中
                            warnEta = warnDx / warnSpd;
                            if (warnEta > ETA_MAX_FRAMES) continue;

                            // (5) Y 走廊预测
                            warnPredictY = bullet._y + bullet.ymov * warnEta;
                            uTop = unitArea.top + warnZOff;
                            uBottom = unitArea.bottom + warnZOff;
                            if (warnPredictY < uTop - WARN_PAD_Y || warnPredictY > uBottom + WARN_PAD_Y) continue;

                            // (6) 节流
                            if (warnTarget._btFrame != frameId) {
                                warnTarget._btFrame = frameId;
                                warnTarget._btCount = 0;
                                warnTarget._btMinETA = 9999;
                                warnTarget._btDirX = 0;
                            }
                            warnTarget._btCount++;
                            if (warnEta < warnTarget._btMinETA) {
                                warnTarget._btMinETA = warnEta;
                                warnTarget._btShooter = shooter;
                            }
                            warnTarget._btDirX += -1;
                        }
                    }
                } // end if (!skipUnits)

                // 与原实现一致：执行段末尾做一次位移更新
                bullet.updateMovement(bullet);
                
                // ---------------- 单出口收尾 ----------------
                if (killFlags != 0 || wantDestroy || bullet.shouldDestroy(bullet)) {
                    // 碰撞器回收已迁移至 BulletLifecycle.bindSafeRemove()
                    // 通过重写子弹的 removeMovieClip 方法，在子弹真正销毁时才回收碰撞器
                    // 这解决了消失动画期间碰撞器被提前回收导致的AABB污染问题

                    // 读取实例状态标志位，检测击中地图标志（用于收尾判断）
                    var sfFinal:Number = bullet.stateFlags | 0;
                    var hitMapFinal:Boolean = (sfFinal & STATE_HIT_MAP) != 0;

                    // 地图命中表现（收尾统一触发）
                    // 注意：消弹token决策（tokenMode=1/2）优先级高于单位命中流程
                    // 已在前面设置击中地图标志的情况下，此处统一处理表现
                    if (hitMapFinal) {
                        FX.Effect(bullet.击中地图效果, bullet._x, bullet._y, 100, undefined, true);
                        fireMapHitHook(bullet);
                    }

                    // 子弹终止优先级处理表：
                    // ┌──────────────────┬────────────────┬──────────────┐
                    // │ 条件              │ 处理方式       │ 优先级        │
                    // ├──────────────────┼────────────────┼──────────────┤
                    // │ MODE_REMOVE      │ removeMovieClip│ 最高（1）    │
                    // │ MODE_VANISH      │ gotoAndPlay    │ 次高（2）    │
                    // │ STATE_HIT_MAP    │ gotoAndPlay    │ 中等（3）    │
                    // │ shouldDestroy    │ removeMovieClip│ 最低（4）    │
                    // └──────────────────┴────────────────┴──────────────┘
                    if ((killFlags & MODE_REMOVE) != 0) {
                        // 优先级1：直接移除（强力消弹+穿透弹）
                        // _root.发布消息("rank 1: removeMovieClip");
                        bullet.removeMovieClip();
                    } else if ((killFlags & MODE_VANISH) != 0 || hitMapFinal) {
                        // 优先级2-3：播放消失动画（普通消弹或击中地图）
                        // _root.发布消息("rank 2/3: gotoAndPlay 消失");
                        bullet.gotoAndPlay("消失");
                    } else {
                        // 优先级4：其他情况默认移除
                        // _root.发布消息("rank 4: removeMovieClip by shouldDestroy");
                        bullet.removeMovieClip();
                    }
                }
            }
            // === 内联 executeLogic 遍历结束 ===

            // 清空队列（仅调用一次，保留函数调用）
            q.clear();
            cancelToken = null;
            cancelBounceShooter = null;
        }

        // 帧结束清理：仅在有消弹区域时清空缓存，防止旧区域"复活"
        if (hasCZ) {
            BulletCancelQueueProcessor.endFrame();
        }
    }

    /**
     * 初始化影子记账：原位位编码方案（私有热点路径方法）
     *
     * 【编码格式】
     * bullet.霰弹值 = -((S₀ << 16) | S₀)
     *   高16位 = S₀（基准值，窗口内不变，用于伤害公式的期望估算）
     *   低16位 = available（剩余可用值，每次命中递减）
     *   取负 = 影子模式标记（有效霰弹值恒为正，负值无歧义）
     *
     * 【甄别阈值】sc < -65535
     *   S₀ ≥ 1 时编码值 ≤ -65537（因 (1<<16)|any ≥ 65536，取负 ≤ -65536）
     *   使用 < 而非 <=：规避 AS2 的 NaN <= x 恒 true 陷阱
     *   NaN < -65535 → undefined → falsy：天然安全
     *
     * 【核心契约】（热路径零防御，以下契约必须严格遵守）
     *
     * C1: 霰弹值值域保证（Init 前置条件）
     *   bullet.霰弹值 在进入影子窗口前必须为正整数且 ≤ 32767
     *   责任方：BulletFactory / BulletInitializer / 装备函数
     *   违约后果：高位溢出导致 >>> 16 解码错误
     *   审计基线：当前最大值 ~80（G1111），远低于上限
     *
     * C2: 窗口内独占写入
     *   影子窗口内，仅 MultiShotDamageHandle 和 __commitDeferScatter 可写入 bullet.霰弹值
     *   责任方：所有命中事件订阅者、击中时触发函数、DamageHandle 链
     *   违约后果：外部写入正数覆盖编码值 → commit 不触发 → 消耗静默丢失
     *   审计确认（2026-03，2026-06-22 收窄）：击中时触发函数不写入 bullet.霰弹值（C2 所需仅此一点）；
     *     其"仅发射新子弹"系旧表述过度泛化——实际尚有加buff/停弹/gotoAndPlay爆炸/让射手硬直等副作用，
     *     均不碰霰弹值，与本契约无关（详见 docs/子弹命中-伤害双管线拆分-架构设计 §4.0）。hit/enemyKilled 订阅者
     *     不读写 bullet.霰弹值；kill/death 事件参数中无 bullet
     *   防御建议：新增订阅者需读散射信息时，从 damageResult.finalScatterValue 获取
     *
     * C3: 窗口内裸读语义（原位编码新增契约）
     *   除 MultiShotDamageHandle 外的代码读取 bullet.霰弹值 将得到编码负数
     *   已知裸读点：无（2026-03 移除 DamageCalculator 调试方差分支后，窗口内零裸读）
     *   防御建议：未来若需读散射值，从 damageResult 或 handler 内部解码获取
     *
     * C4: 编码不可跨帧持久化
     *   commit 必须在同帧内执行，编码值不可残留到下一帧
     *   保证：processQueue 双出口（正常路径 + 早退路径）均有 commit 守卫
     *   违约后果：下帧读到编码负数 → 伤害计算全面崩溃
     *
     * 【调用约束】
     * - 仅在 processQueue 主循环内调用
     * - 调用时 bullet 保证非空
     *
     * @param bullet 子弹对象（保证非空）
     */
    private static function __initDeferScatter(bullet:Object):Void {
        var s0:Number = bullet.霰弹值;
        if (s0 > 0) {
            // C1 防御性 clamp：唯一允许的运行时守卫
            if (s0 > 32767) s0 = 32767;
            // 高16位存基准值，低16位存可用值（初始相等），整体取负标记影子模式
            bullet.霰弹值 = -((s0 << 16) | s0);
        }
    }

    /**
     * 提交影子记账：解码并回写最终可用值（私有热点路径方法）
     *
     * 从编码负值中提取低16位（available），写回 bullet.霰弹值 为正数。
     * 零 delete 操作：不创建/删除任何动态属性，避免哈希表结构变异。
     *
     * 【调用约束】
     * - 仅在 processQueue 主循环内调用（正常路径 + 早退路径）
     * - 调用时 bullet 保证非空
     *
     * @param bullet 子弹对象（保证非空）
     */
    private static function __commitDeferScatter(bullet:Object):Void {
        var sc:Number = bullet.霰弹值;
        // 甄别：sc < -65535 表示处于影子模式（NaN < x → falsy，安全）
        if (sc < -65535) {
            // 提取低16位 = 最终剩余可用值，回写为正数
            bullet.霰弹值 = (-sc) & 0xFFFF;
        }
        if (bullet.chainGroup.shotgun != null) ChainUnitManager.commitShotgunBudget(bullet.chainGroup);
    }
    // ------------------------------------------------------------------------
    // 调试辅助：单位池预检与清洗（仅调试模式调用）
    //  - 验证长度一致性、NaN/undefined、left<=right、不变式：left非降序
    //  - 发现异常时：记录告警，并在本帧内返回“清洗后”的本地数组以避免整帧 miss
    //  - 不修改缓存源数组（cache.*），避免影响其他系统
    // ------------------------------------------------------------------------
    private static function __debugPrecheckAndCleanUnitArrays(unitMap:Array, unitLeftKeys:Array, unitRightKeys:Array, tag:String):Object {
        var nM:Number = unitMap.length;
        var nL:Number = unitLeftKeys.length;
        var nR:Number = unitRightKeys.length;

        var minLen:Number = nM;
        var issues:Number = 0;
        var msgs:Array = [];

        if (nM != nL || nM != nR) {
            msgs.push("长度不一致 map=" + nM + " left=" + nL + " right=" + nR);
            // 三者取最小，避免越界
            minLen = (nM < nL ? (nM < nR ? nM : nR) : (nL < nR ? nL : nR));
            issues++;
        }

        var cleanedMap:Array = [];
        var cleanedLeft:Array = [];
        var cleanedRight:Array = [];
        var lastLeft:Number = -Infinity;
        var nonMonotonic:Boolean = false;
        var nonMonoIndex:Number = -1;
        var invalidCnt:Number = 0;

        var i:Number;
        for (i = 0; i < minLen; ++i) {
            var u:Object = unitMap[i];
            var L:Number = unitLeftKeys[i];
            var R:Number = unitRightKeys[i];

            // 条目有效性：对象存在 + L/R 为数值 + L<=R
            if (u == undefined || u == null || isNaN(L) || isNaN(R) || (L > R)) {
                if (invalidCnt < 3) {
                    msgs.push("无效条目 i=" + i + " L=" + L + " R=" + R + " u=" + u);
                }
                invalidCnt++;
                continue;
            }

            if (L < lastLeft) {
                if (!nonMonotonic) {
                    nonMonoIndex = i;
                }
                nonMonotonic = true;
            }

            cleanedMap.push(u);
            cleanedLeft.push(L);
            cleanedRight.push(R);
            lastLeft = L;
        }

        if (invalidCnt > 0) {
            issues++;
            msgs.push("无效/NaN/逆界(L>R)条目数量=" + invalidCnt);
        }
        if (nonMonotonic) {
            issues++;
            msgs.push("left 非单调(应升序) 首次发生在 i=" + nonMonoIndex);
        }

        if (issues > 0) {
            var msg:String = "[UnitCache预检][" + tag + "] 发现异常: " + msgs.join(" | ");
            // _root.服务器.发布服务器消息(msg);

            // 如存在非单调问题，对清洗结果按 left 做一次轻量稳定插入排序
            if (nonMonotonic && cleanedLeft.length > 1) {
                var j:Number;
                for (i = 1; i < cleanedLeft.length; ++i) {
                    var l:Number = cleanedLeft[i];
                    var r:Number = cleanedRight[i];
                    var um:Object = cleanedMap[i];
                    j = i - 1;
                    while (j >= 0 && cleanedLeft[j] > l) {
                        cleanedLeft[j + 1]  = cleanedLeft[j];
                        cleanedRight[j + 1] = cleanedRight[j];
                        cleanedMap[j + 1]   = cleanedMap[j];
                        --j;
                    }
                    cleanedLeft[j + 1]  = l;
                    cleanedRight[j + 1] = r;
                    cleanedMap[j + 1]   = um;
                }
            }

            var out:Object = new Object();
            out.map  = cleanedMap;
            out.left = cleanedLeft;
            out.right= cleanedRight;
            out.len  = cleanedMap.length;
            return out;
        }

        return null; // 正常，无需清洗
    }

}
