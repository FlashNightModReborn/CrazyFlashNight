"use strict";
// Bounded real-game integration samples; these are not a new balance target.
const fs=require("fs"),path=require("path"),cp=require("child_process"),crypto=require("crypto");
const {normalizeManifest}=require("../arena-calibration/lib/arena-calibration-core");
const {resolveExpectedRuntimeIdentity}=require("../lib/runtime-process-identity");
const ROOT=path.resolve(__dirname,"../..");
const hash=p=>crypto.createHash("sha256").update(fs.readFileSync(p)).digest("hex");
const write=(p,v)=>fs.writeFileSync(p,JSON.stringify(v,null,2)+"\n",{flag:"wx"});
const boundPaths=["flashswf/arts/new/Codex大头机器人素材.swf","flashswf/arts/new/Codex大刀机器人素材.swf",
 "flashswf/arts/things-new.swf","scripts/asLoader.swf","data/enemy_properties/CF6重制敌人.xml",
 "data/units/units.json","data/items/asset_source_map.xml","launcher/web/modules/arena-unit-catalog.js",
 "tools/cf6-headbot-assets/HeadbotAI.as","tools/cf6-headbot-assets/build.py",
 "tools/cf6-headbot-assets/native-manifest.json","tools/cf6-headbot-assets/balance-inputs.json"];

function createPlan(config){
 if(!/^[a-z0-9][a-z0-9-]{0,47}$/.test(config.experimentId||""))throw Error("Fresh experimentId required");
 for(const key of ["projectRoot","candidateRoot","seedPath","outputDirectory"])
  if(!path.isAbsolute(config[key]||""))throw Error("Explicit absolute "+key+" required");
 const worker=path.resolve(config.projectRoot),output=path.resolve(config.outputDirectory);
 if(!output.startsWith(path.join(ROOT,"tmp")+path.sep))throw Error("Owned output directory required");
 if(!path.resolve(config.candidateRoot).startsWith(path.join(worker,"tmp/runtime-candidates/v2")+path.sep))throw Error("Owned candidate required");
 const sourceBindings=boundPaths.map(p=>({path:p,sha256:hash(path.join(ROOT,p))}));
 for(const row of sourceBindings)if(hash(path.join(worker,row.path))!==row.sha256)throw Error("Worker input differs: "+row.path);
 const identity=resolveExpectedRuntimeIdentity(worker,config.candidateRoot);
 if(identity.runtimeMode!=="isolated_candidate")throw Error("Integration sample requires an isolated candidate");
 const cases=["blue","red"].map(side=>{
  const headbot={type:"兵种470",level:40,sourceId:"headbot-40"};
  const bladebot={type:"兵种465",level:40,sourceId:"bladebot-40"};
  return {caseId:"level40-"+side,repeat:1,timeoutFrames:5400,spawnDistance:650,
   blueRoster:[side==="blue"?headbot:bladebot],redRoster:[side==="red"?headbot:bladebot],
   tags:["cf6-headbot","integration","two-attacks",side],
   plannerReason:"核对真实登记、等级面板、索敌、攻击及死亡。交换阵营保留实际差异，不以胜负反向调整阶段7、档次16。",
   authorityContext:{candidateUnitId:470,candidateSide:side,stage:7,tier:16,rivalUnitId:465,
    level:40,sourceBindings,balanceTarget:"none; integration sample only"}};
 });
 const buildCommit=cp.execFileSync("git",["rev-parse","HEAD"],{cwd:worker,encoding:"utf8",windowsHide:true}).trim();
 const manifest=normalizeManifest({batchId:config.experimentId,buildCommit,
  planner:{name:"cf6-headbot-integration",version:1},repeat:1,timeoutFrames:5400,cases});
 fs.mkdirSync(output,{recursive:true});const manifestPath=path.join(output,"manifest.json");write(manifestPath,manifest);
 const paths=cp.execFileSync("git",["ls-files","-z","--cached","--others","--exclude-standard","--","flashswf","sound","sounds","music","font","fonts"],
  {cwd:worker,maxBuffer:32*1024*1024,windowsHide:true}).toString("utf8").split("\0");
 const resourcePaths=[...new Set(paths.filter(p=>/^flashswf\//.test(p)&&/\.(swf|png|jpg|jpeg|webp|mp3|wav|ogg|mp4|flv|f4v)$/i.test(p)||/^(sounds?|music|fonts?)\//.test(p)))];
 const plan={schema:"arena-worker.experiment-plan.v1",experimentId:config.experimentId,
  workers:[{workerId:"headbot",projectRoot:worker,candidateRoot:config.candidateRoot,seedPath:config.seedPath,resourcePaths}],
  saveRoots:[path.join(ROOT,"saves"),path.join(worker,"saves")],
  sharedObjectsRoot:path.join(process.env.APPDATA,"Macromedia","Flash Player","#SharedObjects"),
  groups:[{groupId:"integration",mode:"serial",condition:"stage7-tier16",visibility:"background-visible",
   performance:{preset:"performance",mode:"fixed",maxRenderHeight:180},
   jobs:[{jobId:"level40-sides",workerId:"headbot",manifestPath,batchTimeoutMs:900000}]}],comparisons:[]};
 const planPath=path.join(output,"experiment-plan.json");write(planPath,plan);
 write(path.join(output,"input-identity.json"),{sourceBindings,runtimeIdentity:identity,expectedRows:2,performanceQualification:false});
 return {planPath,rows:2};
}
if(require.main===module){if(process.argv.length!==3)throw Error("Usage: node arena-plan.js <explicit-config.json>");
 console.log(JSON.stringify(createPlan(JSON.parse(fs.readFileSync(process.argv[2],"utf8")))));}
module.exports={createPlan};
