﻿// CF6 固定身体；借鉴军校生的射程分层，复用 CF7 索敌、移动与伤害权威。
// 手枪复用现役 M1911 外观/音效/枪火；威力仍由本敌人面板控制，不冒充可换装人形。
soldierClock=0;
soldierReadyAt=6;
soldierTargetName="";
soldierAttackOwner=null;
soldierShotCount=0;
soldierStabCount=0;
soldierInvalidMuzzleCount=0;
soldierTuning={shootRange:460,knifeRange:95,laneRange:24,keepDistance:190,
    reactionFrames:6,maximumTargetHeight:85};

soldierCancelAttack=function():Void {
    if(this.soldierAttackOwner!=null) this.soldierAttackOwner.active=false;
    this.soldierAttackOwner=null;
};

soldierBeginAttack=function(body:MovieClip,action:String):Void {
    this.soldierCancelAttack();
    if(!(this.hp>0)) {body.stop();return;}
    var token:Object={};body.soldierToken=token;
    this.soldierAttackOwner={token:token,action:action,active:true,lastHitFrame:0,target:this.攻击目标};
};

soldierCanAct=function(body:MovieClip):Boolean {
    var owner:Object=this.soldierAttackOwner;
    return !_root.暂停 && this.hp>0 && !this.硬直中 && owner!=null && owner.active
        && body===this.man && body.soldierToken===owner.token
        && this.状态==(owner.action=="knife"?"近战":"空手攻击");
};

soldierFinishAttack=function(body:MovieClip):Void {
    var owner:Object=this.soldierAttackOwner;
    if(owner==null || body!==this.man || owner.token!==body.soldierToken) return;
    this.soldierCancelAttack();
    this.动画完毕();
};

soldierMuzzle=function(body:MovieClip):Object {
    var holder:MovieClip=body.soldierGun;
    var gun:MovieClip=holder.gun;
    var marker:MovieClip=gun.枪口位置;
    if(holder._parent!==body || gun._parent!==holder || marker._parent!==gun) return null;
    var p:Object={x:0,y:0};marker.localToGlobal(p);
    var globalY:Number=p.y;
    _root.gameworld.globalToLocal(p);
    if(isNaN(p.x) || isNaN(p.y)) return null;
    p.globalY=globalY;
    return p;
};

soldierShoot=function(body:MovieClip):Void {
    if(!this.soldierCanAct(body)) return;
    var owner:Object=this.soldierAttackOwner;
    if(owner.action!="shoot" || owner.lastHitFrame==body._currentframe) return;
    var p:Object=this.soldierMuzzle(body);
    if(p==null) {this.soldierInvalidMuzzleCount++;return;}
    owner.lastHitFrame=body._currentframe;
    this.soldierShotCount++;
    _root.子弹区域shoot传递({声音:"re_pistol_m1911.wav",霰弹值:1,子弹散射度:4,
        发射效果:"紧凑手枪枪火",子弹种类:"普通子弹",子弹威力:this.空手攻击力,
        子弹速度:20,Z轴攻击范围:24,击中地图效果:"火花",发射者:this._name,
        shootX:p.x,shootY:p.y,shootZ:this.Z轴坐标,转换中间y:p.globalY,
        击倒率:10,击中后子弹的效果:"",角度偏移:0});
};

soldierStab=function(body:MovieClip,point:MovieClip):Void {
    if(!this.soldierCanAct(body) || point.area==null) return;
    var owner:Object=this.soldierAttackOwner;
    if(owner.action!="knife" || owner.lastHitFrame==body._currentframe) return;
    owner.lastHitFrame=body._currentframe;
    var p:Object={x:point._x,y:point._y};body.localToGlobal(p);_root.gameworld.globalToLocal(p);
    this.soldierStabCount++;
    _root.子弹区域shoot传递({声音:"",霰弹值:1,子弹散射度:0,发射效果:"",
        子弹种类:"近战子弹",子弹威力:this.空手攻击力,子弹速度:0,
        Z轴攻击范围:24,击中地图效果:"",发射者:this._name,
        shootX:p.x,shootY:p.y,shootZ:this.Z轴坐标,击倒率:10,
        击中后子弹的效果:"空手攻击火花",水平击退速度:2,垂直击退速度:1,
        区域定位area:point.area});
};

soldierChooseAttack=function(dx:Number,dz:Number,height:Number):String {
    var tune:Object=this.soldierTuning;
    if(isNaN(dx) || isNaN(dz) || isNaN(height) || dx<0 || dz<0
        || dz>tune.laneRange || height>tune.maximumTargetHeight || this.soldierClock<this.soldierReadyAt) return "none";
    if(dx<=tune.knifeRange) return "knife";
    if(dx<=tune.shootRange) return "shoot";
    return "none";
};

soldierTick=function():Void {
    if(_root.暂停) return;
    this.soldierClock++;
    if(!isNaN(this.hp) && this.hp<=0) {
        this.soldierCancelAttack();
        if(this.状态!="血腥死" && this.状态!="消失") this.状态改变("血腥死");
        return;
    }
    var owner:Object=this.soldierAttackOwner;
    if(owner!=null && (this.状态!=(owner.action=="knife"?"近战":"空手攻击")
        || this.man.soldierToken!==owner.token)) this.soldierCancelAttack();
    if(!(this.hp>0) || this.倒地 || this.浮空 || this.硬直中) return;
    if(_root.控制目标==this._name && _root.控制目标全自动==false) return;
    if(this.状态!="空手站立" && this.状态!="空手行走" && this.状态!="空手跑") return;
    if((this.soldierClock&3)!=0) return;
    this.x轴攻击范围=0;this.y轴攻击范围=this.soldierTuning.laneRange;
    this.x轴保持距离=this.soldierTuning.keepDistance;
    if(this.unitAI.data!=null) {
        this.unitAI.data.xrange=0;this.unitAI.data.zrange=this.y轴攻击范围;
        this.unitAI.data.xdistance=this.x轴保持距离;
    }
    var target:MovieClip=_root.gameworld[this.攻击目标];
    if(!(target.hp>0) || target==this || target.area==null) return;
    var dx:Number=target._x-this._x,dz:Number=target.Z轴坐标-this.Z轴坐标;
    var height:Number=target.Z轴坐标-target._y;
    if(target.浮空高度!=undefined && !isNaN(target.浮空高度) && target.浮空高度>0) height+=target.浮空高度;
    if(isNaN(dx) || isNaN(dz) || isNaN(height)) return;
    if(this.soldierTargetName!=target._name) {
        this.soldierTargetName=target._name;
        this.soldierReadyAt=this.soldierClock+this.soldierTuning.reactionFrames;
    }
    var action:String=this.soldierChooseAttack(Math.abs(dx),Math.abs(dz),height);
    if(action=="none") {
        this.上行=dz< -6;this.下行=dz>6;
        this.左行=dx< -this.soldierTuning.keepDistance;this.右行=dx>this.soldierTuning.keepDistance;
        if(Math.abs(dx)>460 && this.状态!="空手跑") this.状态改变("空手跑");
        return;
    }
    this.左行=this.右行=this.上行=this.下行=false;
    if(dx<0) this.方向改变("左");else if(dx>0) this.方向改变("右");
    this.状态改变(action=="knife"?"近战":"空手攻击");
};
