"""CF6 ordinary soldier: native R3 art, CF7 handgun and bounded enemy lifecycle."""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.util
import json
import sys
from lxml import etree as E

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
ARCHIVE = ROOT / 'flashswf/arts/new/Codex素材源稿/CF6特种兵-R3'
OWNER = ROOT / 'flashswf/arts/new/Codex特种兵素材'
ANCHOR = 'Codex特种兵素材'
LINKAGE = '敌人-CF6特种兵'
PREFIX = 'Codex/特种兵/'
NS = {'x': 'http://ns.adobe.com/xfl/2008/'}
N = '{' + NS['x'] + '}'
PARSER = E.XMLParser(remove_blank_text=False, strip_cdata=False, resolve_entities=False)
GUN_SOURCE = '1.枪械相关/手枪/枪-手枪-M1911'
GUN_LIBRARY = ROOT / 'flashswf/arts/things/LIBRARY'
SEQUENCES = {498:'站立', 500:'行走', 507:'三次点射', 517:'匕首刺击',
             518:'被击', 519:'被投', 520:'击倒原稿', 558:'死亡'}
# A single grounding translation applies to every body. The death first pose
# is aligned using the identical pelvis, independently of the image crop.
GROUND_SHIFT = -12.500106811523438
OFFSETS = {498:(25.5,-54.45), 500:(25.6,-53.55), 507:(4.75,-62.05),
           517:(26.5,-53.5), 518:(8.95,-59.95), 519:(16.9,-65.4),
           520:(5.5,-59), 558:(8,-59.9)}


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


common = module('soldier_common', ROOT / 'tools/cf6-manman-assets/build.py')
vector = module('soldier_vector', HERE / 'vector.py')
native = common.native
for key, value in {'ROOT':ROOT, 'HERE':HERE, 'OWNER':OWNER, 'ARCHIVE':ARCHIVE,
                   'ANCHOR':ANCHOR, 'LINKAGE':LINKAGE, 'PREFIX':PREFIX}.items():
    setattr(common, key, value)
native.OWNER, native.HERE = OWNER, HERE
native.MANIFEST_SCHEMA = 'cf6-soldier.native-import.v1'
native.PROJECT_FILES = ('DOMDocument.xml', ANCHOR+'.xfl', 'PublishSettings.xml', 'MobileSettings.xml')
native.SHARED_HELPERS = {old:PREFIX+'CF7/'+old for old in native.SHARED_HELPERS}
H = native.SHARED_HELPERS


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def gun_closure():
    result, pending = {}, [GUN_SOURCE]
    while pending:
        name = pending.pop()
        if name in result:
            continue
        source = E.parse(str(GUN_LIBRARY/(name+'.xml')), PARSER).getroot()
        if source.findall('.//x:Actionscript', NS) or source.findall('.//x:BitmapFill', NS) or source.get('linkageImportForRS') == 'true':
            raise ValueError('Handgun dependency requires a new review: '+name)
        result[name] = source
        pending.extend(item.get('libraryItemName') for item in source.findall('.//x:DOMSymbolInstance', NS))
    return result


def build_inputs():
    paths = [HERE/'build.py', HERE/'vector.py', HERE/'SoldierAI.as',
        ROOT/'tools/cf6-wings-assets/vector.py', ROOT/'tools/cf6-manman-assets/build.py',
        ROOT/'tools/cf6-zombie-assets/build.py', ROOT/'tools/gamma-echo-assets/build.py',
        ROOT/'tools/tesla-map-assets/native_vector/svg_to_xfl_legacy.py',
        ROOT/'tools/asset-metrology/xfl_geometry.py',
        ROOT/'flashswf/arts/new/Codex黑仔素材/PublishSettings.xml']
    paths += [native.THINGS1/(old+'.xml') for old in sorted(H)]
    paths += [GUN_LIBRARY/(name+'.xml') for name in sorted(gun_closure())]
    return [{'path':p.relative_to(ROOT).as_posix(), 'sha256':sha(p)} for p in paths]


def depth_layers(timeline, parts):
    layers = []
    for depth in sorted({int(d) for f in timeline for d, row in f.items() if row['id'] in parts}, reverse=True):
        states = [f.get(str(depth)) if f.get(str(depth), {}).get('id') in parts else None for f in timeline]
        frames, start = [], 0
        while start < len(states):
            row, end = states[start], start+1
            def visual(value):
                return None if value is None else (value['id'], value['matrix'], value.get('colorMult'), value.get('colorAdd'))
            while end < len(states) and visual(states[end]) == visual(row):
                end += 1
            elements = []
            if row is not None:
                gun = row['id'] == 492
                inst = native.instance(parts[row['id']], matrix=row['matrix'],
                    **({'symbol_type':'movie clip', 'name':'soldierGun'} if gun else {}))
                mult, add = row.get('colorMult', [256]*4), row.get('colorAdd', [0]*4)
                if mult != [256]*4 or add != [0]*4:
                    color = E.SubElement(E.SubElement(inst, N+'color'), N+'Color')
                    for i, channel in enumerate(('red','green','blue','alpha')):
                        color.set(channel+'Multiplier', native.num(mult[i]/256))
                        color.set(channel+'Offset', native.num(add[i]))
                elements.append(inst)
            frames.append(native.frame(start, end-start, elements))
            start = end
        layers.append(native.layer('原始深度_'+str(depth), frames))
    return layers


def make_body(name, timeline, parts, scripts=None):
    return native.symbol(name, [native.make_sparse_layer('CF7生命周期',len(timeline),scripts or {}),
        *depth_layers(timeline,parts)], symbol_type='movie clip')


def build_symbols():
    common.verify_input()
    timeline = json.loads((ARCHIVE/'reference/timelines.json').read_text(encoding='utf8'))
    assets = {r['id']:r for r in json.loads((ARCHIVE/'asset-manifest.json').read_text(encoding='utf8'))['assets']}
    required = {r['id'] for sid in SEQUENCES for f in timeline[str(sid)] for r in f.values()}
    required -= {281,290,299,311,359,360,492,506}
    if len(required) != 58:
        raise ValueError('Ordinary soldier drawing closure changed')
    result, parts, stats = native.clone_shared_helpers(), {}, []
    vector.NativePart.shared_references = {}
    for cid in sorted(required):
        name = PREFIX+'分件/'+str(cid)
        converted, report = vector.NativePart(ARCHIVE/assets[cid]['file'],name,(0,0)).build()
        for key, item in converted.items():
            if key in result and native.xml_bytes(result[key]) != native.xml_bytes(item):
                raise ValueError('Conflicting shared atlas: '+key)
        result.update(converted)
        parts[cid] = name
        stats.append({'id':cid, **report})

    # This explicit source has four script-free vector symbols. Cloning into the
    # soldier namespace avoids relying on global handgun linkage collisions.
    originals = gun_closure()
    names = {name:PREFIX+'CF7手枪/'+name for name in originals}
    for name, source in originals.items():
        item = copy.deepcopy(source)
        item.set('name',names[name])
        for key in list(item.attrib):
            if key.startswith('linkage') or key in ('itemID','lastModified','lastUniqueIdentifier'):
                item.attrib.pop(key,None)
        item.find('x:timeline/x:DOMTimeline',NS).set('name',names[name].split('/')[-1])
        for inst in item.findall('.//x:DOMSymbolInstance',NS):
            inst.set('libraryItemName',names[inst.get('libraryItemName')])
            if inst.get('name') == '枪口位置':
                inst.set('symbolType','movie clip')
                color = E.SubElement(E.SubElement(inst,N+'color'),N+'Color')
                color.set('alphaMultiplier','0')
        if name == GUN_SOURCE:
            item.set('symbolType','movie clip')
        result[names[name]] = item
    weapon = PREFIX+'武器/固定手枪'
    result[weapon] = native.symbol(weapon,[native.layer('CF7手枪',[native.frame(
        script='stop();',elements=[native.instance(names[GUN_SOURCE],symbol_type='movie clip',name='gun')])])],symbol_type='movie clip')
    parts[492] = weapon
    actions = {sid:PREFIX+'动作/'+name for sid,name in SEQUENCES.items()}
    for sid in SEQUENCES:
        if any(sum(r['id']==492 for r in f.values())>1 for f in timeline[str(sid)]):
            raise ValueError('More than one handgun requires explicit ownership: '+str(sid))

    result[actions[498]] = make_body(actions[498],timeline['498'],parts,
        {4:{'script':'if(_parent.状态=="躲闪" || _parent.状态=="拾取") _parent.动画完毕();'}})
    result[actions[500]] = make_body(actions[500],timeline['500'],parts)
    result[actions[507]] = make_body(actions[507],timeline['507'],parts,{
        0:{'script':'_parent.soldierBeginAttack(this,"shoot");'},
        2:{'script':'_parent.soldierShoot(this);'},
        6:{'script':'_parent.soldierShoot(this);'},
        10:{'script':'_parent.soldierShoot(this);'},
        13:{'script':'_parent.soldierFinishAttack(this);'}})
    knife_height = 135
    center_y = -knife_height/2 - OFFSETS[517][1] - GROUND_SHIFT
    result[actions[517]] = native.symbol(actions[517],[
        native.make_sparse_layer('攻击生命周期',34,{
            0:{'script':'_parent.soldierBeginAttack(this,"knife");'},
            33:{'script':'_parent.soldierFinishAttack(this);'}}),
        native.make_sparse_layer('真实近战判定',34,{13:{'elements':[
            native.instance(H['Symbol 195'],matrix=(101/25,0,0,knife_height/25,10.3,center_y),
                symbol_type='movie clip',name='攻击点',alpha_mult=0,
                script='onClipEvent(load){ _parent._parent.soldierStab(_parent,this); }')]}}),
        *depth_layers(timeline['517'],parts)],symbol_type='movie clip')
    result[actions[518]] = make_body(actions[518],timeline['518'],parts,{
        0:{'name':'a0','label_type':'name'},12:{'name':'a1','label_type':'name'},
        7:{'script':'_parent.动画完毕();'},18:{'script':'_parent.动画完毕();'}})
    result[actions[519]] = make_body(actions[519],timeline['519'],parts,{12:{'script':'stop();'}})
    airborne, down = PREFIX+'动作/击飞', PREFIX+'动作/倒地恢复'
    result[airborne] = make_body(airborne,timeline['520'][:40],parts,{
        0:{'name':'空手','label_type':'name'},39:{'script':'stop();'}})
    result[down] = make_body(down,timeline['520'][40:],parts,{
        8:{'script':'_parent.死亡检测();'},75:{'script':'_parent.动画完毕();'}})
    result[actions[558]] = make_body(actions[558],timeline['558'],parts,{
        0:{'name':'a0','label_type':'name'},58:{'name':'a1','label_type':'name'},104:{'name':'a2','label_type':'name'},
        57:{'script':'_parent.死亡检测(); stop();'},103:{'script':'_parent.死亡检测(); stop();'},
        138:{'script':'_parent.死亡检测(); stop();'}})

    driver = PREFIX+'行为驱动'
    result[driver] = native.symbol(driver,[native.layer('停止',[native.frame(script='stop();')])],symbol_type='movie clip')
    shadow = result[H['Symbol 2']]
    shadow.set('symbolType','movie clip')
    shadow.find('x:timeline/x:DOMTimeline/x:layers',NS).insert(0,native.layer('全状态接地',[native.frame(script='''soldierGround={x:0,y:0};
updateSoldierShadow=function():Void {
    var unit:MovieClip=this._parent;
    var visible:Boolean=_root.是否阴影==true;
    if(this._visible!=visible) this._visible=visible;
    if(isNaN(unit.Z轴坐标)) return;
    var p:Object=this.soldierGround; p.x=unit._x; p.y=unit.Z轴坐标;
    unit._parent.localToGlobal(p);unit.globalToLocal(p);
    if(this._x!=p.x) this._x=p.x;if(this._y!=p.y) this._y=p.y;
    var rotation:Number=unit._xscale<0?unit._rotation:-unit._rotation;
    if(this._rotation!=rotation) this._rotation=rotation;
};
onEnterFrame=updateSoldierShadow;updateSoldierShadow();stop();''')]))

    def body(sid,script=None,name=None):
        x,y = OFFSETS[sid]
        return native.instance(name or actions[sid],matrix=(1,0,0,1,x,y+GROUND_SHIFT),
            symbol_type='movie clip',name='man',script=script)
    states = {1:'空手站立',9:'空手行走',19:'空手跑',29:'空手跳',37:'近战',41:'空手攻击',
        51:'拾取',61:'躲闪',71:'被击',79:'击倒',88:'倒地',95:'被投',104:'血腥死',120:'消失'}
    init = '''hasDressup=false;enableShoot=false;
x轴攻击范围=0;y轴攻击范围=24;x轴保持距离=190;攻击欲望=3;命中率=20;
_root.敌人函数.配置音效("人类",this);
初始化敌人模板=_root.初始化敌人模板;初始化敌人模板();
'''+(HERE/'SoldierAI.as').read_text(encoding='utf-8-sig')
    bodies = {0:(9,body(498)),9:(10,body(500)),19:(10,body(500)),29:(8,body(519)),
        37:(4,body(517)),41:(10,body(507)),51:(10,body(498)),61:(10,body(498)),
        71:(8,body(518,'onClipEvent(load){_parent.soldierCancelAttack();gotoAndPlay("a"+random(2));}')),
        79:(9,body(520,'onClipEvent(load){_parent.soldierCancelAttack();_parent.击飞浮空();}',airborne)),
        88:(7,body(520,'onClipEvent(load){_parent.soldierCancelAttack();_parent.击飞倒地();}',down)),
        95:(9,body(519,'onClipEvent(load){_parent.soldierCancelAttack();}')),
        104:(16,body(558,'onClipEvent(load){_parent.soldierCancelAttack();gotoAndPlay("a"+random(3));}'))}
    root_name = PREFIX+LINKAGE
    result[root_name] = native.symbol(root_name,[
        native.make_sparse_layer('状态标签',125,{i:{'name':s,'label_type':'name'} for i,s in states.items()}),
        native.make_sparse_layer('初始化与消失',125,{0:{'script':init},1:{'script':'this.swapDepths(this._y);'},120:{'script':'hp=0;soldierCancelAttack();'}}),
        native.make_sparse_layer('私有行为',125,{0:{'duration':120,'elements':[
            native.instance(driver,symbol_type='movie clip',name='soldierDriver',script='onClipEvent(enterFrame){_parent.soldierTick();}')]}}),
        native.make_sparse_layer('文字信息',125,{0:{'duration':120,'elements':[
            native.instance(H['Symbol 32'],matrix=(1,0,0,1,0,-150),symbol_type='movie clip',name='人物文字信息')]}}),
        native.make_sparse_layer('受击包围盒',125,{0:{'duration':79,'elements':[
            native.instance(H['Symbol 19'],matrix=(3.2,0,0,5.2,-44,-132),symbol_type='movie clip',name='area')]},
            79:{'duration':9,'elements':[native.instance(H['Symbol 19'],matrix=(3.2,0,0,5.2,-44,-132),symbol_type='movie clip',name='area')]},
            88:{'duration':7,'elements':[native.instance(H['Symbol 19'],matrix=(5.4,0,0,1.7,-68,-43),symbol_type='movie clip',name='area')]},
            95:{'duration':9,'elements':[native.instance(H['Symbol 19'],matrix=(3.2,0,0,5.2,-44,-132),symbol_type='movie clip',name='area')]}}),
        native.make_sparse_layer('通用索敌',125,{0:{'duration':29,'elements':[native.instance(H['思考标签'],symbol_type='movie clip')]}}),
        native.make_sparse_layer('行走',125,{0:{'duration':29,'elements':[
            native.instance(driver,symbol_type='movie clip',name='控制块',script='onClipEvent(enterFrame){if(!_root.暂停)_parent.行走();}')]}}),
        native.make_sparse_layer('动作',125,{i:{'duration':d,'elements':[b]} for i,(d,b) in bodies.items()}),
        native.make_sparse_layer('全状态接地阴影',125,{0:{'duration':120,'elements':[
            native.instance(H['Symbol 2'],matrix=(0.62,0,0,0.14,0,0),symbol_type='movie clip',name='soldierShadow')]}}),
    ],symbol_type='movie clip',linkage=LINKAGE,export_first_frame=True)
    return result,root_name,stats


def import_assets():
    native.guard_overwrite_allowed(False)
    symbols,root_name,stats = build_symbols()
    native.guard_overwrite_allowed(False)
    outputs = common.write_workspace(symbols,root_name)
    manifest = {'schema':native.MANIFEST_SCHEMA,'owner':OWNER.relative_to(ROOT).as_posix(),
        'approvedInput':ARCHIVE.relative_to(ROOT).as_posix(),'nativeSymbolCount':len(outputs),
        'buildInputs':build_inputs(),'parts':stats,'groundShift':GROUND_SHIFT,
        'sourceOffsets':{str(k):v for k,v in OFFSETS.items()},'ordinaryRoot':559,
        'sourceBodyFrames':378,'shootFrames':[3,7,11],'knifeHitFrame':14,
        'deathBranches':[[1,58],[59,104],[105,139]],'airborneSourceFrames':[1,40],'landedSourceFrames':[41,116],
        'weaponSource':GUN_SOURCE,'weaponSourceSymbols':len(gun_closure()),'outputs':outputs,
        'projectFiles':[{'path':p,'sha256':sha(OWNER/p),'bytes':(OWNER/p).stat().st_size} for p in native.PROJECT_FILES]}
    (HERE/'native-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
    common.mount_shared_library()
    print(json.dumps({'symbols':len(outputs),'linkage':LINKAGE},ensure_ascii=False))


def check():
    common.verify_input()
    manifest = json.loads((HERE/'native-manifest.json').read_text(encoding='utf8'))
    errors = native.workspace_identity_failures(manifest)
    if manifest['buildInputs'] != build_inputs():
        errors.append('Generator inputs changed; guarded regeneration required')
    includes = {i.get('href') for i in E.parse(str(OWNER/'DOMDocument.xml')).findall('x:symbols/x:Include',NS)}
    for row in manifest['outputs']:
        tree = E.parse(str(OWNER/row['path']),PARSER)
        if row['path'][8:] not in includes:
            errors.append('Missing Include: '+row['path'])
        for element in tree.iter():
            ref = element.get('libraryItemName')
            if ref and not (OWNER/'LIBRARY'/(ref+'.xml')).is_file():
                errors.append('Unresolved '+ref)
        if tree.findall('.//x:BitmapFill',NS) or tree.findall('.//x:DOMBitmapInstance',NS):
            errors.append('Unexpected bitmap '+row['path'])
    if errors:
        raise ValueError('\n'.join(errors))
    print(json.dumps({'ok':True,'symbols':len(manifest['outputs']),'projectFiles':len(manifest['projectFiles'])}))


if __name__ == '__main__':
    if hasattr(sys.stdout,'reconfigure'):
        sys.stdout.reconfigure(encoding='utf8')
    parser = argparse.ArgumentParser()
    parser.add_argument('--import-approved',action='store_true')
    parser.add_argument('--check',action='store_true')
    args = parser.parse_args()
    if args.import_approved:
        import_assets()
    check()
