#!/usr/bin/env python3
"""Read-only audit of the supplied R6 archive. Never executes bundled sources.
Usage: python audit_evidence.py INPUT.zip OUTPUT_DIRECTORY
Outputs evidence-audit.json and selected-evidence.md; input files remain unchanged.
"""
from __future__ import annotations
import collections
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path

CASES = ('before', 'hover-fixed', 'same-process', 'final')

def main(archive: Path, output: Path) -> None:
    if not archive.is_file():
        raise FileNotFoundError(archive)
    output.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        def text(name: str) -> str:
            return z.read(name).decode('utf-8-sig')
        manifest = json.loads(text('sha256.json'))
        integrity = [{'path': k, 'expected': v, 'actual': hashlib.sha256(z.read(k)).hexdigest(),
                      'matches': hashlib.sha256(z.read(k)).hexdigest() == v}
                     for k, v in manifest.items()]
        report: dict = {
            'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'manifest_entries': len(manifest), 'manifest_mismatches': [r['path'] for r in integrity if not r['matches']],
            'integrity': integrity,
            'scope': 'Static parsing only. No Windows, Flash, native selftest, Host suite, or manual acceptance was run.',
            'cases': {}}
        for case in CASES:
            base = f'evidence/{case}/'
            summary = json.loads(text(base+'summary.json'))
            as2 = [json.loads(l) for l in text(base+'as2.jsonl').splitlines() if l.strip()]
            raw = [json.loads(r['Raw']) for r in as2]
            host = text(base+'host.log').splitlines()
            traces = []
            for i, line in enumerate(host, 1):
                if ' TRACE ' in line:
                    item = dict(re.findall(r'(\w+)=([^ ]+)', line))
                    item['file_line'] = i
                    traces.append(item)
            phases = {}
            for phase in sorted({r['Phase'] for r in as2}):
                rr = [r for r in as2 if r['Phase'] == phase]
                phases[phase] = dict(collections.Counter(r['Event'] for r in rr))
            report['cases'][case] = {
                'identity': json.loads(text(base+'identity.json')),
                'summary_result': summary['result'],
                'summary_pass_count': sum(bool(a['okay']) for a in summary['assertions']),
                'summary_assertion_count': len(summary['assertions']),
                'summary_failed_assertions': [a['name'] for a in summary['assertions'] if not a['okay']],
                'as2_record_count': len(as2), 'as2_first_seq': raw[0]['seq'], 'as2_last_seq': raw[-1]['seq'],
                'as2_sequence_gaps': [{'previous': a['seq'], 'next': b['seq']} for a,b in zip(raw,raw[1:]) if b['seq'] != a['seq']+1],
                'phase_event_counts': phases,
                'phase_count_caveat': 'Whole receive-time Phase counts, not the exact unlogged per-assertion mark/end windows.',
                'trace_count': len(traces),
                'trace_stage_counts': dict(collections.Counter(t['stage'] for t in traces)),
                'trace_ordinal_gaps': [{'previous': a['ordinal'], 'next': b['ordinal']} for a,b in zip(traces,traces[1:]) if a['session']==b['session'] and int(b['ordinal']) != int(a['ordinal'])+1],
                'wm_capturechanged_observations': [t for t in traces if t.get('msg') == '0x215'],
                'external_phase_non_sample_callbacks': [dict(file_line=i, **json.loads(r['Raw'])) for i,r in enumerate(as2,1) if r['Phase']=='external-focus' and r['Event']!='sample'],
                'limitation': 'Existing summaries were counted; their pass results were not independently rerun.'}
        native = text('evidence/native-selftest.log').splitlines()
        queue = text('evidence/g1-queue.log').splitlines()
        report['native_logged_pass_count'] = sum(l.startswith('PASS ') for l in native)
        report['g1_logged_assert_pass_count'] = sum('ASSERT PASS ' in l for l in queue)
        report['pre_down_summary'] = json.loads(text('evidence/pre-down-experiment-summary.json'))
        report['binary_provenance_limit'] = 'Manifest and hash statements verified as text only; DLL/EXE/SWF bytes and original build closure are not in this archive.'
        (output/'evidence-audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
        ranges = [
            ('01-request.md',1,26), ('02-report.md',1,100),
            ('src/InputBridge.cpp',80,106), ('src/InputBridge.cpp',146,166),
            ('src/InputBridge.cpp',213,291), ('src/InputBridge.cpp',293,359),
            ('src/InputBridge.h',35,62), ('src/NativePointerBridge.cs',74,94),
            ('src/WorldCompositionSurface.cs',74,141), ('src/WorldCompositionSurface.cs',202,243),
            ('src/WorldCompositionSurface.cs',264,288),
            ('src/WorldCompositorController.cs',246,267), ('src/WorldCompositorController.cs',326,362),
            ('src/HoverProbe.as',1,35), ('src/HoverHost.cs',67,85), ('src/HoverHost.cs',174,215),
            ('evidence/final/host.log',438,470), ('evidence/final/as2.jsonl',599,633),
            ('evidence/same-process/host.log',423,455),
            ('evidence/native-selftest.log',1,len(native)), ('evidence/g1-queue.log',185,len(queue)),
            ('evidence/causal-pair.json',1,100), ('evidence/native-pair.json',1,100), ('evidence/entry-observed.json',1,100)]
        out = ['# R6 原始证据摘录\n', '所有 L 行号均对应输入 ZIP 内原文件；未改写摘录。此文件由静态读取产生，不代表重新执行测试。\n']
        for name, start, end in ranges:
            lines = text(name).splitlines(); end=min(end,len(lines))
            out += [f'\n## {name}:L{start}–L{end}\n', '```text\n']
            out += [f'L{i}: {lines[i-1]}\n' for i in range(start,end+1)]
            out += ['```\n']
        (output/'selected-evidence.md').write_text(''.join(out), encoding='utf-8')
    print(json.dumps({'archive_sha256': report['archive_sha256'], 'manifest_entries': report['manifest_entries'],
                      'mismatches': report['manifest_mismatches'], 'native_logged_passes': report['native_logged_pass_count'],
                      'g1_logged_passes': report['g1_logged_assert_pass_count'],
                      'cases': {k: {'passed':v['summary_pass_count'],'total':v['summary_assertion_count']} for k,v in report['cases'].items()}},ensure_ascii=False,indent=2))

if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('Usage: python audit_evidence.py INPUT.zip OUTPUT_DIRECTORY')
    main(Path(sys.argv[1]), Path(sys.argv[2]))
