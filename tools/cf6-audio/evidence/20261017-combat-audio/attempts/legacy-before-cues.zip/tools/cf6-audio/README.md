# CF6 动作音效核查与原生播放接线

**文档角色**：已接入 CF6 单位的音效来源、缺失统计、确定性装配和验证入口。所有新增播放均调用 `_root.播放音效`；角色 SWF 不携带音轨、DefineSound 或 StartSound。八个素材生成器共用 [build.py](build.py)，调用时机随动作装配，实际声音交给现有原生 SFX 管线。

## 本轮发现与修复

核查包括兵种 461–472 的十二个目录身份，以及既有克隆兽 372、女特工 373、派生克隆兽 459／460。光头保安两种目录身份共用原作动作根，因此新素材库对应十一个原作根；派生克隆兽也不重复计作独立原作单位。

按原作 StartSound 的动作位置计数，八库共有 50 处，此前缺失 45 处，另 5 处由 Wings 现有 CF7 劈砍声覆盖。这里的 90% 只描述这些动作位置，**不代表全部声音文件或玩家实际听感的缺失比例**。脚本随机叫声、枪械声音、变形过场和旧单位改编另外核查。

| 新素材库 | 原作动作位置 | 此前缺失 | 处理 |
|---|---:|---:|---|
| 男／女僵尸 | 6 | 6 | 攻击、投掷、落地；女僵尸受击与倒地改回原女声 |
| 蛮蛮 | 6 | 6 | 突刺、劈砍、受击、死亡；删除两个残留时间轴音轨声明 |
| Wings | 7 | 2 | 补首段刀声与落地；原脚步、枪声和五次连斩改编保留 |
| 两阶段特种兵 | 4 | 4 | 匕首与破盾；补随机受击、投掷及死亡叫声，枪声仍来自装备 |
| 两型光头保安 | 3 | 3 | 变身与落地；补受击／死亡叫声，保留 SPAS12 枪声 |
| 大刀机器人 | 7 | 7 | 光束、刀招、受击和机械死亡 |
| 大头机器人 | 4 | 4 | 两段光束、冲击机械声与受击 |
| 老头两种形态 | 13 | 13 | 刺击、机械动作、红束和死亡；补脚本叫声及角色变形段 |

[cues.json](cues.json) 记录原 sprite／帧／soundId 与当前动作位置；67 个动作调用、两处女声替换、三种机器人的一次性爆炸声分别记录。改编新增招式复用原声，但不计作原作漏接。人形老头的原关卡枪声配置为“无”，本次四发增加现有 `shoot.wav`，明确属于新表现。

Wings、特种兵及光头保安的死亡片段从自然首帧进入时原先会先后触发两次叫声，已改为每个死亡身体一次；直接跳入相应分支仍能发声。暂停时不触发新增动作声，旧身体不能以迟到帧继续播放。

旧克隆兽及两个派生单位原有脚步、爪击、跳跃、着陆和嘶吼调用完整，但共用的 `soundheadexplode.wav` 在原生预载目录缺失。已从 `things1` 原工程复制原文件，字节、CRC 与工程元数据一致，未改旧 SWF。旧女特工保留现有 CF7 武器、动作和女声改编，声明的声音文件均存在；不因其音色不同而判成“没有声音”。三个克隆兽另有原生死亡调用复验；旧女特工此次仅静态核查，没有新增实机听感结论。

## 来源与资源

原 CF6 SWF 的 SHA-256 为 `b52af10e2dda43332e0b2ffb9549d2fad474f298b9f6c67d848ffc33ff589b01`。只读解析 DefineSound、StartSound、导出表及实例闭包，不改写原文件。[assets.json](assets.json) 绑定 44 份提取资源、soundId、原包元信息与每文件哈希，总计 1,401,498 字节；其中 41 份为原 MP3 载荷，3 份为按原音量包络离线生成的 PCM WAV。加上恢复的旧 WAV，总增量为 45 份、1,537,990 字节。

[legacy-assets.json](legacy-assets.json) 单独绑定旧资源恢复。[audit.py](audit.py) 解码全部新提取音效，检查非空、非静音、有限采样及完整解码；它不是原生输出端听音验收。原 male-zombie 和旧女特工的 CF7 叫声改编保留，通用血肉／金属碰撞继续由正式伤害管线负责。

## 重建与验证

从仓库根执行，提取时传入上述哈希对应的合法原文件：

```powershell
chcp.com 65001
python -X utf8 -B tools/cf6-audio/extract.py --source-swf <原CF6.swf> --write
python -X utf8 -B tools/cf6-audio/extract.py --source-swf <原CF6.swf>
python -X utf8 -B tools/cf6-audio/restore-legacy.py --write
python -X utf8 -B tools/cf6-audio/restore-legacy.py
python -X utf8 -B tools/cf6-audio/build-test-fixture.py --check
python -X utf8 -B tools/cf6-audio/build-legacy-test-fixture.py --check
scripts/run-cf6-audio-tests.ps1
scripts/run-cf6-legacy-audio-tests.ps1
python -X utf8 -B tools/cf6-audio/audit.py --source-swf <原CF6.swf> --baseline-zip <修改前源码与SWF包.zip> --output <新审计目录>
```

修改 `cues.json` 后须逐个运行所属素材库的生成器和 `--check`，再用明确的独立 XFL 目标交给真实 CS6 编译；不重编主 XFL 或 native runtime。行为夹具实际加载发布 SWF，拦截 `_root.播放音效`，校验指定动作、自然死亡、暂停及旧身体拒绝；这证明调用路由，不证明扬声器输出或音量混音。爆炸伤害和新招式的验证归三个机器人各自入口。

本轮全部成功、失败及恢复材料集中在[战斗与音效证据](evidence/20261017-combat-audio/summary.json)。45 份音效随八个新角色 SWF 一起交付；完整退出游戏再启动以重新预载。主观音量、音色和战斗体验由玩家验收，正式 runtime 发布状态独立记录。
