# Particles-AS2-Port
Particles JS tutorial ported to actionscript 2.0 in Adobe Flash CS3 (2015) 

In 2015, I followed this tutorial http://www.playfuljs.com/particle-effects-are-easy/
and ported the javascript to actionscript 2.0 as best as I could with my knowledge at the time.

The end result was somewhat different from the demo that the JS author posted and ran much slower and
unoptimised on my swf file.

The end result however, was a fun little experiment.

Original Javascript source by Hunter Loftis:
http://www.playfuljs.com/
https://www.linkedin.com/in/hunterloftis
https://twitter.com/hunterloftis

This was one of the first times that I tried porting something from one language from another.
Especially the fact that I didn't know JavaScript except for the fact that both JavaScript and
ActionScript 2.0 had similar syntax.

Port by Stephen Birsa (2015)
